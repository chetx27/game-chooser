import GameSelector from "@/components/game-selector"
import BackgroundAnimation from "@/components/background-animation"

export default function Home() {
  return (
    <main className="min-h-screen overflow-hidden relative text-white">
      <BackgroundAnimation />

      <div className="container mx-auto px-4 py-12 relative z-10">
        <header className="mb-12 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-[#FF2D95] to-[#00FFFF] drop-shadow-[0_0_10px_rgba(255,45,149,0.3)]">
            Game Finder
          </h1>
          <p className="text-xl text-[#E0E0FF] max-w-2xl mx-auto">
            Discover your perfect game by making simple choices between contrasting options
          </p>
        </header>

        <GameSelector />
      </div>
    </main>
  )
}
