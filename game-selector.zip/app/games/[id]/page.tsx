"use client"

import { Badge } from "@/components/ui/badge"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import NeonFuryGame from "@/components/games/neon-fury"
import CosmicConquestGame from "@/components/games/cosmic-conquest"
import PuzzleDimensionsGame from "@/components/games/puzzle-dimensions"
import VelocityRushGame from "@/components/games/velocity-rush"

// Sample game data (same as in game-selector.tsx)
const GAMES = [
  {
    id: 1,
    title: "Cosmic Conquest",
    description: "An epic space strategy game with deep resource management and diplomacy.",
    image: "/placeholder.svg?height=300&width=200",
    genres: ["Strategy", "Sci-Fi", "4X"],
    platforms: ["PC", "Mac"],
    multiplayer: false,
    pace: "Slow",
    complexity: "High",
  },
  {
    id: 2,
    title: "Neon Fury",
    description: "Fast-paced cyberpunk shooter with stunning visuals and intense combat.",
    image: "/placeholder.svg?height=300&width=200",
    genres: ["Action", "FPS", "Cyberpunk"],
    platforms: ["PC", "PlayStation", "Xbox"],
    multiplayer: true,
    pace: "Fast",
    complexity: "Medium",
  },
  {
    id: 3,
    title: "Verdant Valley",
    description: "Relaxing farming simulator where you build your dream homestead.",
    image: "/placeholder.svg?height=300&width=200",
    genres: ["Simulation", "Casual", "Life Sim"],
    platforms: ["PC", "Switch", "Mobile"],
    multiplayer: false,
    pace: "Slow",
    complexity: "Low",
  },
  {
    id: 4,
    title: "Legends Arena",
    description: "Competitive team-based battle game with unique heroes and abilities.",
    image: "/placeholder.svg?height=300&width=200",
    genres: ["MOBA", "Strategy", "Action"],
    platforms: ["PC", "Mobile"],
    multiplayer: true,
    pace: "Fast",
    complexity: "High",
  },
  {
    id: 5,
    title: "Mystic Realms",
    description: "Immersive fantasy RPG with a vast open world and compelling storyline.",
    image: "/placeholder.svg?height=300&width=200",
    genres: ["RPG", "Fantasy", "Open World"],
    platforms: ["PC", "PlayStation", "Xbox"],
    multiplayer: false,
    pace: "Medium",
    complexity: "High",
  },
  {
    id: 6,
    title: "Velocity Rush",
    description: "High-octane racing game with futuristic vehicles and impossible tracks.",
    image: "/placeholder.svg?height=300&width=200",
    genres: ["Racing", "Arcade", "Futuristic"],
    platforms: ["PC", "PlayStation", "Xbox", "Switch"],
    multiplayer: true,
    pace: "Fast",
    complexity: "Low",
  },
  {
    id: 7,
    title: "Puzzle Dimensions",
    description: "Mind-bending puzzle game that plays with physics and perspective.",
    image: "/placeholder.svg?height=300&width=200",
    genres: ["Puzzle", "Casual", "Indie"],
    platforms: ["PC", "Mobile", "Switch"],
    multiplayer: false,
    pace: "Slow",
    complexity: "Medium",
  },
  {
    id: 8,
    title: "Survival Horizon",
    description: "Post-apocalyptic survival game where every decision matters.",
    image: "/placeholder.svg?height=300&width=200",
    genres: ["Survival", "Open World", "Crafting"],
    platforms: ["PC", "PlayStation", "Xbox"],
    multiplayer: true,
    pace: "Medium",
    complexity: "High",
  },
]

export default function GamePage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [game, setGame] = useState<(typeof GAMES)[0] | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Find the game by ID
    const gameId = Number.parseInt(params.id)
    const foundGame = GAMES.find((g) => g.id === gameId)

    if (foundGame) {
      setGame(foundGame)
    }

    setLoading(false)
  }, [params.id])

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#0F0B2A] to-[#1A1145] text-white flex items-center justify-center">
        <div className="text-2xl font-bold">Loading...</div>
      </div>
    )
  }

  if (!game) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#0F0B2A] to-[#1A1145] text-white flex flex-col items-center justify-center p-4">
        <div className="text-2xl font-bold mb-4">Game not found</div>
        <Button
          onClick={() => router.push("/")}
          variant="outline"
          className="bg-transparent border border-[#9D00FF] text-white hover:bg-[#9D00FF]/20"
        >
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Home
        </Button>
      </div>
    )
  }

  // Render the appropriate game component based on the game ID
  const renderGame = () => {
    switch (game.id) {
      case 2: // Neon Fury
        return <NeonFuryGame />
      case 1: // Cosmic Conquest
        return <CosmicConquestGame />
      case 7: // Puzzle Dimensions
        return <PuzzleDimensionsGame />
      case 6: // Velocity Rush
        return <VelocityRushGame />
      default:
        return (
          <div className="flex flex-col items-center justify-center h-[500px] bg-[#0F0B2A]/50 rounded-lg">
            <div className="text-xl font-bold mb-4">Game demo coming soon!</div>
            <p className="text-[#E0E0FF]">This game is still in development.</p>
          </div>
        )
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0F0B2A] to-[#1A1145] text-white">
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center mb-8">
          <Button
            onClick={() => router.push("/")}
            variant="outline"
            className="bg-transparent border border-[#9D00FF] text-white hover:bg-[#9D00FF]/20"
          >
            <ArrowLeft className="mr-2 h-4 w-4" /> Back
          </Button>
          <h1 className="ml-4 text-2xl md:text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-[#FF2D95] to-[#00FFFF]">
            {game.title}
          </h1>
        </div>

        <div className="mb-8">{renderGame()}</div>

        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <h2 className="text-xl font-bold mb-4 text-[#00FFFF]">About the Game</h2>
            <p className="text-[#E0E0FF] mb-4">{game.description}</p>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <h3 className="font-bold text-[#9D00FF] mb-2">Genres</h3>
                <div className="flex flex-wrap gap-2">
                  {game.genres.map((genre) => (
                    <Badge key={genre} className="bg-[#3A2A65] hover:bg-[#4A3A75] text-white">
                      {genre}
                    </Badge>
                  ))}
                </div>
              </div>
              <div>
                <h3 className="font-bold text-[#9D00FF] mb-2">Platforms</h3>
                <div className="flex flex-wrap gap-2">
                  {game.platforms.map((platform) => (
                    <Badge key={platform} className="bg-[#3A2A65] hover:bg-[#4A3A75] text-white">
                      {platform}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div>
            <h2 className="text-xl font-bold mb-4 text-[#00FFFF]">How to Play</h2>
            <div className="bg-[#1A1145]/50 p-4 rounded-lg">
              {game.id === 2 && (
                <div className="space-y-2">
                  <p className="font-bold text-[#FF2D95]">Neon Fury Controls:</p>
                  <ul className="list-disc list-inside text-[#E0E0FF] space-y-1">
                    <li>Move your mouse to aim</li>
                    <li>Click to shoot</li>
                    <li>WASD or Arrow keys to move</li>
                    <li>Space to dash</li>
                    <li>Eliminate all enemies to advance</li>
                    <li>Collect power-ups for special abilities</li>
                  </ul>
                </div>
              )}

              {game.id === 1 && (
                <div className="space-y-2">
                  <p className="font-bold text-[#FF2D95]">Cosmic Conquest Controls:</p>
                  <ul className="list-disc list-inside text-[#E0E0FF] space-y-1">
                    <li>Click on stars to select them</li>
                    <li>Drag between stars to send fleets</li>
                    <li>Right-click to cancel selection</li>
                    <li>Capture neutral stars to expand your empire</li>
                    <li>Defend your territory from rival empires</li>
                    <li>Research technologies to gain advantages</li>
                  </ul>
                </div>
              )}

              {game.id === 7 && (
                <div className="space-y-2">
                  <p className="font-bold text-[#FF2D95]">Puzzle Dimensions Controls:</p>
                  <ul className="list-disc list-inside text-[#E0E0FF] space-y-1">
                    <li>Click and drag to rotate the puzzle</li>
                    <li>Click on puzzle pieces to select them</li>
                    <li>Arrow keys to move selected pieces</li>
                    <li>Space to change perspective</li>
                    <li>Align the shapes to match the silhouette</li>
                    <li>Complete the puzzle before time runs out</li>
                  </ul>
                </div>
              )}

              {game.id === 6 && (
                <div className="space-y-2">
                  <p className="font-bold text-[#FF2D95]">Velocity Rush Controls:</p>
                  <ul className="list-disc list-inside text-[#E0E0FF] space-y-1">
                    <li>WASD or Arrow keys to steer</li>
                    <li>Space to boost</li>
                    <li>Shift to drift</li>
                    <li>E to use power-ups</li>
                    <li>Avoid obstacles and stay on the track</li>
                    <li>Complete laps as fast as possible</li>
                  </ul>
                </div>
              )}

              {![1, 2, 6, 7].includes(game.id) && (
                <div className="space-y-2">
                  <p className="font-bold text-[#FF2D95]">Game Controls:</p>
                  <ul className="list-disc list-inside text-[#E0E0FF] space-y-1">
                    <li>Controls will be available when the game is released</li>
                    <li>Check back soon for updates!</li>
                  </ul>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
