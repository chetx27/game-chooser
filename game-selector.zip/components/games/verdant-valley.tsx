"use client"

import { useEffect, useRef, useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Play, Pause, RotateCcw, Volume2, VolumeX, Shovel, Droplets, SproutIcon as Seedling, Sun } from "lucide-react"

interface Tile {
  id: number
  x: number
  y: number
  type: "empty" | "tilled" | "watered" | "growing" | "ready"
  crop?: "carrot" | "tomato" | "corn" | "pumpkin"
  growthStage: number
  maxGrowthStage: number
  lastWatered: number
}

interface Inventory {
  money: number
  seeds: {
    carrot: number
    tomato: number
    corn: number
    pumpkin: number
  }
  crops: {
    carrot: number
    tomato: number
    corn: number
    pumpkin: number
  }
}

export default function VerdantValleyGame() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [gameStarted, setGameStarted] = useState(false)
  const [gamePaused, setGamePaused] = useState(false)
  const [gameOver, setGameOver] = useState(false)
  const [score, setScore] = useState(0)
  const [day, setDay] = useState(1)
  const [muted, setMuted] = useState(false)
  const [selectedTool, setSelectedTool] = useState<"hoe" | "water" | "seed" | "harvest">("hoe")
  const [selectedSeed, setSelectedSeed] = useState<"carrot" | "tomato" | "corn" | "pumpkin">("carrot")
  const [inventory, setInventory] = useState<Inventory>({
    money: 100,
    seeds: {
      carrot: 5,
      tomato: 3,
      corn: 2,
      pumpkin: 1,
    },
    crops: {
      carrot: 0,
      tomato: 0,
      corn: 0,
      pumpkin: 0,
    },
  })

  // Game state
  const gameStateRef = useRef({
    grid: [] as Tile[],
    gridSize: 8,
    tileSize: 50,
    dayTime: 0, // 0-1000, representing time from morning to night
    dayLength: 60000, // 60 seconds per day
    weather: "sunny" as "sunny" | "rainy" | "cloudy",
    nextId: 1,
  })

  // Initialize game
  const initializeGame = () => {
    const { gridSize } = gameStateRef.current
    const grid: Tile[] = []

    // Create grid
    for (let y = 0; y < gridSize; y++) {
      for (let x = 0; x < gridSize; x++) {
        grid.push({
          id: gameStateRef.current.nextId++,
          x,
          y,
          type: "empty",
          growthStage: 0,
          maxGrowthStage: 4,
          lastWatered: 0,
        })
      }
    }

    gameStateRef.current.grid = grid
    gameStateRef.current.dayTime = 0
    gameStateRef.current.weather = Math.random() < 0.7 ? "sunny" : Math.random() < 0.5 ? "cloudy" : "rainy"

    setDay(1)
    setScore(0)
    setInventory({
      money: 100,
      seeds: {
        carrot: 5,
        tomato: 3,
        corn: 2,
        pumpkin: 1,
      },
      crops: {
        carrot: 0,
        tomato: 0,
        corn: 0,
        pumpkin: 0,
      },
    })
  }

  // Start game
  const startGame = () => {
    setGameStarted(true)
    setGameOver(false)
    initializeGame()
  }

  // Reset game
  const resetGame = () => {
    setGameStarted(false)
    setGameOver(false)
    setGamePaused(false)
  }

  // Toggle pause
  const togglePause = () => {
    setGamePaused(!gamePaused)
  }

  // Toggle mute
  const toggleMute = () => {
    setMuted(!muted)
  }

  // Handle tile click
  const handleTileClick = (tile: Tile) => {
    if (gamePaused || gameOver) return

    const { grid } = gameStateRef.current
    const tileIndex = grid.findIndex((t) => t.id === tile.id)

    if (tileIndex === -1) return

    // Apply selected tool
    switch (selectedTool) {
      case "hoe":
        if (tile.type === "empty") {
          grid[tileIndex].type = "tilled"
          playSound("till")
        }
        break
      case "water":
        if (tile.type === "tilled" || tile.type === "growing") {
          grid[tileIndex].type = tile.type === "tilled" ? "watered" : "growing"
          grid[tileIndex].lastWatered = Date.now()
          playSound("water")
        }
        break
      case "seed":
        if (tile.type === "watered" && inventory.seeds[selectedSeed] > 0) {
          grid[tileIndex].type = "growing"
          grid[tileIndex].crop = selectedSeed
          grid[tileIndex].growthStage = 1

          // Set max growth stage and value based on crop type
          switch (selectedSeed) {
            case "carrot":
              grid[tileIndex].maxGrowthStage = 3
              break
            case "tomato":
              grid[tileIndex].maxGrowthStage = 4
              break
            case "corn":
              grid[tileIndex].maxGrowthStage = 5
              break
            case "pumpkin":
              grid[tileIndex].maxGrowthStage = 6
              break
          }

          // Deduct seed from inventory
          setInventory((prev) => ({
            ...prev,
            seeds: {
              ...prev.seeds,
              [selectedSeed]: prev.seeds[selectedSeed] - 1,
            },
          }))

          playSound("plant")
        }
        break
      case "harvest":
        if (tile.type === "ready") {
          // Add crop to inventory
          setInventory((prev) => {
            const cropValue = getCropValue(tile.crop!)
            return {
              money: prev.money + cropValue,
              seeds: prev.seeds,
              crops: {
                ...prev.crops,
                [tile.crop!]: prev.crops[tile.crop!] + 1,
              },
            }
          })

          // Reset tile
          grid[tileIndex].type = "empty"
          grid[tileIndex].crop = undefined
          grid[tileIndex].growthStage = 0

          // Update score
          setScore((prev) => prev + 10)

          playSound("harvest")
        }
        break
    }

    // Update grid
    gameStateRef.current.grid = [...grid]
  }

  // Get crop value
  const getCropValue = (crop: "carrot" | "tomato" | "corn" | "pumpkin"): number => {
    switch (crop) {
      case "carrot":
        return 10
      case "tomato":
        return 15
      case "corn":
        return 20
      case "pumpkin":
        return 30
    }
  }

  // Buy seeds
  const buySeed = (type: "carrot" | "tomato" | "corn" | "pumpkin") => {
    const seedPrice = {
      carrot: 5,
      tomato: 8,
      corn: 12,
      pumpkin: 20,
    }

    if (inventory.money >= seedPrice[type]) {
      setInventory((prev) => ({
        money: prev.money - seedPrice[type],
        seeds: {
          ...prev.seeds,
          [type]: prev.seeds[type] + 1,
        },
        crops: prev.crops,
      }))

      playSound("buy")
    }
  }

  // Play sound
  const playSound = (type: "till" | "water" | "plant" | "harvest" | "buy" | "dayChange") => {
    if (muted) return

    const sound = new Audio()
    sound.volume = 0.3

    // Simple audio data
    sound.src = "data:audio/wav;base64,UklGRigAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAAABMYXZmNTguMTMuMTAw"
    sound.play()
  }

  // Initialize canvas and event listeners
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    // Set canvas dimensions
    const { gridSize, tileSize } = gameStateRef.current
    canvas.width = gridSize * tileSize
    canvas.height = gridSize * tileSize

    // Event listener for canvas clicks
    const handleCanvasClick = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect()
      const x = Math.floor((e.clientX - rect.left) / tileSize)
      const y = Math.floor((e.clientY - rect.top) / tileSize)

      const clickedTile = gameStateRef.current.grid.find((tile) => tile.x === x && tile.y === y)
      if (clickedTile) {
        handleTileClick(clickedTile)
      }
    }

    canvas.addEventListener("click", handleCanvasClick)

    return () => {
      canvas.removeEventListener("click", handleCanvasClick)
    }
  }, [selectedTool, selectedSeed, inventory, gamePaused, gameOver])

  // Game loop
  useEffect(() => {
    if (!gameStarted || gamePaused || gameOver) return

    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    let animationFrameId: number
    let lastTime = 0
    let lastGrowthCheck = 0

    const gameLoop = (timestamp: number) => {
      if (!gameStarted || gamePaused || gameOver) return

      const deltaTime = timestamp - lastTime
      lastTime = timestamp

      // Update day time
      gameStateRef.current.dayTime += deltaTime

      // Check if day is over
      if (gameStateRef.current.dayTime >= gameStateRef.current.dayLength) {
        // New day
        setDay((prev) => prev + 1)
        gameStateRef.current.dayTime = 0
        gameStateRef.current.weather = Math.random() < 0.7 ? "sunny" : Math.random() < 0.5 ? "cloudy" : "rainy"
        playSound("dayChange")

        // Check for game over (30 days)
        if (day >= 30) {
          setGameOver(true)
        }
      }

      // Check plant growth every 2 seconds
      if (timestamp - lastGrowthCheck > 2000) {
        updatePlantGrowth()
        lastGrowthCheck = timestamp
      }

      // Clear canvas
      ctx.fillStyle = "#8BC34A" // Grass green
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      // Draw grid
      drawGrid(ctx)

      // Draw weather effects
      drawWeather(ctx)

      // Draw UI
      drawUI(ctx)

      animationFrameId = requestAnimationFrame(gameLoop)
    }

    animationFrameId = requestAnimationFrame(gameLoop)

    return () => {
      cancelAnimationFrame(animationFrameId)
    }
  }, [gameStarted, gamePaused, gameOver, day, selectedTool, selectedSeed, inventory, muted])

  // Update plant growth
  const updatePlantGrowth = () => {
    const { grid, weather } = gameStateRef.current
    const now = Date.now()

    grid.forEach((tile, index) => {
      if (tile.type === "growing") {
        // Check if watered recently (last 24 hours in game time)
        const isWatered = now - tile.lastWatered < gameStateRef.current.dayLength

        // Growth chance based on weather and watering
        let growthChance = 0.1 // Base chance

        if (isWatered) growthChance += 0.2
        if (weather === "rainy") growthChance += 0.15
        if (weather === "sunny") growthChance += 0.1

        // Try to grow
        if (Math.random() < growthChance) {
          tile.growthStage++

          // Check if fully grown
          if (tile.growthStage >= tile.maxGrowthStage) {
            tile.type = "ready"
          }
        }

        // Plants can wither if not watered
        if (!isWatered && Math.random() < 0.05) {
          // 5% chance to wither if not watered
          if (tile.growthStage > 1) {
            tile.growthStage--
          }
        }
      }
    })

    gameStateRef.current.grid = [...grid]
  }

  // Draw grid
  const drawGrid = (ctx: CanvasRenderingContext2D) => {
    const { grid, tileSize } = gameStateRef.current

    grid.forEach((tile) => {
      const x = tile.x * tileSize
      const y = tile.y * tileSize

      // Draw tile background based on type
      switch (tile.type) {
        case "empty":
          ctx.fillStyle = "#8BC34A" // Grass green
          break
        case "tilled":
          ctx.fillStyle = "#795548" // Brown
          break
        case "watered":
          ctx.fillStyle = "#5D4037" // Dark brown (wet soil)
          break
        case "growing":
        case "ready":
          ctx.fillStyle = "#795548" // Brown
          break
      }

      ctx.fillRect(x, y, tileSize, tileSize)

      // Draw grid lines
      ctx.strokeStyle = "#33691E"
      ctx.lineWidth = 1
      ctx.strokeRect(x, y, tileSize, tileSize)

      // Draw crops
      if (tile.type === "growing" || tile.type === "ready") {
        drawCrop(ctx, tile)
      }

      // Draw water effect
      if (tile.type === "watered" || (tile.type === "growing" && Date.now() - tile.lastWatered < 10000)) {
        ctx.fillStyle = "rgba(33, 150, 243, 0.3)"
        ctx.fillRect(x, y, tileSize, tileSize)
      }
    })
  }

  // Draw crop
  const drawCrop = (ctx: CanvasRenderingContext2D, tile: Tile) => {
    if (!tile.crop) return

    const x = tile.x * gameStateRef.current.tileSize
    const y = tile.y * gameStateRef.current.tileSize
    const size = gameStateRef.current.tileSize

    // Growth percentage
    const growthPercent = tile.growthStage / tile.maxGrowthStage

    // Crop colors
    let color
    switch (tile.crop) {
      case "carrot":
        color = "#FF9800" // Orange
        break
      case "tomato":
        color = "#F44336" // Red
        break
      case "corn":
        color = "#FFEB3B" // Yellow
        break
      case "pumpkin":
        color = "#FF5722" // Deep orange
        break
    }

    // Draw plant stem
    ctx.fillStyle = "#4CAF50" // Green
    ctx.fillRect(x + size * 0.45, y + size * (1 - growthPercent * 0.8), size * 0.1, size * growthPercent * 0.8)

    // Draw leaves
    if (growthPercent > 0.3) {
      ctx.fillStyle = "#81C784" // Light green

      // Left leaf
      ctx.beginPath()
      ctx.ellipse(
        x + size * 0.35,
        y + size * (1 - growthPercent * 0.6),
        size * 0.1 * growthPercent,
        size * 0.05 * growthPercent,
        Math.PI / 4,
        0,
        Math.PI * 2,
      )
      ctx.fill()

      // Right leaf
      ctx.beginPath()
      ctx.ellipse(
        x + size * 0.65,
        y + size * (1 - growthPercent * 0.6),
        size * 0.1 * growthPercent,
        size * 0.05 * growthPercent,
        -Math.PI / 4,
        0,
        Math.PI * 2,
      )
      ctx.fill()
    }

    // Draw fruit/vegetable
    if (growthPercent > 0.5) {
      ctx.fillStyle = color

      if (tile.crop === "carrot") {
        // Carrot (triangle)
        ctx.beginPath()
        ctx.moveTo(x + size * 0.5, y + size * 0.9)
        ctx.lineTo(x + size * (0.5 - 0.15 * growthPercent), y + size * (0.9 - 0.2 * growthPercent))
        ctx.lineTo(x + size * (0.5 + 0.15 * growthPercent), y + size * (0.9 - 0.2 * growthPercent))
        ctx.closePath()
        ctx.fill()
      } else if (tile.crop === "tomato") {
        // Tomato (circle)
        ctx.beginPath()
        ctx.arc(x + size * 0.5, y + size * (1 - growthPercent * 0.4), size * 0.15 * growthPercent, 0, Math.PI * 2)
        ctx.fill()
      } else if (tile.crop === "corn") {
        // Corn (rectangle)
        ctx.fillRect(x + size * 0.4, y + size * (1 - growthPercent * 0.5), size * 0.2, size * 0.3 * growthPercent)
      } else if (tile.crop === "pumpkin") {
        // Pumpkin (ellipse)
        ctx.beginPath()
        ctx.ellipse(
          x + size * 0.5,
          y + size * 0.85,
          size * 0.2 * growthPercent,
          size * 0.15 * growthPercent,
          0,
          0,
          Math.PI * 2,
        )
        ctx.fill()
      }
    }

    // Draw "ready" indicator
    if (tile.type === "ready") {
      ctx.fillStyle = "rgba(255, 255, 255, 0.7)"
      ctx.beginPath()
      ctx.arc(x + size * 0.8, y + size * 0.2, size * 0.15, 0, Math.PI * 2)
      ctx.fill()

      ctx.fillStyle = "#4CAF50"
      ctx.font = `${size * 0.2}px Arial`
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText("✓", x + size * 0.8, y + size * 0.2)
    }
  }

  // Draw weather effects
  const drawWeather = (ctx: CanvasRenderingContext2D) => {
    const { weather } = gameStateRef.current
    const canvas = canvasRef.current
    if (!canvas) return

    if (weather === "rainy") {
      // Draw rain
      ctx.fillStyle = "rgba(33, 150, 243, 0.5)"
      for (let i = 0; i < 100; i++) {
        const x = Math.random() * canvas.width
        const y = Math.random() * canvas.height
        const length = 10 + Math.random() * 10

        ctx.beginPath()
        ctx.moveTo(x, y)
        ctx.lineTo(x - 5, y + length)
        ctx.stroke()
      }
    } else if (weather === "cloudy") {
      // Draw clouds
      ctx.fillStyle = "rgba(255, 255, 255, 0.7)"
      for (let i = 0; i < 5; i++) {
        const x = (i * canvas.width) / 5 + Math.random() * 50
        const y = 20 + Math.random() * 30
        const size = 30 + Math.random() * 20

        // Cloud shape (multiple circles)
        for (let j = 0; j < 5; j++) {
          const cloudX = x + j * 10 - 20
          const cloudY = y + (j % 2 === 0 ? -5 : 5)
          ctx.beginPath()
          ctx.arc(cloudX, cloudY, size / 2, 0, Math.PI * 2)
          ctx.fill()
        }
      }
    }
  }

  // Draw UI
  const drawUI = (ctx: CanvasRenderingContext2D) => {
    const canvas = canvasRef.current
    if (!canvas) return

    // Draw day/night cycle
    const dayPercent = gameStateRef.current.dayTime / gameStateRef.current.dayLength
    const skyColor = getSkyColor(dayPercent)

    ctx.fillStyle = skyColor
    ctx.globalAlpha = 0.2
    ctx.fillRect(0, 0, canvas.width, canvas.height)
    ctx.globalAlpha = 1

    // Draw sun/moon
    const celestialX = canvas.width * dayPercent
    const celestialY = canvas.height * 0.2 * Math.sin(Math.PI * dayPercent) + 20

    if (dayPercent < 0.5) {
      // Sun
      ctx.fillStyle = "#FFD54F"
      ctx.beginPath()
      ctx.arc(celestialX, celestialY, 20, 0, Math.PI * 2)
      ctx.fill()
    } else {
      // Moon
      ctx.fillStyle = "#E0E0E0"
      ctx.beginPath()
      ctx.arc(celestialX, celestialY, 15, 0, Math.PI * 2)
      ctx.fill()
    }
  }

  // Get sky color based on time of day
  const getSkyColor = (dayPercent: number): string => {
    if (dayPercent < 0.25) {
      // Morning
      return "rgba(255, 236, 179, 0.3)"
    } else if (dayPercent < 0.5) {
      // Midday
      return "rgba(179, 229, 252, 0.3)"
    } else if (dayPercent < 0.75) {
      // Evening
      return "rgba(255, 183, 77, 0.3)"
    } else {
      // Night
      return "rgba(25, 25, 112, 0.3)"
    }
  }

  return (
    <div className="relative">
      {/* Game canvas */}
      <canvas ref={canvasRef} className="bg-[#8BC34A] rounded-lg shadow-lg" />

      {/* Game UI overlay */}
      <div className="absolute top-4 left-4 flex items-center space-x-4">
        <Badge className="bg-[#4CAF50] text-white px-3 py-1">Day: {day}/30</Badge>
        <Badge className="bg-[#FF9800] text-white px-3 py-1">Money: ${inventory.money}</Badge>
        <Badge className="bg-[#9C27B0] text-white px-3 py-1">Score: {score}</Badge>
      </div>

      {/* Weather indicator */}
      <div className="absolute top-4 right-4 flex items-center space-x-2">
        <Badge className="bg-[#2196F3] text-white px-3 py-1">
          {gameStateRef.current.weather === "sunny"
            ? "☀️ Sunny"
            : gameStateRef.current.weather === "rainy"
              ? "🌧️ Rainy"
              : "☁️ Cloudy"}
        </Badge>

        <Button
          size="icon"
          variant="outline"
          className="bg-[#1A1145]/50 border-[#3A2A65] text-white hover:bg-[#3A2A65]/50"
          onClick={toggleMute}
        >
          {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
        </Button>

        <Button
          size="icon"
          variant="outline"
          className="bg-[#1A1145]/50 border-[#3A2A65] text-white hover:bg-[#3A2A65]/50"
          onClick={togglePause}
        >
          {gamePaused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
        </Button>

        <Button
          size="icon"
          variant="outline"
          className="bg-[#1A1145]/50 border-[#3A2A65] text-white hover:bg-[#3A2A65]/50"
          onClick={resetGame}
        >
          <RotateCcw className="h-4 w-4" />
        </Button>
      </div>

      {/* Tools */}
      <div className="absolute bottom-4 left-4 flex flex-col space-y-2 bg-[#1A1145]/70 p-2 rounded-lg">
        <div className="text-white text-sm font-bold mb-1">Tools</div>
        <div className="flex space-x-2">
          <Button
            size="sm"
            variant={selectedTool === "hoe" ? "default" : "outline"}
            className={`${selectedTool === "hoe" ? "bg-[#FF9800]" : "bg-[#1A1145]/50 border-[#3A2A65]"} text-white`}
            onClick={() => setSelectedTool("hoe")}
          >
            <Shovel className="h-4 w-4 mr-1" /> Till
          </Button>
          <Button
            size="sm"
            variant={selectedTool === "water" ? "default" : "outline"}
            className={`${selectedTool === "water" ? "bg-[#2196F3]" : "bg-[#1A1145]/50 border-[#3A2A65]"} text-white`}
            onClick={() => setSelectedTool("water")}
          >
            <Droplets className="h-4 w-4 mr-1" /> Water
          </Button>
          <Button
            size="sm"
            variant={selectedTool === "seed" ? "default" : "outline"}
            className={`${selectedTool === "seed" ? "bg-[#4CAF50]" : "bg-[#1A1145]/50 border-[#3A2A65]"} text-white`}
            onClick={() => setSelectedTool("seed")}
          >
            <Seedling className="h-4 w-4 mr-1" /> Plant
          </Button>
          <Button
            size="sm"
            variant={selectedTool === "harvest" ? "default" : "outline"}
            className={`${selectedTool === "harvest" ? "bg-[#9C27B0]" : "bg-[#1A1145]/50 border-[#3A2A65]"} text-white`}
            onClick={() => setSelectedTool("harvest")}
          >
            <Sun className="h-4 w-4 mr-1" /> Harvest
          </Button>
        </div>
      </div>

      {/* Seeds */}
      {selectedTool === "seed" && (
        <div className="absolute bottom-4 left-48 flex flex-col space-y-2 bg-[#1A1145]/70 p-2 rounded-lg">
          <div className="text-white text-sm font-bold mb-1">Seeds</div>
          <div className="flex space-x-2">
            <Button
              size="sm"
              variant={selectedSeed === "carrot" ? "default" : "outline"}
              className={`${selectedSeed === "carrot" ? "bg-[#FF9800]" : "bg-[#1A1145]/50 border-[#3A2A65]"} text-white`}
              onClick={() => setSelectedSeed("carrot")}
            >
              Carrot ({inventory.seeds.carrot})
            </Button>
            <Button
              size="sm"
              variant={selectedSeed === "tomato" ? "default" : "outline"}
              className={`${selectedSeed === "tomato" ? "bg-[#F44336]" : "bg-[#1A1145]/50 border-[#3A2A65]"} text-white`}
              onClick={() => setSelectedSeed("tomato")}
            >
              Tomato ({inventory.seeds.tomato})
            </Button>
            <Button
              size="sm"
              variant={selectedSeed === "corn" ? "default" : "outline"}
              className={`${selectedSeed === "corn" ? "bg-[#FFEB3B]" : "bg-[#1A1145]/50 border-[#3A2A65]"} text-white`}
              onClick={() => setSelectedSeed("corn")}
            >
              Corn ({inventory.seeds.corn})
            </Button>
            <Button
              size="sm"
              variant={selectedSeed === "pumpkin" ? "default" : "outline"}
              className={`${selectedSeed === "pumpkin" ? "bg-[#FF5722]" : "bg-[#1A1145]/50 border-[#3A2A65]"} text-white`}
              onClick={() => setSelectedSeed("pumpkin")}
            >
              Pumpkin ({inventory.seeds.pumpkin})
            </Button>
          </div>
        </div>
      )}

      {/* Shop */}
      <div className="absolute bottom-4 right-4 flex flex-col space-y-2 bg-[#1A1145]/70 p-2 rounded-lg">
        <div className="text-white text-sm font-bold mb-1">Shop</div>
        <div className="grid grid-cols-2 gap-2">
          <Button
            size="sm"
            variant="outline"
            className="bg-[#1A1145]/50 border-[#3A2A65] text-white"
            onClick={() => buySeed("carrot")}
          >
            Carrot ($5)
          </Button>
          <Button
            size="sm"
            variant="outline"
            className="bg-[#1A1145]/50 border-[#3A2A65] text-white"
            onClick={() => buySeed("tomato")}
          >
            Tomato ($8)
          </Button>
          <Button
            size="sm"
            variant="outline"
            className="bg-[#1A1145]/50 border-[#3A2A65] text-white"
            onClick={() => buySeed("corn")}
          >
            Corn ($12)
          </Button>
          <Button
            size="sm"
            variant="outline"
            className="bg-[#1A1145]/50 border-[#3A2A65] text-white"
            onClick={() => buySeed("pumpkin")}
          >
            Pumpkin ($20)
          </Button>
        </div>
      </div>

      {/* Inventory */}
      <div className="absolute top-16 right-4 flex flex-col space-y-2 bg-[#1A1145]/70 p-2 rounded-lg">
        <div className="text-white text-sm font-bold mb-1">Harvested</div>
        <div className="text-white text-xs">
          <div>Carrot: {inventory.crops.carrot}</div>
          <div>Tomato: {inventory.crops.tomato}</div>
          <div>Corn: {inventory.crops.corn}</div>
          <div>Pumpkin: {inventory.crops.pumpkin}</div>
        </div>
      </div>

      {/* Game start overlay */}
      {!gameStarted && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#0F0B2A]/80 rounded-lg">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4 text-[#4CAF50]">Verdant Valley</h2>
            <p className="text-[#E0E0FF] mb-6 max-w-md">
              Build your dream farm in this relaxing farming simulator. Till the soil, plant seeds, water your crops,
              and harvest them when they're ready. Complete as many harvests as you can in 30 days!
            </p>
            <Button
              onClick={startGame}
              className="bg-gradient-to-r from-[#4CAF50] to-[#8BC34A] text-white font-bold hover:from-[#43A047] hover:to-[#7CB342]"
            >
              Start Game
            </Button>
          </div>
        </div>
      )}

      {/* Game over overlay */}
      {gameOver && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#0F0B2A]/80 rounded-lg">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4 text-[#4CAF50]">Game Over</h2>
            <p className="text-2xl text-[#E0E0FF] mb-2">Final Score: {score}</p>
            <p className="text-[#E0E0FF] mb-6">You've completed {day} days of farming!</p>
            <Button
              onClick={resetGame}
              className="bg-gradient-to-r from-[#4CAF50] to-[#8BC34A] text-white font-bold hover:from-[#43A047] hover:to-[#7CB342]"
            >
              Play Again
            </Button>
          </div>
        </div>
      )}

      {/* Pause overlay */}
      {gameStarted && gamePaused && !gameOver && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#0F0B2A]/80 rounded-lg">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4 text-[#4CAF50]">Game Paused</h2>
            <Button
              onClick={togglePause}
              className="bg-gradient-to-r from-[#4CAF50] to-[#8BC34A] text-white font-bold hover:from-[#43A047] hover:to-[#7CB342]"
            >
              Resume
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}
