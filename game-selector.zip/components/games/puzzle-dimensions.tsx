"use client"

import { useEffect, useRef, useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Play, Pause, RotateCcw, Volume2, VolumeX, RefreshCw } from "lucide-react"

interface PuzzlePiece {
  id: number
  x: number
  y: number
  z: number
  width: number
  height: number
  depth: number
  color: string
  rotation: number
  selected: boolean
  solved: boolean
  targetX: number
  targetY: number
  targetZ: number
  targetRotation: number
}

export default function PuzzleDimensionsGame() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [gameStarted, setGameStarted] = useState(false)
  const [gamePaused, setGamePaused] = useState(false)
  const [gameOver, setGameOver] = useState(false)
  const [score, setScore] = useState(0)
  const [level, setLevel] = useState(1)
  const [timeLeft, setTimeLeft] = useState(120)
  const [muted, setMuted] = useState(false)
  const [perspective, setPerspective] = useState<"front" | "top" | "side">("front")

  // Game state
  const gameStateRef = useRef({
    pieces: [] as PuzzlePiece[],
    mouse: {
      x: 0,
      y: 0,
      clicked: false,
      dragging: false,
    },
    camera: {
      rotationX: 0,
      rotationY: 0,
      zoom: 1,
    },
    selectedPieceId: null as number | null,
    gameTime: 0,
    score: 0,
    nextId: 1,
  })

  // Initialize game
  const initializeGame = () => {
    if (!canvasRef.current) return

    const canvas = canvasRef.current
    const width = canvas.width
    const height = canvas.height

    // Create puzzle pieces
    const pieces: PuzzlePiece[] = []
    const colors = ["#FF2D95", "#00FFFF", "#9D00FF", "#FFFF00", "#00FF80"]

    // Create different shapes based on level
    const pieceCount = 3 + level

    for (let i = 0; i < pieceCount; i++) {
      const size = 30 + Math.random() * 20
      const depth = 20 + Math.random() * 30

      // Random position within canvas bounds
      const x = 100 + Math.random() * (width - 200)
      const y = 100 + Math.random() * (height - 200)
      const z = Math.random() * 100

      // Target position (solution)
      const targetX = width / 2 - (pieceCount * 30) / 2 + i * 30
      const targetY = height / 2
      const targetZ = 50

      pieces.push({
        id: gameStateRef.current.nextId++,
        x,
        y,
        z,
        width: size,
        height: size,
        depth,
        color: colors[i % colors.length],
        rotation: Math.random() * Math.PI * 2,
        selected: false,
        solved: false,
        targetX,
        targetY,
        targetZ,
        targetRotation: 0,
      })
    }

    gameStateRef.current.pieces = pieces
    setTimeLeft(120)
    setScore(0)
    gameStateRef.current.score = 0
  }

  // Start game
  const startGame = () => {
    setGameStarted(true)
    setGameOver(false)
    setLevel(1)
    gameStateRef.current.nextId = 1
    gameStateRef.current.pieces = []
    gameStateRef.current.gameTime = 0
    gameStateRef.current.camera = {
      rotationX: 0,
      rotationY: 0,
      zoom: 1,
    }

    initializeGame()
  }

  // Reset game
  const resetGame = () => {
    setGameStarted(false)
    setGameOver(false)
    setGamePaused(false)
  }

  // Toggle pause
  const togglePause = () => {
    setGamePaused(!gamePaused)
  }

  // Toggle mute
  const toggleMute = () => {
    setMuted(!muted)
  }

  // Change perspective
  const changePerspective = () => {
    if (perspective === "front") {
      setPerspective("top")
      gameStateRef.current.camera.rotationX = Math.PI / 2
      gameStateRef.current.camera.rotationY = 0
    } else if (perspective === "top") {
      setPerspective("side")
      gameStateRef.current.camera.rotationX = 0
      gameStateRef.current.camera.rotationY = Math.PI / 2
    } else {
      setPerspective("front")
      gameStateRef.current.camera.rotationX = 0
      gameStateRef.current.camera.rotationY = 0
    }
  }

  // Initialize canvas and event listeners
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    // Set canvas dimensions
    canvas.width = 800
    canvas.height = 600

    // Event listeners
    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect()
      const mouseX = e.clientX - rect.left
      const mouseY = e.clientY - rect.top

      if (gameStateRef.current.mouse.dragging && gameStateRef.current.selectedPieceId !== null) {
        // Move selected piece
        const selectedPiece = gameStateRef.current.pieces.find((p) => p.id === gameStateRef.current.selectedPieceId)
        if (selectedPiece) {
          selectedPiece.x += mouseX - gameStateRef.current.mouse.x
          selectedPiece.y += mouseY - gameStateRef.current.mouse.y
        }
      }

      gameStateRef.current.mouse.x = mouseX
      gameStateRef.current.mouse.y = mouseY
    }

    const handleMouseDown = () => {
      gameStateRef.current.mouse.clicked = true

      // Check if clicked on a piece
      const { pieces, mouse } = gameStateRef.current

      for (const piece of pieces) {
        // Simple 2D hit test (perspective dependent)
        let hit = false

        if (perspective === "front") {
          // Front view - check x, y
          const dx = mouse.x - piece.x
          const dy = mouse.y - piece.y
          hit = Math.abs(dx) < piece.width / 2 && Math.abs(dy) < piece.height / 2
        } else if (perspective === "top") {
          // Top view - check x, z
          const dx = mouse.x - piece.x
          const dz = mouse.y - piece.z // z is mapped to y in top view
          hit = Math.abs(dx) < piece.width / 2 && Math.abs(dz) < piece.depth / 2
        } else {
          // Side view - check z, y
          const dz = mouse.x - piece.z // z is mapped to x in side view
          const dy = mouse.y - piece.y
          hit = Math.abs(dz) < piece.depth / 2 && Math.abs(dy) < piece.height / 2
        }

        if (hit) {
          // Select piece
          pieces.forEach((p) => (p.selected = false))
          piece.selected = true
          gameStateRef.current.selectedPieceId = piece.id
          gameStateRef.current.mouse.dragging = true
          break
        }
      }
    }

    const handleMouseUp = () => {
      gameStateRef.current.mouse.clicked = false
      gameStateRef.current.mouse.dragging = false

      // Check if piece is close to target
      if (gameStateRef.current.selectedPieceId !== null) {
        const selectedPiece = gameStateRef.current.pieces.find((p) => p.id === gameStateRef.current.selectedPieceId)
        if (selectedPiece) {
          const dx = selectedPiece.x - selectedPiece.targetX
          const dy = selectedPiece.y - selectedPiece.targetY
          const dz = selectedPiece.z - selectedPiece.targetZ
          const distance = Math.sqrt(dx * dx + dy * dy + dz * dz)

          if (distance < 30) {
            // Snap to target
            selectedPiece.x = selectedPiece.targetX
            selectedPiece.y = selectedPiece.targetY
            selectedPiece.z = selectedPiece.targetZ
            selectedPiece.rotation = selectedPiece.targetRotation
            selectedPiece.solved = true

            // Play sound
            if (!muted) {
              const snapSound = new Audio()
              snapSound.src =
                "data:audio/wav;base64,UklGRiQDAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YQADAAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wA"
              snapSound.volume = 0.3
              snapSound.play()
            }

            // Check if all pieces are solved
            if (gameStateRef.current.pieces.every((p) => p.solved)) {
              // Level complete
              gameStateRef.current.score += 100 + timeLeft * 10
              setScore(gameStateRef.current.score)

              // Next level
              setLevel(level + 1)
              initializeGame()
            }
          }
        }
      }

      gameStateRef.current.selectedPieceId = null
    }

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === " ") {
        changePerspective()
      } else if (e.key === "ArrowUp" || e.key === "ArrowDown" || e.key === "ArrowLeft" || e.key === "ArrowRight") {
        // Move selected piece
        if (gameStateRef.current.selectedPieceId !== null) {
          const selectedPiece = gameStateRef.current.pieces.find((p) => p.id === gameStateRef.current.selectedPieceId)
          if (selectedPiece) {
            const moveAmount = 10

            if (perspective === "front") {
              if (e.key === "ArrowUp") selectedPiece.y -= moveAmount
              if (e.key === "ArrowDown") selectedPiece.y += moveAmount
              if (e.key === "ArrowLeft") selectedPiece.x -= moveAmount
              if (e.key === "ArrowRight") selectedPiece.x += moveAmount
            } else if (perspective === "top") {
              if (e.key === "ArrowUp") selectedPiece.z -= moveAmount
              if (e.key === "ArrowDown") selectedPiece.z += moveAmount
              if (e.key === "ArrowLeft") selectedPiece.x -= moveAmount
              if (e.key === "ArrowRight") selectedPiece.x += moveAmount
            } else {
              if (e.key === "ArrowUp") selectedPiece.y -= moveAmount
              if (e.key === "ArrowDown") selectedPiece.y += moveAmount
              if (e.key === "ArrowLeft") selectedPiece.z -= moveAmount
              if (e.key === "ArrowRight") selectedPiece.z += moveAmount
            }
          }
        }
      }
    }

    canvas.addEventListener("mousemove", handleMouseMove)
    canvas.addEventListener("mousedown", handleMouseDown)
    canvas.addEventListener("mouseup", handleMouseUp)
    window.addEventListener("keydown", handleKeyDown)

    return () => {
      canvas.removeEventListener("mousemove", handleMouseMove)
      canvas.removeEventListener("mousedown", handleMouseDown)
      canvas.removeEventListener("mouseup", handleMouseUp)
      window.removeEventListener("keydown", handleKeyDown)
    }
  }, [perspective, level, muted])

  // Game timer
  useEffect(() => {
    if (!gameStarted || gamePaused || gameOver) return

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          // Time's up
          setGameOver(true)
          clearInterval(timer)
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [gameStarted, gamePaused, gameOver])

  // Game loop
  useEffect(() => {
    if (!gameStarted || gamePaused || gameOver) return

    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    let animationFrameId: number
    let lastTime = 0

    const gameLoop = (timestamp: number) => {
      if (!gameStarted || gamePaused || gameOver) return

      const deltaTime = timestamp - lastTime
      lastTime = timestamp

      gameStateRef.current.gameTime += deltaTime

      // Clear canvas
      ctx.fillStyle = "#0F0B2A"
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      // Draw grid based on perspective
      drawGrid(ctx, canvas.width, canvas.height)

      // Draw puzzle pieces
      drawPieces(ctx)

      // Draw target outlines
      drawTargets(ctx)

      animationFrameId = requestAnimationFrame(gameLoop)
    }

    animationFrameId = requestAnimationFrame(gameLoop)

    return () => {
      cancelAnimationFrame(animationFrameId)
    }
  }, [gameStarted, gamePaused, gameOver, perspective])

  // Draw grid
  const drawGrid = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    ctx.strokeStyle = "rgba(102, 51, 153, 0.1)"
    ctx.lineWidth = 1

    if (perspective === "front" || perspective === "side") {
      // Horizontal lines
      for (let y = 0; y < height; y += 40) {
        ctx.beginPath()
        ctx.moveTo(0, y)
        ctx.lineTo(width, y)
        ctx.stroke()
      }

      // Vertical lines
      for (let x = 0; x < width; x += 40) {
        ctx.beginPath()
        ctx.moveTo(x, 0)
        ctx.lineTo(x, height)
        ctx.stroke()
      }
    } else {
      // Top view - draw a perspective grid
      const gridSize = 40
      const gridExtent = 10

      for (let i = -gridExtent; i <= gridExtent; i++) {
        ctx.beginPath()
        ctx.moveTo(width / 2 + i * gridSize, 0)
        ctx.lineTo(width / 2 + i * gridSize, height)
        ctx.stroke()

        ctx.beginPath()
        ctx.moveTo(0, height / 2 + i * gridSize)
        ctx.lineTo(width, height / 2 + i * gridSize)
        ctx.stroke()
      }
    }
  }

  // Draw puzzle pieces
  const drawPieces = (ctx: CanvasRenderingContext2D) => {
    // Sort pieces by z-index for proper rendering
    const sortedPieces = [...gameStateRef.current.pieces].sort((a, b) => {
      if (perspective === "front") {
        return a.z - b.z
      } else if (perspective === "top") {
        return a.y - b.y
      } else {
        return a.x - b.x
      }
    })

    sortedPieces.forEach((piece) => {
      ctx.save()

      // Apply perspective transformation
      if (perspective === "front") {
        ctx.translate(piece.x, piece.y)
        ctx.rotate(piece.rotation)

        // Draw piece
        ctx.fillStyle = piece.color
        ctx.globalAlpha = 0.8

        // Draw 3D effect
        ctx.beginPath()
        ctx.rect(-piece.width / 2, -piece.height / 2, piece.width, piece.height)
        ctx.fill()

        // Add shadow/highlight for 3D effect
        ctx.fillStyle = "rgba(0, 0, 0, 0.2)"
        ctx.beginPath()
        ctx.rect(-piece.width / 2, -piece.height / 2, piece.width, 5)
        ctx.fill()

        ctx.fillStyle = "rgba(255, 255, 255, 0.2)"
        ctx.beginPath()
        ctx.rect(-piece.width / 2, piece.height / 2 - 5, piece.width, 5)
        ctx.fill()
      } else if (perspective === "top") {
        ctx.translate(piece.x, piece.z) // z is mapped to y in top view
        ctx.rotate(piece.rotation)

        // Draw piece from top view
        ctx.fillStyle = piece.color
        ctx.globalAlpha = 0.8

        ctx.beginPath()
        ctx.rect(-piece.width / 2, -piece.depth / 2, piece.width, piece.depth)
        ctx.fill()
      } else {
        ctx.translate(piece.z, piece.y) // z is mapped to x in side view
        ctx.rotate(piece.rotation)

        // Draw piece from side view
        ctx.fillStyle = piece.color
        ctx.globalAlpha = 0.8

        ctx.beginPath()
        ctx.rect(-piece.depth / 2, -piece.height / 2, piece.depth, piece.height)
        ctx.fill()
      }

      // Draw selection indicator
      if (piece.selected) {
        ctx.strokeStyle = "#FFFF00"
        ctx.lineWidth = 2

        if (perspective === "front") {
          ctx.strokeRect(-piece.width / 2 - 5, -piece.height / 2 - 5, piece.width + 10, piece.height + 10)
        } else if (perspective === "top") {
          ctx.strokeRect(-piece.width / 2 - 5, -piece.depth / 2 - 5, piece.width + 10, piece.depth + 10)
        } else {
          ctx.strokeRect(-piece.depth / 2 - 5, -piece.height / 2 - 5, piece.depth + 10, piece.height + 10)
        }
      }

      ctx.restore()
    })
  }

  // Draw target outlines
  const drawTargets = (ctx: CanvasRenderingContext2D) => {
    gameStateRef.current.pieces.forEach((piece) => {
      if (!piece.solved) {
        ctx.save()

        // Apply perspective transformation
        if (perspective === "front") {
          ctx.translate(piece.targetX, piece.targetY)
          ctx.rotate(piece.targetRotation)

          // Draw target outline
          ctx.strokeStyle = piece.color
          ctx.lineWidth = 2
          ctx.setLineDash([5, 5])
          ctx.strokeRect(-piece.width / 2, -piece.height / 2, piece.width, piece.height)
        } else if (perspective === "top") {
          ctx.translate(piece.targetX, piece.targetZ) // z is mapped to y in top view
          ctx.rotate(piece.targetRotation)

          ctx.strokeStyle = piece.color
          ctx.lineWidth = 2
          ctx.setLineDash([5, 5])
          ctx.strokeRect(-piece.width / 2, -piece.depth / 2, piece.width, piece.depth)
        } else {
          ctx.translate(piece.targetZ, piece.targetY) // z is mapped to x in side view
          ctx.rotate(piece.targetRotation)

          ctx.strokeStyle = piece.color
          ctx.lineWidth = 2
          ctx.setLineDash([5, 5])
          ctx.strokeRect(-piece.depth / 2, -piece.height / 2, piece.depth, piece.height)
        }

        ctx.restore()
      }
    })
  }

  return (
    <div className="relative">
      {/* Game canvas */}
      <canvas ref={canvasRef} className="bg-[#0F0B2A] rounded-lg shadow-lg" width={800} height={600} />

      {/* Game UI overlay */}
      <div className="absolute top-4 left-4 flex items-center space-x-4">
        <Badge className="bg-[#00FFFF] text-black px-3 py-1">Score: {score}</Badge>
        <Badge className="bg-[#FF2D95] text-white px-3 py-1">Level: {level}</Badge>
        <Badge className="bg-[#FFFF00] text-black px-3 py-1">
          Time: {Math.floor(timeLeft / 60)}:{(timeLeft % 60).toString().padStart(2, "0")}
        </Badge>
      </div>

      {/* Game controls */}
      <div className="absolute top-4 right-4 flex items-center space-x-2">
        <Button
          size="icon"
          variant="outline"
          className="bg-[#1A1145]/50 border-[#3A2A65] text-white hover:bg-[#3A2A65]/50"
          onClick={changePerspective}
        >
          <RefreshCw className="h-4 w-4" />
        </Button>

        <Button
          size="icon"
          variant="outline"
          className="bg-[#1A1145]/50 border-[#3A2A65] text-white hover:bg-[#3A2A65]/50"
          onClick={toggleMute}
        >
          {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
        </Button>

        <Button
          size="icon"
          variant="outline"
          className="bg-[#1A1145]/50 border-[#3A2A65] text-white hover:bg-[#3A2A65]/50"
          onClick={togglePause}
        >
          {gamePaused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
        </Button>

        <Button
          size="icon"
          variant="outline"
          className="bg-[#1A1145]/50 border-[#3A2A65] text-white hover:bg-[#3A2A65]/50"
          onClick={resetGame}
        >
          <RotateCcw className="h-4 w-4" />
        </Button>
      </div>

      {/* Perspective indicator */}
      <div className="absolute bottom-4 left-4">
        <Badge className="bg-[#9D00FF] text-white px-3 py-1">
          View: {perspective.charAt(0).toUpperCase() + perspective.slice(1)}
        </Badge>
        <p className="text-[#E0E0FF] text-xs mt-1">Press SPACE to change view</p>
      </div>

      {/* Game start overlay */}
      {!gameStarted && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#0F0B2A]/80 rounded-lg">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4 text-[#00FFFF]">Puzzle Dimensions</h2>
            <p className="text-[#E0E0FF] mb-6 max-w-md">
              Solve the 3D puzzle by moving pieces to their target positions. Change perspective with SPACE and move
              pieces with arrow keys or mouse.
            </p>
            <Button
              onClick={startGame}
              className="bg-gradient-to-r from-[#9D00FF] to-[#FF2D95] text-white font-bold hover:from-[#B347FF] hover:to-[#FF5CAD]"
            >
              Start Game
            </Button>
          </div>
        </div>
      )}

      {/* Game over overlay */}
      {gameOver && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#0F0B2A]/80 rounded-lg">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4 text-[#00FFFF]">Game Over</h2>
            <p className="text-2xl text-[#E0E0FF] mb-2">Final Score: {score}</p>
            <p className="text-[#E0E0FF] mb-6">You reached level {level}!</p>
            <Button
              onClick={resetGame}
              className="bg-gradient-to-r from-[#9D00FF] to-[#FF2D95] text-white font-bold hover:from-[#B347FF] hover:to-[#FF5CAD]"
            >
              Play Again
            </Button>
          </div>
        </div>
      )}

      {/* Pause overlay */}
      {gameStarted && gamePaused && !gameOver && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#0F0B2A]/80 rounded-lg">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4 text-[#00FFFF]">Game Paused</h2>
            <Button
              onClick={togglePause}
              className="bg-gradient-to-r from-[#9D00FF] to-[#FF2D95] text-white font-bold hover:from-[#B347FF] hover:to-[#FF5CAD]"
            >
              Resume
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}
