"use client"

import { useEffect, useRef, useState } from "react"
import { Button } from "@/components/ui/button"
import { Play, Pause, RotateCcw, Volume2, VolumeX, Sword, Scroll, Backpack } from "lucide-react"

interface Player {
  x: number
  y: number
  size: number
  speed: number
  health: number
  maxHealth: number
  mana: number
  maxMana: number
  stamina: number
  maxStamina: number
  level: number
  experience: number
  experienceToNextLevel: number
  gold: number
  inventory: Item[]
  equipment: Equipment
  spells: Spell[]
  direction: "up" | "down" | "left" | "right"
  isMoving: boolean
  isAttacking: boolean
  lastAttack: number
  attackCooldown: number
}

interface NPC {
  id: number
  name: string
  x: number
  y: number
  size: number
  type: "friendly" | "enemy" | "merchant"
  health: number
  maxHealth: number
  damage: number
  defense: number
  speed: number
  experience: number
  gold: number
  drops: Item[]
  dialogue: string[]
  isMoving: boolean
  direction: "up" | "down" | "left" | "right"
  state: "idle" | "following" | "attacking" | "fleeing"
  target: { x: number; y: number } | null
  aggroRange: number
  attackRange: number
  lastAttack: number
  attackCooldown: number
}

interface Item {
  id: number
  name: string
  type: "weapon" | "armor" | "potion" | "scroll" | "quest" | "misc"
  value: number
  description: string
  icon: string
  stats?: {
    damage?: number
    defense?: number
    health?: number
    mana?: number
    stamina?: number
  }
  effect?: () => void
}

interface Equipment {
  weapon: Item | null
  armor: Item | null
  accessory: Item | null
}

interface Spell {
  id: number
  name: string
  manaCost: number
  cooldown: number
  lastCast: number
  damage: number
  range: number
  areaOfEffect: number
  icon: string
  description: string
  effect: "damage" | "heal" | "buff" | "debuff"
}

interface Projectile {
  id: number
  x: number
  y: number
  targetX: number
  targetY: number
  speed: number
  damage: number
  size: number
  color: string
  isPlayerProjectile: boolean
  spellId?: number
}

interface Effect {
  id: number
  x: number
  y: number
  size: number
  color: string
  duration: number
  startTime: number
  type: "damage" | "heal" | "buff" | "debuff"
}

interface Quest {
  id: number
  title: string
  description: string
  objectives: {
    type: "kill" | "collect" | "talk"
    target: string
    count: number
    current: number
  }[]
  rewards: {
    experience: number
    gold: number
    items: Item[]
  }
  isCompleted: boolean
  isActive: boolean
}

interface MapTile {
  type: "grass" | "water" | "mountain" | "forest" | "path" | "house" | "cave" | "chest"
  isWalkable: boolean
  isInteractable: boolean
  interaction?: () => void
}

export default function MysticRealmsGame() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [gameStarted, setGameStarted] = useState(false)
  const [gamePaused, setGamePaused] = useState(false)
  const [gameOver, setGameOver] = useState(false)
  const [score, setScore] = useState(0)
  const [showInventory, setShowInventory] = useState(false)
  const [showQuests, setShowQuests] = useState(false)
  const [showDialogue, setShowDialogue] = useState(false)
  const [currentDialogue, setCurrentDialogue] = useState<string[]>([])
  const [currentDialogueIndex, setCurrentDialogueIndex] = useState(0)
  const [currentNPC, setCurrentNPC] = useState<NPC | null>(null)
  const [selectedSpell, setSelectedSpell] = useState<number | null>(null)
  const [muted, setMuted] = useState(false)

  // Game state
  const gameStateRef = useRef({
    player: {
      x: 400,
      y: 300,
      size: 20,
      speed: 3,
      health: 100,
      maxHealth: 100,
      mana: 50,
      maxMana: 50,
      stamina: 100,
      maxStamina: 100,
      level: 1,
      experience: 0,
      experienceToNextLevel: 100,
      gold: 50,
      inventory: [] as Item[],
      equipment: {
        weapon: null,
        armor: null,
        accessory: null,
      } as Equipment,
      spells: [
        {
          id: 1,
          name: "Fireball",
          manaCost: 10,
          cooldown: 2000,
          lastCast: 0,
          damage: 20,
          range: 200,
          areaOfEffect: 50,
          icon: "🔥",
          description: "Launches a ball of fire that explodes on impact",
          effect: "damage",
        },
        {
          id: 2,
          name: "Heal",
          manaCost: 15,
          cooldown: 5000,
          lastCast: 0,
          damage: -30, // Negative damage = healing
          range: 0,
          areaOfEffect: 0,
          icon: "💚",
          description: "Restores health",
          effect: "heal",
        },
      ] as Spell[],
      direction: "down" as "up" | "down" | "left" | "right",
      isMoving: false,
      isAttacking: false,
      lastAttack: 0,
      attackCooldown: 500,
    } as Player,
    npcs: [] as NPC[],
    projectiles: [] as Projectile[],
    effects: [] as Effect[],
    quests: [] as Quest[],
    map: [] as MapTile[][],
    mapWidth: 800,
    mapHeight: 600,
    tileSize: 40,
    camera: {
      x: 0,
      y: 0,
    },
    gameTime: 0,
    nextId: 1,
    nextProjectileId: 1,
    nextEffectId: 1,
    keys: {
      w: false,
      a: false,
      s: false,
      d: false,
      space: false,
    },
    mouse: {
      x: 0,
      y: 0,
      clicked: false,
    },
  })

  // Initialize game
  const initializeGame = () => {
    // Initialize player
    gameStateRef.current.player = {
      x: 400,
      y: 300,
      size: 20,
      speed: 3,
      health: 100,
      maxHealth: 100,
      mana: 50,
      maxMana: 50,
      stamina: 100,
      maxStamina: 100,
      level: 1,
      experience: 0,
      experienceToNextLevel: 100,
      gold: 50,
      inventory: [
        {
          id: 1,
          name: "Health Potion",
          type: "potion",
          value: 10,
          description: "Restores 30 health",
          icon: "🧪",
          stats: {
            health: 30,
          },
          effect: () => {
            const player = gameStateRef.current.player
            player.health = Math.min(player.maxHealth, player.health + 30)
            createEffect(player.x, player.y, 30, "#00FF00", 1000, "heal")
            playSound("potion")
          },
        },
        {
          id: 2,
          name: "Mana Potion",
          type: "potion",
          value: 15,
          description: "Restores 20 mana",
          icon: "🧪",
          stats: {
            mana: 20,
          },
          effect: () => {
            const player = gameStateRef.current.player
            player.mana = Math.min(player.maxMana, player.mana + 20)
            createEffect(player.x, player.y, 30, "#0000FF", 1000, "buff")
            playSound("potion")
          },
        },
      ],
      equipment: {
        weapon: {
          id: 3,
          name: "Wooden Sword",
          type: "weapon",
          value: 25,
          description: "A basic wooden sword",
          icon: "🗡️",
          stats: {
            damage: 5,
          },
        },
        armor: {
          id: 4,
          name: "Leather Armor",
          type: "armor",
          value: 30,
          description: "Basic leather armor",
          icon: "🛡️",
          stats: {
            defense: 3,
          },
        },
        accessory: null,
      },
      spells: [
        {
          id: 1,
          name: "Fireball",
          manaCost: 10,
          cooldown: 2000,
          lastCast: 0,
          damage: 20,
          range: 200,
          areaOfEffect: 50,
          icon: "🔥",
          description: "Launches a ball of fire that explodes on impact",
          effect: "damage",
        },
        {
          id: 2,
          name: "Heal",
          manaCost: 15,
          cooldown: 5000,
          lastCast: 0,
          damage: -30, // Negative damage = healing
          range: 0,
          areaOfEffect: 0,
          icon: "💚",
          description: "Restores health",
          effect: "heal",
        },
      ],
      direction: "down",
      isMoving: false,
      isAttacking: false,
      lastAttack: 0,
      attackCooldown: 500,
    }

    // Initialize NPCs
    gameStateRef.current.npcs = [
      // Friendly NPC
      {
        id: gameStateRef.current.nextId++,
        name: "Village Elder",
        x: 300,
        y: 200,
        size: 20,
        type: "friendly",
        health: 100,
        maxHealth: 100,
        damage: 0,
        defense: 0,
        speed: 1,
        experience: 0,
        gold: 0,
        drops: [],
        dialogue: [
          "Welcome, traveler! Our village has been plagued by monsters lately.",
          "Could you help us by clearing out the nearby cave?",
          "I'll reward you handsomely if you can defeat the monsters.",
        ],
        isMoving: false,
        direction: "down",
        state: "idle",
        target: null,
        aggroRange: 0,
        attackRange: 0,
        lastAttack: 0,
        attackCooldown: 0,
      },
      // Merchant NPC
      {
        id: gameStateRef.current.nextId++,
        name: "Merchant",
        x: 500,
        y: 200,
        size: 20,
        type: "merchant",
        health: 100,
        maxHealth: 100,
        damage: 0,
        defense: 0,
        speed: 1,
        experience: 0,
        gold: 0,
        drops: [],
        dialogue: [
          "Greetings! I have many fine wares for sale.",
          "Would you like to see my inventory?",
          "I buy and sell all sorts of items.",
        ],
        isMoving: false,
        direction: "down",
        state: "idle",
        target: null,
        aggroRange: 0,
        attackRange: 0,
        lastAttack: 0,
        attackCooldown: 0,
      },
      // Enemy NPC
      {
        id: gameStateRef.current.nextId++,
        name: "Goblin",
        x: 600,
        y: 400,
        size: 18,
        type: "enemy",
        health: 50,
        maxHealth: 50,
        damage: 5,
        defense: 2,
        speed: 2,
        experience: 20,
        gold: 10,
        drops: [
          {
            id: 5,
            name: "Goblin Ear",
            type: "quest",
            value: 5,
            description: "A trophy from a defeated goblin",
            icon: "👂",
          },
        ],
        dialogue: [],
        isMoving: true,
        direction: "left",
        state: "idle",
        target: null,
        aggroRange: 150,
        attackRange: 30,
        lastAttack: 0,
        attackCooldown: 1000,
      },
      // Another enemy NPC
      {
        id: gameStateRef.current.nextId++,
        name: "Wolf",
        x: 200,
        y: 450,
        size: 16,
        type: "enemy",
        health: 30,
        maxHealth: 30,
        damage: 7,
        defense: 1,
        speed: 3,
        experience: 15,
        gold: 5,
        drops: [
          {
            id: 6,
            name: "Wolf Pelt",
            type: "misc",
            value: 8,
            description: "A pelt from a defeated wolf",
            icon: "🐺",
          },
        ],
        dialogue: [],
        isMoving: true,
        direction: "right",
        state: "idle",
        target: null,
        aggroRange: 180,
        attackRange: 25,
        lastAttack: 0,
        attackCooldown: 800,
      },
    ]

    // Initialize quests
    gameStateRef.current.quests = [
      {
        id: 1,
        title: "Clear the Cave",
        description: "The Village Elder has asked you to clear out the nearby cave of monsters.",
        objectives: [
          {
            type: "kill",
            target: "Goblin",
            count: 5,
            current: 0,
          },
          {
            type: "kill",
            target: "Wolf",
            count: 3,
            current: 0,
          },
        ],
        rewards: {
          experience: 100,
          gold: 50,
          items: [
            {
              id: 7,
              name: "Iron Sword",
              type: "weapon",
              value: 50,
              description: "A sturdy iron sword",
              icon: "⚔️",
              stats: {
                damage: 10,
              },
            },
          ],
        },
        isCompleted: false,
        isActive: false,
      },
    ]

    // Initialize projectiles and effects
    gameStateRef.current.projectiles = []
    gameStateRef.current.effects = []

    // Initialize map (simple for now)
    const mapWidth = Math.ceil(gameStateRef.current.mapWidth / gameStateRef.current.tileSize)
    const mapHeight = Math.ceil(gameStateRef.current.mapHeight / gameStateRef.current.tileSize)
    const map: MapTile[][] = []

    for (let y = 0; y < mapHeight; y++) {
      const row: MapTile[] = []
      for (let x = 0; x < mapWidth; x++) {
        // Default to grass
        let tile: MapTile = {
          type: "grass",
          isWalkable: true,
          isInteractable: false,
        }

        // Add some variety
        if (Math.random() < 0.05) {
          tile = {
            type: "forest",
            isWalkable: false,
            isInteractable: false,
          }
        } else if (Math.random() < 0.03) {
          tile = {
            type: "water",
            isWalkable: false,
            isInteractable: false,
          }
        } else if (Math.random() < 0.02) {
          tile = {
            type: "mountain",
            isWalkable: false,
            isInteractable: false,
          }
        } else if (Math.random() < 0.01) {
          tile = {
            type: "chest",
            isWalkable: false,
            isInteractable: true,
            interaction: () => {
              // Open chest
              const randomGold = Math.floor(Math.random() * 20) + 10
              gameStateRef.current.player.gold += randomGold

              // Random chance for an item
              if (Math.random() < 0.5) {
                const items = [
                  {
                    id: gameStateRef.current.nextId++,
                    name: "Health Potion",
                    type: "potion",
                    value: 10,
                    description: "Restores 30 health",
                    icon: "🧪",
                    stats: {
                      health: 30,
                    },
                    effect: () => {
                      const player = gameStateRef.current.player
                      player.health = Math.min(player.maxHealth, player.health + 30)
                      createEffect(player.x, player.y, 30, "#00FF00", 1000, "heal")
                      playSound("potion")
                    },
                  },
                  {
                    id: gameStateRef.current.nextId++,
                    name: "Mana Potion",
                    type: "potion",
                    value: 15,
                    description: "Restores 20 mana",
                    icon: "🧪",
                    stats: {
                      mana: 20,
                    },
                    effect: () => {
                      const player = gameStateRef.current.player
                      player.mana = Math.min(player.maxMana, player.mana + 20)
                      createEffect(player.x, player.y, 30, "#0000FF", 1000, "buff")
                      playSound("potion")
                    },
                  },
                ]

                const randomItem = items[Math.floor(Math.random() * items.length)]
                gameStateRef.current.player.inventory.push(randomItem)
              }

              // Create effect
              createEffect(
                x * gameStateRef.current.tileSize + gameStateRef.current.tileSize / 2,
                y * gameStateRef.current.tileSize + gameStateRef.current.tileSize / 2,
                30,
                "#FFFF00",
                1000,
                "buff",
              )

              // Play sound
              playSound("chest")

              // Remove chest
              map[y][x] = {
                type: "grass",
                isWalkable: true,
                isInteractable: false,
              }
            },
          }
        }

        row.push(tile)
      }
      map.push(row)
    }

    gameStateRef.current.map = map

    // Reset game state
    gameStateRef.current.gameTime = 0
    gameStateRef.current.camera = {
      x: 0,
      y: 0,
    }

    setScore(0)
    setShowInventory(false)
    setShowQuests(false)
    setShowDialogue(false)
    setCurrentDialogue([])
    setCurrentDialogueIndex(0)
    setCurrentNPC(null)
    setSelectedSpell(null)
  }

  // Start game
  const startGame = () => {
    setGameStarted(true)
    setGameOver(false)
    initializeGame()
  }

  // Reset game
  const resetGame = () => {
    setGameStarted(false)
    setGameOver(false)
    setGamePaused(false)
  }

  // Toggle pause
  const togglePause = () => {
    setGamePaused(!gamePaused)
  }

  // Toggle mute
  const toggleMute = () => {
    setMuted(!muted)
  }

  // Toggle inventory
  const toggleInventory = () => {
    setShowInventory(!showInventory)
    setShowQuests(false)
  }

  // Toggle quests
  const toggleQuests = () => {
    setShowQuests(!showQuests)
    setShowInventory(false)
  }

  // Use item
  const useItem = (itemId: number) => {
    const { player } = gameStateRef.current
    const itemIndex = player.inventory.findIndex((item) => item.id === itemId)

    if (itemIndex !== -1) {
      const item = player.inventory[itemIndex]

      // Use item effect
      if (item.effect) {
        item.effect()
      }

      // Remove item from inventory (consumables)
      if (item.type === "potion" || item.type === "scroll") {
        player.inventory.splice(itemIndex, 1)
      }
    }
  }

  // Equip item
  const equipItem = (itemId: number) => {
    const { player } = gameStateRef.current
    const itemIndex = player.inventory.findIndex((item) => item.id === itemId)

    if (itemIndex !== -1) {
      const item = player.inventory[itemIndex]

      // Check item type
      if (item.type === "weapon" || item.type === "armor") {
        // Unequip current item if any
        const currentItem =
          item.type === "weapon"
            ? player.equipment.weapon
            : item.type === "armor"
              ? player.equipment.armor
              : player.equipment.accessory

        if (currentItem) {
          player.inventory.push(currentItem)
        }

        // Equip new item
        if (item.type === "weapon") {
          player.equipment.weapon = item
        } else if (item.type === "armor") {
          player.equipment.armor = item
        } else {
          player.equipment.accessory = item
        }

        // Remove from inventory
        player.inventory.splice(itemIndex, 1)

        // Play sound
        playSound("equip")
      }
    }
  }

  // Cast spell
  const castSpell = (spellId: number) => {
    const { player, gameTime } = gameStateRef.current
    const spell = player.spells.find((s) => s.id === spellId)

    if (!spell) return

    // Check cooldown
    if (gameTime - spell.lastCast < spell.cooldown) return

    // Check mana
    if (player.mana < spell.manaCost) return

    // Consume mana
    player.mana -= spell.manaCost

    // Set cooldown
    spell.lastCast = gameTime

    // Cast spell based on effect
    switch (spell.effect) {
      case "damage":
        // Create projectile
        const mouseX = gameStateRef.current.mouse.x + gameStateRef.current.camera.x
        const mouseY = gameStateRef.current.mouse.y + gameStateRef.current.camera.y

        createProjectile(player.x, player.y, mouseX, mouseY, 5, spell.damage, 10, "#FF5722", true, spell.id)

        // Play sound
        playSound("spell")
        break

      case "heal":
        // Heal player
        player.health = Math.min(player.maxHealth, player.health + Math.abs(spell.damage))

        // Create effect
        createEffect(player.x, player.y, 40, "#00FF00", 1000, "heal")

        // Play sound
        playSound("heal")
        break

      case "buff":
        // Buff player
        // Implementation depends on the specific buff

        // Create effect
        createEffect(player.x, player.y, 40, "#FFFF00", 1000, "buff")

        // Play sound
        playSound("buff")
        break

      case "debuff":
        // Create area effect
        createEffect(mouseX, mouseY, spell.areaOfEffect, "#800080", 2000, "debuff")

        // Apply debuff to enemies in range
        gameStateRef.current.npcs.forEach((npc) => {
          if (npc.type === "enemy") {
            const dx = npc.x - mouseX
            const dy = npc.y - mouseY
            const distance = Math.sqrt(dx * dx + dy * dy)

            if (distance < spell.areaOfEffect) {
              // Apply debuff (e.g., slow)
              npc.speed = Math.max(0.5, npc.speed * 0.5)

              // Reset after duration
              setTimeout(() => {
                if (gameStateRef.current.npcs.includes(npc)) {
                  npc.speed *= 2 // Restore speed
                }
              }, 5000)
            }
          }
        })

        // Play sound
        playSound("debuff")
        break
    }
  }

  // Create projectile
  const createProjectile = (
    x: number,
    y: number,
    targetX: number,
    targetY: number,
    speed: number,
    damage: number,
    size: number,
    color: string,
    isPlayerProjectile: boolean,
    spellId?: number,
  ) => {
    gameStateRef.current.projectiles.push({
      id: gameStateRef.current.nextProjectileId++,
      x,
      y,
      targetX,
      targetY,
      speed,
      damage,
      size,
      color,
      isPlayerProjectile,
      spellId,
    })
  }

  // Create effect
  const createEffect = (
    x: number,
    y: number,
    size: number,
    color: string,
    duration: number,
    type: "damage" | "heal" | "buff" | "debuff",
  ) => {
    gameStateRef.current.effects.push({
      id: gameStateRef.current.nextEffectId++,
      x,
      y,
      size,
      color,
      duration,
      startTime: gameStateRef.current.gameTime,
      type,
    })
  }

  // Play sound
  const playSound = (
    type: "hit" | "death" | "spell" | "heal" | "buff" | "debuff" | "potion" | "chest" | "levelup" | "equip",
  ) => {
    if (muted) return

    const sound = new Audio()
    sound.volume = 0.3

    // Simple audio data
    sound.src = "data:audio/wav;base64,UklGRigAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAAABMYXZmNTguMTMuMTAw"
    sound.play()
  }

  // Helper function to get angle from direction
  const getDirectionAngle = (direction: "up" | "down" | "left" | "right"): number => {
    switch (direction) {
      case "up":
        return -Math.PI / 2
      case "down":
        return Math.PI / 2
      case "left":
        return Math.PI
      case "right":
        return 0
    }
  }

  // Initialize canvas and event listeners
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    // Set canvas dimensions
    canvas.width = gameStateRef.current.mapWidth
    canvas.height = gameStateRef.current.mapHeight

    // Event listeners
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "w" || e.key === "W" || e.key === "ArrowUp") gameStateRef.current.keys.w = true
      if (e.key === "a" || e.key === "A" || e.key === "ArrowLeft") gameStateRef.current.keys.a = true
      if (e.key === "s" || e.key === "S" || e.key === "ArrowDown") gameStateRef.current.keys.s = true
      if (e.key === "d" || e.key === "D" || e.key === "ArrowRight") gameStateRef.current.keys.d = true
      if (e.key === " ") gameStateRef.current.keys.space = true

      // Hotkeys for spells
      if (e.key === "1") castSpell(1)
      if (e.key === "2") castSpell(2)

      // Hotkeys for inventory and quests
      if (e.key === "i" || e.key === "I") toggleInventory()
      if (e.key === "q" || e.key === "Q") toggleQuests()

      // Hotkey for interaction
      if (e.key === "e" || e.key === "E") handleInteraction()
    }

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key === "w" || e.key === "W" || e.key === "ArrowUp") gameStateRef.current.keys.w = false
      if (e.key === "a" || e.key === "A" || e.key === "ArrowLeft") gameStateRef.current.keys.a = false
      if (e.key === "s" || e.key === "S" || e.key === "ArrowDown") gameStateRef.current.keys.s = false
      if (e.key === "d" || e.key === "D" || e.key === "ArrowRight") gameStateRef.current.keys.d = false
      if (e.key === " ") gameStateRef.current.keys.space = false
    }

    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect()
      gameStateRef.current.mouse.x = e.clientX - rect.left
      gameStateRef.current.mouse.y = e.clientY - rect.top
    }

    const handleMouseDown = (e: MouseEvent) => {
      if (e.button === 0) {
        gameStateRef.current.mouse.clicked = true

        // Attack or cast spell
        if (selectedSpell !== null) {
          castSpell(selectedSpell)
          setSelectedSpell(null)
        } else {
          handleAttack()
        }
      }
    }

    const handleMouseUp = (e: MouseEvent) => {
      if (e.button === 0) {
        gameStateRef.current.mouse.clicked = false
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    window.addEventListener("keyup", handleKeyUp)
    canvas.addEventListener("mousemove", handleMouseMove)
    canvas.addEventListener("mousedown", handleMouseDown)
    canvas.addEventListener("mouseup", handleMouseUp)

    return () => {
      window.removeEventListener("keydown", handleKeyDown)
      window.removeEventListener("keyup", handleKeyUp)
      canvas.removeEventListener("mousemove", handleMouseMove)
      canvas.removeEventListener("mousedown", handleMouseDown)
      canvas.removeEventListener("mouseup", handleMouseUp)
    }
  }, [selectedSpell])

  // Handle attack
  const handleAttack = () => {
    const { player, gameTime, npcs } = gameStateRef.current

    // Check attack cooldown
    if (gameTime - player.lastAttack < player.attackCooldown) return

    // Set attack cooldown
    player.lastAttack = gameTime
    player.isAttacking = true

    // Reset attack animation after a short delay
    setTimeout(() => {
      if (gameStateRef.current.player) {
        gameStateRef.current.player.isAttacking = false
      }
    }, 300)

    // Calculate attack range based on weapon
    const attackRange = player.equipment.weapon ? 40 : 30

    // Check for enemies in range
    npcs.forEach((npc) => {
      if (npc.type === "enemy") {
        const dx = npc.x - player.x
        const dy = npc.y - player.y
        const distance = Math.sqrt(dx * dx + dy * dy)

        if (distance < attackRange + npc.size) {
          // Calculate damage
          const weaponDamage = player.equipment.weapon?.stats?.damage || 1
          const damage = 5 + weaponDamage

          // Apply damage
          npc.health -= Math.max(1, damage - npc.defense / 2)

          // Create hit effect
          createEffect(npc.x, npc.y, 20, "#FF0000", 300, "damage")

          // Play sound
          playSound("hit")

          // Check if enemy is dead
          if (npc.health <= 0) {
            handleEnemyDeath(npc)
          }
        }
      }
    })
  }

  // Handle enemy death
  const handleEnemyDeath = (npc: NPC) => {
    const { player, quests } = gameStateRef.current

    // Award experience
    player.experience += npc.experience

    // Award gold
    player.gold += npc.gold

    // Add drops to inventory
    npc.drops.forEach((item) => {
      player.inventory.push({ ...item, id: gameStateRef.current.nextId++ })
    })

    // Create death effect
    createEffect(npc.x, npc.y, 30, "#FF0000", 500, "damage")

    // Play sound
    playSound("death")

    // Update quest progress
    quests.forEach((quest) => {
      if (quest.isActive && !quest.isCompleted) {
        quest.objectives.forEach((objective) => {
          if (objective.type === "kill" && objective.target === npc.name) {
            objective.current = Math.min(objective.count, objective.current + 1)

            // Check if quest is completed
            if (quest.objectives.every((obj) => obj.current >= obj.count)) {
              quest.isCompleted = true

              // Award quest rewards
              player.experience += quest.rewards.experience
              player.gold += quest.rewards.gold

              quest.rewards.items.forEach((item) => {
                player.inventory.push({ ...item, id: gameStateRef.current.nextId++ })
              })

              // Create effect
              createEffect(player.x, player.y, 50, "#FFFF00", 1000, "buff")

              // Play sound
              playSound("levelup")
            }
          }
        })
      }
    })

    // Remove enemy from game
    gameStateRef.current.npcs = gameStateRef.current.npcs.filter((n) => n.id !== npc.id)

    // Check for level up
    checkLevelUp()

    // Update score
    setScore((prev) => prev + npc.experience)
  }

  // Check for level up
  const checkLevelUp = () => {
    const { player } = gameStateRef.current

    if (player.experience >= player.experienceToNextLevel) {
      // Level up
      player.level++
      player.experience -= player.experienceToNextLevel
      player.experienceToNextLevel = Math.floor(player.experienceToNextLevel * 1.5)

      // Increase stats
      player.maxHealth += 10
      player.health = player.maxHealth
      player.maxMana += 5
      player.mana = player.maxMana
      player.maxStamina += 5
      player.stamina = player.maxStamina

      // Create effect
      createEffect(player.x, player.y, 50, "#FFFF00", 1000, "buff")

      // Play sound
      playSound("levelup")
    }
  }

  // Handle interaction
  const handleInteraction = () => {
    const { player, npcs, map } = gameStateRef.current

    // Check for NPCs in range
    for (const npc of npcs) {
      const dx = npc.x - player.x
      const dy = npc.y - player.y
      const distance = Math.sqrt(dx * dx + dy * dy)

      if (distance < 50) {
        // Interact with NPC
        if (npc.type === "friendly" || npc.type === "merchant") {
          // Show dialogue
          setShowDialogue(true)
          setCurrentDialogue(npc.dialogue)
          setCurrentDialogueIndex(0)
          setCurrentNPC(npc)
          return
        }
      }
    }

    // Check for interactable tiles
    const tileX = Math.floor(player.x / gameStateRef.current.tileSize)
    const tileY = Math.floor(player.y / gameStateRef.current.tileSize)

    // Check surrounding tiles
    for (let y = tileY - 1; y <= tileY + 1; y++) {
      for (let x = tileX - 1; x <= tileX + 1; x++) {
        if (y >= 0 && y < map.length && x >= 0 && x < map[y].length) {
          const tile = map[y][x]

          if (tile.isInteractable && tile.interaction) {
            tile.interaction()
            return
          }
        }
      }
    }
  }

  // Advance dialogue
  const advanceDialogue = () => {
    if (currentDialogueIndex < currentDialogue.length - 1) {
      setCurrentDialogueIndex(currentDialogueIndex + 1)
    } else {
      // End dialogue
      setShowDialogue(false)

      // Check if NPC has a quest
      if (currentNPC && currentNPC.name === "Village Elder") {
        // Activate quest
        const quest = gameStateRef.current.quests.find((q) => q.title === "Clear the Cave")
        if (quest && !quest.isActive) {
          quest.isActive = true

          // Show quest notification
          createEffect(gameStateRef.current.player.x, gameStateRef.current.player.y, 50, "#FFFF00", 1000, "buff")
        }
      }
    }
  }

  // Game loop
  useEffect(() => {
    if (!gameStarted || gamePaused || gameOver) return

    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    let animationFrameId: number
    let lastTime = 0

    const gameLoop = (timestamp: number) => {
      if (!gameStarted || gamePaused || gameOver) return

      const deltaTime = timestamp - lastTime
      lastTime = timestamp

      gameStateRef.current.gameTime += deltaTime

      // Update player
      updatePlayer(deltaTime)

      // Update NPCs
      updateNPCs(deltaTime)

      // Update projectiles
      updateProjectiles(deltaTime)

      // Update effects
      updateEffects(deltaTime)

      // Update camera
      updateCamera()

      // Clear canvas
      ctx.fillStyle = "#0F0B2A"
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      // Draw map
      drawMap(ctx)

      // Draw NPCs
      drawNPCs(ctx)

      // Draw player
      drawPlayer(ctx)

      // Draw projectiles
      drawProjectiles(ctx)

      // Draw effects
      drawEffects(ctx)

      // Draw UI
      drawUI(ctx)

      animationFrameId = requestAnimationFrame(gameLoop)
    }

    animationFrameId = requestAnimationFrame(gameLoop)

    return () => {
      cancelAnimationFrame(animationFrameId)
    }
  }, [gameStarted, gamePaused, gameOver, showInventory, showQuests, showDialogue, currentDialogueIndex, selectedSpell])

  // Update player
  const updatePlayer = (deltaTime: number) => {
    const { player, keys } = gameStateRef.current

    // Movement
    let dx = 0
    let dy = 0

    if (keys.w) {
      dy -= player.speed
      player.direction = "up"
    }
    if (keys.s) {
      dy += player.speed
      player.direction = "down"
    }
    if (keys.a) {
      dx -= player.speed
      player.direction = "left"
    }
    if (keys.d) {
      dx += player.speed
      player.direction = "right"
    }

    // Normalize diagonal movement
    if (dx !== 0 && dy !== 0) {
      const length = Math.sqrt(dx * dx + dy * dy)
      dx = (dx / length) * player.speed
      dy = (dy / length) * player.speed
    }

    // Check if moving
    player.isMoving = dx !== 0 || dy !== 0

    // Check collision with map
    const newX = player.x + dx
    const newY = player.y + dy

    if (isWalkable(newX, player.y)) {
      player.x = newX
    }

    if (isWalkable(player.x, newY)) {
      player.y = newY
    }

    // Regenerate mana and stamina
    player.mana = Math.min(player.maxMana, player.mana + 0.01 * deltaTime)
    player.stamina = Math.min(player.maxStamina, player.stamina + 0.02 * deltaTime)

    // Check for game over
    if (player.health <= 0) {
      setGameOver(true)
    }
  }

  // Update NPCs
  const updateNPCs = (deltaTime: number) => {
    const { npcs, player, gameTime } = gameStateRef.current

    npcs.forEach((npc) => {
      switch (npc.type) {
        case "friendly":
        case "merchant":
          // Simple wandering behavior
          if (Math.random() < 0.01) {
            npc.isMoving = !npc.isMoving

            if (npc.isMoving) {
              npc.direction = ["up", "down", "left", "right"][Math.floor(Math.random() * 4)] as
                | "up"
                | "down"
                | "left"
                | "right"
            }
          }

          if (npc.isMoving) {
            let dx = 0
            let dy = 0

            if (npc.direction === "up") dy -= npc.speed
            if (npc.direction === "down") dy += npc.speed
            if (npc.direction === "left") dx -= npc.speed
            if (npc.direction === "right") dx += npc.speed

            // Check collision with map
            const newX = npc.x + dx
            const newY = npc.y + dy

            if (isWalkable(newX, npc.y)) {
              npc.x = newX
            } else {
              npc.direction = npc.direction === "left" ? "right" : "left"
            }

            if (isWalkable(npc.x, newY)) {
              npc.y = newY
            } else {
              npc.direction = npc.direction === "up" ? "down" : "up"
            }
          }
          break

        case "enemy":
          // AI behavior
          const dx = player.x - npc.x
          const dy = player.y - npc.y
          const distance = Math.sqrt(dx * dx + dy * dy)

          if (distance < npc.aggroRange) {
            // Player is in aggro range
            npc.state = "following"
            npc.target = { x: player.x, y: player.y }

            // Set direction
            if (Math.abs(dx) > Math.abs(dy)) {
              npc.direction = dx > 0 ? "right" : "left"
            } else {
              npc.direction = dy > 0 ? "down" : "up"
            }

            if (distance < npc.attackRange) {
              // Player is in attack range
              npc.state = "attacking"

              // Attack player if cooldown is ready
              if (gameTime - npc.lastAttack >= npc.attackCooldown) {
                // Attack
                npc.lastAttack = gameTime

                // Calculate damage
                const damage = Math.max(1, npc.damage - (player.equipment.armor?.stats?.defense || 0) / 2)

                // Apply damage to player
                player.health -= damage

                // Create hit effect
                createEffect(player.x, player.y, 20, "#FF0000", 300, "damage")

                // Play sound
                playSound("hit")
              }
            } else {
              // Move toward player
              const moveDistance = Math.min(distance, npc.speed)
              const ratio = moveDistance / distance

              const moveX = dx * ratio
              const moveY = dy * ratio

              // Check collision with map
              if (isWalkable(npc.x + moveX, npc.y)) {
                npc.x += moveX
              }

              if (isWalkable(npc.x, npc.y + moveY)) {
                npc.y += moveY
              }

              npc.isMoving = true
            }
          } else if (npc.state === "following") {
            // Lost sight of player, return to idle
            npc.state = "idle"
            npc.target = null
            npc.isMoving = false
          } else {
            // Random movement
            if (Math.random() < 0.01) {
              npc.isMoving = !npc.isMoving

              if (npc.isMoving) {
                npc.direction = ["up", "down", "left", "right"][Math.floor(Math.random() * 4)] as
                  | "up"
                  | "down"
                  | "left"
                  | "right"
              }
            }

            if (npc.isMoving) {
              let dx = 0
              let dy = 0

              if (npc.direction === "up") dy -= npc.speed
              if (npc.direction === "down") dy += npc.speed
              if (npc.direction === "left") dx -= npc.speed
              if (npc.direction === "right") dx += npc.speed

              // Check collision with map
              const newX = npc.x + dx
              const newY = npc.y + dy

              if (isWalkable(newX, npc.y)) {
                npc.x = newX
              } else {
                npc.direction = npc.direction === "left" ? "right" : "left"
              }

              if (isWalkable(npc.x, newY)) {
                npc.y = newY
              } else {
                npc.direction = npc.direction === "up" ? "down" : "up"
              }
            }
          }
          break
      }
    })
  }

  // Update projectiles
  const updateProjectiles = (deltaTime: number) => {
    const { projectiles, npcs, player } = gameStateRef.current

    for (let i = projectiles.length - 1; i >= 0; i--) {
      const projectile = projectiles[i]

      // Move projectile
      const dx = projectile.targetX - projectile.x
      const dy = projectile.targetY - projectile.y
      const distance = Math.sqrt(dx * dx + dy * dy)

      if (distance < projectile.speed) {
        // Reached target

        // Create impact effect
        createEffect(projectile.x, projectile.y, 30, projectile.color, 500, "damage")

        // Check for area of effect
        if (projectile.spellId === 1) {
          // Fireball
          // Check for enemies in blast radius
          npcs.forEach((npc) => {
            if (npc.type === "enemy") {
              const npcDx = npc.x - projectile.x
              const npcDy = npc.y - projectile.y
              const npcDistance = Math.sqrt(npcDx * npcDx + npcDy * npcDy)

              if (npcDistance < 50) {
                // Apply damage
                npc.health -= Math.max(1, projectile.damage - npc.defense / 2)

                // Create hit effect
                createEffect(npc.x, npc.y, 20, "#FF0000", 300, "damage")

                // Check if enemy is dead
                if (npc.health <= 0) {
                  handleEnemyDeath(npc)
                }
              }
            }
          })
        }

        // Remove projectile
        projectiles.splice(i, 1)
      } else {
        // Move toward target
        const ratio = projectile.speed / distance
        projectile.x += dx * ratio
        projectile.y += dy * ratio

        // Check for collision with enemies (player projectiles)
        if (projectile.isPlayerProjectile) {
          for (const npc of npcs) {
            if (npc.type === "enemy") {
              const npcDx = npc.x - projectile.x
              const npcDy = npc.y - projectile.y
              const npcDistance = Math.sqrt(npcDx * npcDx + npcDy * npcDy)

              if (npcDistance < npc.size + projectile.size) {
                // Hit enemy
                npc.health -= Math.max(1, projectile.damage - npc.defense / 2)

                // Create hit effect
                createEffect(npc.x, npc.y, 20, "#FF0000", 300, "damage")

                // Check if enemy is dead
                if (npc.health <= 0) {
                  handleEnemyDeath(npc)
                }

                // Remove projectile
                projectiles.splice(i, 1)
                break
              }
            }
          }
        } else {
          // Check for collision with player (enemy projectiles)
          const playerDx = player.x - projectile.x
          const playerDy = player.y - projectile.y
          const playerDistance = Math.sqrt(playerDx * playerDx + playerDy * playerDy)

          if (playerDistance < player.size + projectile.size) {
            // Hit player
            player.health -= Math.max(1, projectile.damage - (player.equipment.armor?.stats?.defense || 0) / 2)

            // Create hit effect
            createEffect(player.x, player.y, 20, "#FF0000", 300, "damage")

            // Play sound
            playSound("hit")

            // Remove projectile
            projectiles.splice(i, 1)
          }
        }
      }
    }
  }

  // Update effects
  const updateEffects = (deltaTime: number) => {
    const { effects, gameTime } = gameStateRef.current

    for (let i = effects.length - 1; i >= 0; i--) {
      const effect = effects[i]

      // Check if effect has expired
      if (gameTime - effect.startTime >= effect.duration) {
        effects.splice(i, 1)
      }
    }
  }

  // Update camera
  const updateCamera = () => {
    const { player, mapWidth, mapHeight } = gameStateRef.current

    // Center camera on player
    gameStateRef.current.camera.x = player.x - mapWidth / 2
    gameStateRef.current.camera.y = player.y - mapHeight / 2

    // Clamp camera to map bounds
    gameStateRef.current.camera.x = Math.max(0, Math.min(gameStateRef.current.camera.x, mapWidth))
    gameStateRef.current.camera.y = Math.max(0, Math.min(gameStateRef.current.camera.y, mapHeight))
  }

  // Check if position is walkable
  const isWalkable = (x: number, y: number): boolean => {
    const { map, tileSize } = gameStateRef.current

    // Convert position to tile coordinates
    const tileX = Math.floor(x / tileSize)
    const tileY = Math.floor(y / tileSize)

    // Check if tile is within map bounds
    if (tileY >= 0 && tileY < map.length && tileX >= 0 && tileX < map[tileY].length) {
      return map[tileY][tileX].isWalkable
    }

    return false
  }

  // Draw map
  const drawMap = (ctx: CanvasRenderingContext2D) => {
    const { map, tileSize, camera } = gameStateRef.current

    // Calculate visible tiles
    const startX = Math.floor(camera.x / tileSize)
    const startY = Math.floor(camera.y / tileSize)
    const endX = startX + Math.ceil(gameStateRef.current.mapWidth / tileSize) + 1
    const endY = startY + Math.ceil(gameStateRef.current.mapHeight / tileSize) + 1

    // Draw visible tiles
    for (let y = startY; y < endY; y++) {
      if (y < 0 || y >= map.length) continue

      for (let x = startX; x < endX; x++) {
        if (x < 0 || x >= map[y].length) continue

        const tile = map[y][x]
        const screenX = x * tileSize - camera.x
        const screenY = y * tileSize - camera.y

        // Draw tile based on type
        switch (tile.type) {
          case "grass":
            ctx.fillStyle = "#4CAF50"
            break
          case "water":
            ctx.fillStyle = "#2196F3"
            break
          case "mountain":
            ctx.fillStyle = "#795548"
            break
          case "forest":
            ctx.fillStyle = "#388E3C"
            break
          case "path":
            ctx.fillStyle = "#FFC107"
            break
          case "house":
            ctx.fillStyle = "#FF5722"
            break
          case "cave":
            ctx.fillStyle = "#607D8B"
            break
          case "chest":
            ctx.fillStyle = "#FFC107"
            break
        }

        ctx.fillRect(screenX, screenY, tileSize, tileSize)

        // Draw tile border
        ctx.strokeStyle = "#000000"
        ctx.lineWidth = 1
        ctx.strokeRect(screenX, screenY, tileSize, tileSize)

        // Draw tile icon
        if (tile.type === "chest") {
          ctx.fillStyle = "#000000"
          ctx.font = "20px Arial"
          ctx.textAlign = "center"
          ctx.textBaseline = "middle"
          ctx.fillText("📦", screenX + tileSize / 2, screenY + tileSize / 2)
        }
      }
    }
  }

  // Draw player
  const drawPlayer = (ctx: CanvasRenderingContext2D) => {
    const { player, camera } = gameStateRef.current

    // Calculate screen position
    const screenX = player.x - camera.x
    const screenY = player.y - camera.y

    // Draw player
    ctx.beginPath()
    ctx.arc(screenX, screenY, player.size, 0, Math.PI * 2)
    ctx.fillStyle = "#00FFFF"
    ctx.fill()
    ctx.strokeStyle = "#FFFFFF"
    ctx.lineWidth = 2
    ctx.stroke()

    // Draw direction indicator
    const dirX = screenX + Math.cos(getDirectionAngle(player.direction)) * player.size
    const dirY = screenY + Math.sin(getDirectionAngle(player.direction)) * player.size

    ctx.beginPath()
    ctx.arc(dirX, dirY, 5, 0, Math.PI * 2)
    ctx.fillStyle = "#FFFFFF"
    ctx.fill()

    // Draw attack animation
    if (player.isAttacking) {
      const attackAngle = getDirectionAngle(player.direction)
      const attackX = screenX + Math.cos(attackAngle) * player.size * 2
      const attackY = screenY + Math.sin(attackAngle) * player.size * 2

      ctx.beginPath()
      ctx.arc(attackX, attackY, 10, 0, Math.PI * 2)
      ctx.fillStyle = "#FF0000"
      ctx.fill()
    }

    // Draw health bar
    const healthBarWidth = player.size * 2
    const healthBarHeight = 5
    const healthPercent = player.health / player.maxHealth

    ctx.fillStyle = "#333333"
    ctx.fillRect(screenX - healthBarWidth / 2, screenY - player.size - 10, healthBarWidth, healthBarHeight)

    ctx.fillStyle = "#00FF00"
    ctx.fillRect(
      screenX - healthBarWidth / 2,
      screenY - player.size - 10,
      healthBarWidth * healthPercent,
      healthBarHeight,
    )

    // Draw mana bar
    const manaBarWidth = player.size * 2
    const manaBarHeight = 3
    const manaPercent = player.mana / player.maxMana

    ctx.fillStyle = "#333333"
    ctx.fillRect(screenX - manaBarWidth / 2, screenY - player.size - 5, manaBarWidth, manaBarHeight)

    ctx.fillStyle = "#0000FF"
    ctx.fillRect(screenX - manaBarWidth / 2, screenY - player.size - 5, manaBarWidth * manaPercent, manaBarHeight)
  }

  // Draw NPCs
  const drawNPCs = (ctx: CanvasRenderingContext2D) => {
    const { npcs, camera } = gameStateRef.current

    npcs.forEach((npc) => {
      // Calculate screen position
      const screenX = npc.x - camera.x
      const screenY = npc.y - camera.y

      // Draw NPC
      ctx.beginPath()
      ctx.arc(screenX, screenY, npc.size, 0, Math.PI * 2)

      // Color based on type
      if (npc.type === "friendly") {
        ctx.fillStyle = "#00FF00"
      } else if (npc.type === "merchant") {
        ctx.fillStyle = "#FFC107"
      } else {
        ctx.fillStyle = "#FF0000"
      }

      ctx.fill()
      ctx.strokeStyle = "#FFFFFF"
      ctx.lineWidth = 2
      ctx.stroke()

      // Draw direction indicator
      const dirX = screenX + Math.cos(getDirectionAngle(npc.direction)) * npc.size
      const dirY = screenY + Math.sin(getDirectionAngle(npc.direction)) * npc.size

      ctx.beginPath()
      ctx.arc(dirX, dirY, 3, 0, Math.PI * 2)
      ctx.fillStyle = "#FFFFFF"
      ctx.fill()

      // Draw name
      ctx.fillStyle = "#FFFFFF"
      ctx.font = "12px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "bottom"
      ctx.fillText(npc.name, screenX, screenY - npc.size - 5)

      // Draw health bar for enemies
      if (npc.type === "enemy") {
        const healthBarWidth = npc.size * 2
        const healthBarHeight = 3
        const healthPercent = npc.health / npc.maxHealth

        ctx.fillStyle = "#333333"
        ctx.fillRect(screenX - healthBarWidth / 2, screenY - npc.size - 10, healthBarWidth, healthBarHeight)

        ctx.fillStyle = "#FF0000"
        ctx.fillRect(
          screenX - healthBarWidth / 2,
          screenY - npc.size - 10,
          healthBarWidth * healthPercent,
          healthBarHeight,
        )
      }
    })
  }

  // Draw projectiles
  const drawProjectiles = (ctx: CanvasRenderingContext2D) => {
    const { projectiles, camera } = gameStateRef.current

    projectiles.forEach((projectile) => {
      // Calculate screen position
      const screenX = projectile.x - camera.x
      const screenY = projectile.y - camera.y

      // Draw projectile
      ctx.beginPath()
      ctx.arc(screenX, screenY, projectile.size, 0, Math.PI * 2)
      ctx.fillStyle = projectile.color
      ctx.fill()

      // Draw glow effect
      ctx.shadowBlur = 10
      ctx.shadowColor = projectile.color
      ctx.fill()
      ctx.shadowBlur = 0

      // Draw trail
      const dx = projectile.targetX - projectile.x
      const dy = projectile.targetY - projectile.y
      const angle = Math.atan2(dy, dx)

      ctx.beginPath()
      ctx.moveTo(screenX, screenY)
      ctx.lineTo(screenX - Math.cos(angle) * projectile.size * 3, screenY - Math.sin(angle) * projectile.size * 3)
      ctx.strokeStyle = projectile.color
      ctx.lineWidth = projectile.size
      ctx.globalAlpha = 0.5
      ctx.stroke()
      ctx.globalAlpha = 1
    })
  }

  // Draw effects
  const drawEffects = (ctx: CanvasRenderingContext2D) => {
    const { effects, gameTime, camera } = gameStateRef.current

    effects.forEach((effect) => {
      // Calculate screen position
      const screenX = effect.x - camera.x
      const screenY = effect.y - camera.y

      // Calculate effect progress
      const progress = (gameTime - effect.startTime) / effect.duration

      // Draw effect based on type
      switch (effect.type) {
        case "damage":
          // Expanding circle that fades out
          ctx.beginPath()
          ctx.arc(screenX, screenY, effect.size * progress, 0, Math.PI * 2)
          ctx.fillStyle = effect.color
          ctx.globalAlpha = 1 - progress
          ctx.fill()
          ctx.globalAlpha = 1
          break

        case "heal":
          // Rising particles
          for (let i = 0; i < 5; i++) {
            const angle = Math.PI * 2 * (i / 5)
            const distance = effect.size * progress

            ctx.beginPath()
            ctx.arc(
              screenX + Math.cos(angle) * distance,
              screenY + Math.sin(angle) * distance - effect.size * progress,
              5,
              0,
              Math.PI * 2,
            )
            ctx.fillStyle = "#00FF00"
            ctx.globalAlpha = 1 - progress
            ctx.fill()
            ctx.globalAlpha = 1
          }
          break

        case "buff":
          // Rotating stars
          for (let i = 0; i < 5; i++) {
            const angle = Math.PI * 2 * (i / 5) + progress * Math.PI * 2
            const distance = effect.size * 0.7

            ctx.beginPath()
            ctx.moveTo(screenX + Math.cos(angle) * distance, screenY + Math.sin(angle) * distance)

            for (let j = 0; j < 5; j++) {
              const starAngle = angle + Math.PI * 2 * (j / 5)
              const starDistance = j % 2 === 0 ? distance * 0.5 : distance

              ctx.lineTo(screenX + Math.cos(starAngle) * starDistance, screenY + Math.sin(starAngle) * starDistance)
            }

            ctx.fillStyle = "#FFFF00"
            ctx.globalAlpha = 1 - progress
            ctx.fill()
            ctx.globalAlpha = 1
          }
          break

        case "debuff":
          // Pulsating circle
          const pulseSize = effect.size * (0.8 + Math.sin(progress * Math.PI * 10) * 0.2)

          ctx.beginPath()
          ctx.arc(screenX, screenY, pulseSize, 0, Math.PI * 2)
          ctx.strokeStyle = effect.color
          ctx.lineWidth = 3
          ctx.globalAlpha = 1 - progress
          ctx.stroke()
          ctx.globalAlpha = 1
          break
      }
    })
  }

  // Draw UI
  const drawUI = (ctx: CanvasRenderingContext2D) => {
    const { player } = gameStateRef.current

    // Draw player stats
    ctx.fillStyle = "rgba(0, 0, 0, 0.5)"
    ctx.fillRect(10, 10, 200, 80)

    ctx.fillStyle = "#FFFFFF"
    ctx.font = "14px Arial"
    ctx.textAlign = "left"
    ctx.textBaseline = "top"
    ctx.fillText(`Level: ${player.level}`, 20, 20)
    ctx.fillText(`Health: ${Math.floor(player.health)}/${player.maxHealth}`, 20, 40)
    ctx.fillText(`Mana: ${Math.floor(player.mana)}/${player.maxMana}`, 20, 60)
    ctx.fillText(`Gold: ${player.gold}`, 20, 80)

    // Draw experience bar
    const expBarWidth = 200
    const expBarHeight = 10
    const expPercent = player.experience / player.experienceToNextLevel

    ctx.fillStyle = "#333333"
    ctx.fillRect(10, 100, expBarWidth, expBarHeight)

    ctx.fillStyle = "#FFFF00"
    ctx.fillRect(10, 100, expBarWidth * expPercent, expBarHeight)

    // Draw spell icons
    player.spells.forEach((spell, index) => {
      const x = 10 + index * 50
      const y = gameStateRef.current.mapHeight - 60

      // Draw spell background
      ctx.fillStyle = selectedSpell === spell.id ? "#FFFFFF" : "#333333"
      ctx.fillRect(x, y, 40, 40)

      // Draw spell icon
      ctx.fillStyle = "#000000"
      ctx.font = "20px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(spell.icon, x + 20, y + 20)

      // Draw cooldown overlay
      const cooldown = gameStateRef.current.gameTime - spell.lastCast
      if (cooldown < spell.cooldown) {
        const cooldownPercent = cooldown / spell.cooldown

        // Gray overlay
        ctx.fillStyle = "rgba(0, 0, 0, 0.7)"
        ctx.fillRect(x, y + 40 * (1 - cooldownPercent), 40, 40 * (1 - cooldownPercent))
      }

      // Draw mana cost indicator
      if (player.mana < spell.manaCost) {
        // Blue overlay
        ctx.fillStyle = "rgba(0, 0, 255, 0.3)"
        ctx.fillRect(x, y, 40, 40)
      }

      // Draw spell hotkey
      ctx.fillStyle = "#FFFFFF"
      ctx.font = "12px Arial"
      ctx.textAlign = "left"
      ctx.textBaseline = "top"
      ctx.fillText(`${index + 1}`, x + 2, y + 2)
    })

    // Draw score
    ctx.fillStyle = "#FFFFFF"
    ctx.font = "16px Arial"
    ctx.textAlign = "right"
    ctx.textBaseline = "top"
    ctx.fillText(`Score: ${score}`, gameStateRef.current.mapWidth - 20, 20)

    // Draw inventory if open
    if (showInventory) {
      drawInventory(ctx)
    }

    // Draw quests if open
    if (showQuests) {
      drawQuests(ctx)
    }

    // Draw dialogue if open
    if (showDialogue) {
      drawDialogue(ctx)
    }
  }

  // Draw inventory
  const drawInventory = (ctx: CanvasRenderingContext2D) => {
    const { player } = gameStateRef.current
    const { mapWidth, mapHeight } = gameStateRef.current

    // Draw inventory background
    ctx.fillStyle = "rgba(0, 0, 0, 0.8)"
    ctx.fillRect(mapWidth / 4, mapHeight / 4, mapWidth / 2, mapHeight / 2)

    // Draw inventory title
    ctx.fillStyle = "#FFFFFF"
    ctx.font = "20px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "top"
    ctx.fillText("Inventory", mapWidth / 2, mapHeight / 4 + 10)

    // Draw equipment section
    ctx.fillStyle = "#AAAAAA"
    ctx.font = "16px Arial"
    ctx.textAlign = "left"
    ctx.fillText("Equipment:", mapWidth / 4 + 20, mapHeight / 4 + 50)

    // Draw equipped items
    if (player.equipment.weapon) {
      ctx.fillStyle = "#FFFFFF"
      ctx.fillText(
        `Weapon: ${player.equipment.weapon.name} (DMG: ${player.equipment.weapon.stats?.damage})`,
        mapWidth / 4 + 30,
        mapHeight / 4 + 80,
      )
    } else {
      ctx.fillStyle = "#777777"
      ctx.fillText("Weapon: None", mapWidth / 4 + 30, mapHeight / 4 + 80)
    }

    if (player.equipment.armor) {
      ctx.fillStyle = "#FFFFFF"
      ctx.fillText(
        `Armor: ${player.equipment.armor.name} (DEF: ${player.equipment.armor.stats?.defense})`,
        mapWidth / 4 + 30,
        mapHeight / 4 + 110,
      )
    } else {
      ctx.fillStyle = "#777777"
      ctx.fillText("Armor: None", mapWidth / 4 + 30, mapHeight / 4 + 110)
    }

    // Draw items section
    ctx.fillStyle = "#AAAAAA"
    ctx.font = "16px Arial"
    ctx.fillText("Items:", mapWidth / 4 + 20, mapHeight / 4 + 150)

    // Draw items
    player.inventory.forEach((item, index) => {
      const x = mapWidth / 4 + 30
      const y = mapHeight / 4 + 180 + index * 30

      // Skip if out of bounds
      if (y > mapHeight / 4 + mapHeight / 2 - 40) return

      ctx.fillStyle = "#FFFFFF"
      ctx.font = "14px Arial"
      ctx.textAlign = "left"
      ctx.fillText(`${item.icon} ${item.name} - ${item.description}`, x, y)

      // Draw use/equip button
      if (item.type === "potion" || item.type === "scroll") {
        ctx.fillStyle = "#4CAF50"
        ctx.fillRect(mapWidth / 2 + 100, y - 5, 60, 25)
        ctx.fillStyle = "#FFFFFF"
        ctx.textAlign = "center"
        ctx.fillText("Use", mapWidth / 2 + 130, y + 7)
      } else if (item.type === "weapon" || item.type === "armor") {
        ctx.fillStyle = "#2196F3"
        ctx.fillRect(mapWidth / 2 + 100, y - 5, 60, 25)
        ctx.fillStyle = "#FFFFFF"
        ctx.textAlign = "center"
        ctx.fillText("Equip", mapWidth / 2 + 130, y + 7)
      }
    })

    // Draw close button
    ctx.fillStyle = "#FF5722"
    ctx.fillRect(mapWidth / 2 + mapWidth / 4 - 80, mapHeight / 4 + 10, 60, 30)
    ctx.fillStyle = "#FFFFFF"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText("Close", mapWidth / 2 + mapWidth / 4 - 50, mapHeight / 4 + 25)
  }

  // Draw quests
  const drawQuests = (ctx: CanvasRenderingContext2D) => {
    const { quests } = gameStateRef.current
    const { mapWidth, mapHeight } = gameStateRef.current

    // Draw quests background
    ctx.fillStyle = "rgba(0, 0, 0, 0.8)"
    ctx.fillRect(mapWidth / 4, mapHeight / 4, mapWidth / 2, mapHeight / 2)

    // Draw quests title
    ctx.fillStyle = "#FFFFFF"
    ctx.font = "20px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "top"
    ctx.fillText("Quests", mapWidth / 2, mapHeight / 4 + 10)

    // Draw quests
    quests.forEach((quest, index) => {
      const x = mapWidth / 4 + 20
      const y = mapHeight / 4 + 50 + index * 100

      // Skip if out of bounds
      if (y > mapHeight / 4 + mapHeight / 2 - 100) return

      // Draw quest title
      ctx.fillStyle = quest.isCompleted ? "#4CAF50" : quest.isActive ? "#FFEB3B" : "#AAAAAA"
      ctx.font = "16px Arial"
      ctx.textAlign = "left"
      ctx.fillText(quest.title, x, y)

      // Draw quest description
      ctx.fillStyle = "#FFFFFF"
      ctx.font = "14px Arial"
      ctx.fillText(quest.description, x, y + 25)

      // Draw quest objectives
      quest.objectives.forEach((objective, objIndex) => {
        ctx.fillStyle = objective.current >= objective.count ? "#4CAF50" : "#FFFFFF"
        ctx.fillText(
          `- ${objective.type === "kill" ? "Kill" : objective.type === "collect" ? "Collect" : "Talk to"} ${
            objective.target
          }: ${objective.current}/${objective.count}`,
          x + 10,
          y + 50 + objIndex * 20,
        )
      })

      // Draw quest status
      if (quest.isCompleted) {
        ctx.fillStyle = "#4CAF50"
        ctx.fillText("Completed", mapWidth / 2 + 100, y)
      } else if (quest.isActive) {
        ctx.fillStyle = "#FFEB3B"
        ctx.fillText("Active", mapWidth / 2 + 100, y)
      } else {
        ctx.fillStyle = "#AAAAAA"
        ctx.fillText("Not Started", mapWidth / 2 + 100, y)
      }
    })

    // Draw close button
    ctx.fillStyle = "#FF5722"
    ctx.fillRect(mapWidth / 2 + mapWidth / 4 - 80, mapHeight / 4 + 10, 60, 30)
    ctx.fillStyle = "#FFFFFF"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText("Close", mapWidth / 2 + mapWidth / 4 - 50, mapHeight / 4 + 25)
  }

  // Draw dialogue
  const drawDialogue = (ctx: CanvasRenderingContext2D) => {
    const { mapWidth, mapHeight } = gameStateRef.current

    // Draw dialogue background
    ctx.fillStyle = "rgba(0, 0, 0, 0.8)"
    ctx.fillRect(mapWidth / 6, mapHeight * 0.7, (mapWidth * 2) / 3, mapHeight * 0.25)

    // Draw NPC name
    if (currentNPC) {
      ctx.fillStyle = "#FFEB3B"
      ctx.font = "18px Arial"
      ctx.textAlign = "left"
      ctx.textBaseline = "top"
      ctx.fillText(currentNPC.name, mapWidth / 6 + 20, mapHeight * 0.7 + 20)
    }

    // Draw dialogue text
    if (currentDialogue.length > 0) {
      ctx.fillStyle = "#FFFFFF"
      ctx.font = "16px Arial"
      ctx.fillText(currentDialogue[currentDialogueIndex], mapWidth / 6 + 20, mapHeight * 0.7 + 50)
    }

    // Draw continue button
    ctx.fillStyle = "#4CAF50"
    ctx.fillRect(mapWidth / 2 - 50, mapHeight * 0.7 + mapHeight * 0.25 - 40, 100, 30)
    ctx.fillStyle = "#FFFFFF"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText(
      currentDialogueIndex < currentDialogue.length - 1 ? "Continue" : "Close",
      mapWidth / 2,
      mapHeight * 0.7 + mapHeight * 0.25 - 25,
    )
  }

  return (
    <div className="relative">
      {/* Game canvas */}
      <canvas ref={canvasRef} className="bg-[#0F0B2A] rounded-lg shadow-lg" />

      {/* Game UI overlay */}
      <div className="absolute top-4 right-4 flex items-center space-x-2">
        <Button
          size="icon"
          variant="outline"
          className="bg-[#1A1145]/50 border-[#3A2A65] text-white hover:bg-[#3A2A65]/50"
          onClick={toggleInventory}
        >
          <Backpack className="h-4 w-4" />
        </Button>

        <Button
          size="icon"
          variant="outline"
          className="bg-[#1A1145]/50 border-[#3A2A65] text-white hover:bg-[#3A2A65]/50"
          onClick={toggleQuests}
        >
          <Scroll className="h-4 w-4" />
        </Button>

        <Button
          size="icon"
          variant="outline"
          className="bg-[#1A1145]/50 border-[#3A2A65] text-white hover:bg-[#3A2A65]/50"
          onClick={toggleMute}
        >
          {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
        </Button>

        <Button
          size="icon"
          variant="outline"
          className="bg-[#1A1145]/50 border-[#3A2A65] text-white hover:bg-[#3A2A65]/50"
          onClick={togglePause}
        >
          {gamePaused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
        </Button>

        <Button
          size="icon"
          variant="outline"
          className="bg-[#1A1145]/50 border-[#3A2A65] text-white hover:bg-[#3A2A65]/50"
          onClick={resetGame}
        >
          <RotateCcw className="h-4 w-4" />
        </Button>
      </div>

      {/* Spell buttons */}
      <div className="absolute bottom-4 left-4 flex space-x-2">
        {gameStateRef.current.player.spells.map((spell) => (
          <Button
            key={spell.id}
            size="sm"
            variant={selectedSpell === spell.id ? "default" : "outline"}
            className={`${selectedSpell === spell.id ? "bg-[#9D00FF]" : "bg-[#1A1145]/50 border-[#3A2A65]"} text-white`}
            onClick={() => setSelectedSpell(spell.id)}
            disabled={
              gameStateRef.current.gameTime - spell.lastCast < spell.cooldown ||
              gameStateRef.current.player.mana < spell.manaCost
            }
          >
            <span className="mr-1">{spell.icon}</span>
            {spell.name}
          </Button>
        ))}
      </div>

      {/* Attack button */}
      <div className="absolute bottom-4 right-4">
        <Button
          size="lg"
          variant="default"
          className="bg-[#FF2D95] hover:bg-[#FF5CAD] text-white"
          onClick={handleAttack}
          disabled={
            gameStateRef.current.gameTime - gameStateRef.current.player.lastAttack <
            gameStateRef.current.player.attackCooldown
          }
        >
          <Sword className="h-5 w-5 mr-2" />
          Attack
        </Button>
      </div>

      {/* Dialogue overlay */}
      {showDialogue && (
        <div
          className="absolute bottom-0 left-0 right-0 bg-black/80 p-4 text-white"
          style={{ height: "30%" }}
          onClick={advanceDialogue}
        >
          {currentNPC && <div className="text-yellow-300 text-lg font-bold mb-2">{currentNPC.name}</div>}
          <div className="text-white text-md">{currentDialogue[currentDialogueIndex]}</div>
          <div className="absolute bottom-4 right-4 text-sm text-gray-400">
            Click to {currentDialogueIndex < currentDialogue.length - 1 ? "continue" : "close"}
          </div>
        </div>
      )}

      {/* Game start overlay */}
      {!gameStarted && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#0F0B2A]/80 rounded-lg">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4 text-[#9D00FF]">Mystic Realms</h2>
            <p className="text-[#E0E0FF] mb-6 max-w-md">
              Embark on an epic adventure in a vast fantasy world. Explore, battle monsters, complete quests, and become
              a legendary hero!
            </p>
            <Button
              onClick={startGame}
              className="bg-gradient-to-r from-[#9D00FF] to-[#FF2D95] text-white font-bold hover:from-[#B347FF] hover:to-[#FF5CAD]"
            >
              Start Game
            </Button>
          </div>
        </div>
      )}

      {/* Game over overlay */}
      {gameOver && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#0F0B2A]/80 rounded-lg">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4 text-[#FF2D95]">Game Over</h2>
            <p className="text-2xl text-[#E0E0FF] mb-2">Final Score: {score}</p>
            <p className="text-[#E0E0FF] mb-6">
              You reached level {gameStateRef.current.player.level} and collected {gameStateRef.current.player.gold}{" "}
              gold!
            </p>
            <Button
              onClick={resetGame}
              className="bg-gradient-to-r from-[#9D00FF] to-[#FF2D95] text-white font-bold hover:from-[#B347FF] hover:to-[#FF5CAD]"
            >
              Play Again
            </Button>
          </div>
        </div>
      )}

      {/* Pause overlay */}
      {gameStarted && gamePaused && !gameOver && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#0F0B2A]/80 rounded-lg">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4 text-[#9D00FF]">Game Paused</h2>
            <Button
              onClick={togglePause}
              className="bg-gradient-to-r from-[#9D00FF] to-[#FF2D95] text-white font-bold hover:from-[#B347FF] hover:to-[#FF5CAD]"
            >
              Resume
            </Button>
          </div>
        </div>
      )}

      {/* Controls help */}
      <div className="absolute top-16 left-4 bg-[#1A1145]/70 p-2 rounded-lg text-[#E0E0FF] text-xs">
        <p>WASD: Move</p>
        <p>Click: Attack/Cast</p>
        <p>1-2: Select spells</p>
        <p>E: Interact</p>
        <p>I: Inventory</p>
        <p>Q: Quests</p>
      </div>
    </div>
  )
}
