"use client"

import { useRef, useState } from "react"

interface Player {
  x: number
  y: number
  size: number
  speed: number
  health: number
  maxHealth: number
  hunger: number
  maxHunger: number
  thirst: number
  maxThirst: number
  stamina: number
  maxStamina: number
  inventory: Resource[]
  direction: "up" | "down" | "left" | "right"
  isMoving: boolean
  isGathering: boolean
  gatheringTime: number
  gatheringResource: Resource | null
  gatheringProgress: number
  gatheringSpeed: number
  craftingQueue: CraftingItem[]
}

interface Resource {
  id: number
  name: string
  type: "wood" | "stone" | "food" | "water" | "metal" | "cloth" | "medicine" | "tool" | "weapon" | "building"
  quantity: number
  icon: string
  description: string
}

interface ResourceNode {
  id: number
  x: number
  y: number
  size: number
  type: "tree" | "rock" | "bush" | "water" | "animal" | "debris"
  resourceType: "wood" | "stone" | "food" | "water" | "metal" | "cloth"
  quantity: number
  maxQuantity: number
  respawnTime: number
  lastHarvested: number
  harvestTime: number
}

interface CraftingRecipe {
  id: number
  name: string
  type: "tool" | "weapon" | "building" | "food" | "medicine"
  icon: string
  description: string
  ingredients: {
    type: "wood" | "stone" | "food" | "water" | "metal" | "cloth" | "medicine"
    quantity: number
  }[]
  result: {
    type: "tool" | "weapon" | "building" | "food" | "medicine" | "water"
    quantity: number
  }
  craftingTime: number
}

interface CraftingItem {
  recipeId: number
  progress: number
  totalTime: number
}

interface Building {
  id: number
  x: number
  y: number
  size: number
  type: "shelter" | "campfire" | "workbench" | "storage" | "farm" | "well"
  health: number
  maxHealth: number
  resources: Resource[]
  effects: {
    type: "health" | "hunger" | "thirst" | "crafting" | "storage"
    value: number
  }[]
}

interface Threat {
  id: number
  x: number
  y: number
  size: number
  type: "animal" | "zombie" | "bandit" | "weather"
  health: number
  maxHealth: number
  damage: number
  speed: number
  aggroRange: number
  attackRange: number
  lastAttack: number
  attackCooldown: number
  state: "idle" | "chasing" | "attacking" | "fleeing"
  direction: "up" | "down" | "left" | "right"
  target: { x: number; y: number } | null
}

interface MapTile {
  type: "grass" | "dirt" | "sand" | "water" | "road" | "ruins"
  isWalkable: boolean
  movementPenalty: number
}

export default function SurvivalHorizonGame() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [gameStarted, setGameStarted] = useState(false)
  const [gamePaused, setGamePaused] = useState(false)
  const [gameOver, setGameOver] = useState(false)
  const [score, setScore] = useState(0)
  const [day, setDay] = useState(1)
  const [showInventory, setShowInventory] = useState(false)
  const [showCrafting, setShowCrafting] = useState(false)
  const [selectedRecipe, setSelectedRecipe] = useState<number | null>(null)
  const [muted, setMuted] = useState(false)

  // Game state
  const gameStateRef = useRef({
    player: {
      x: 400,
      y: 300,
      size: 20,
      speed: 3,
      health: 100,
      maxHealth: 100,
      hunger: 100,
      maxHunger: 100,
      thirst: 100,
      maxThirst: 100,
      stamina: 100,
      maxStamina: 100,
      inventory: [] as Resource[],
      direction: "down" as "up" | "down" | "left" | "right",
      isMoving: false,
      isGathering: false,
      gatheringTime: 0,
      gatheringResource: null as Resource | null,
      gatheringProgress: 0,
      gatheringSpeed: 1,
      craftingQueue: [] as CraftingItem[],
    } as Player,
    resourceNodes: [] as ResourceNode[],
    buildings: [] as Building[],
    threats: [] as Threat[],
    map: [] as MapTile[][],
    mapWidth: 800,
    mapHeight: 600,
    tileSize: 40,
    dayTime: 0, // 0-1000, representing time from morning to night
    dayLength: 60000, // 60 seconds per day
    weather: "clear" as "clear" | "rain" | "fog" | "storm",
    camera: {
      x: 0,
      y: 0,
    },
    gameTime: 0,
    nextId: 1,
    keys: {
      w: false,
      a: false,
      s: false,
      d: false,
      space: false,
      e: false,
    },
    mouse: {
      x: 0,
      y: 0,
      clicked: false,
      rightClicked: false,
    },
  })

  // Crafting recipes
  const craftingRecipes: CraftingRecipe[] = [
    {
      id: 1,
      name: "Axe",
      type: "tool",
      icon: "🪓",
      description: "Increases wood gathering speed",
      ingredients: [
        { type: "wood", quantity: 5 },
        { type: "stone", quantity: 3 },
      ],
      result: { type: "tool", quantity: 1 },
      craftingTime: 5000,
    },
    {
      id: 2,
      name: "Spear",
      type: "weapon",
      icon: "🔱",
      description: "Basic weapon for hunting and defense",
      ingredients: [
        { type: "wood", quantity: 3 },
        { type: "stone", quantity: 2 },
      ],
      result: { type: "weapon", quantity: 1 },
      craftingTime: 3000,
    },
    {
      id: 3,
      name: "Shelter",
      type: "building",
      icon: "🏠",
      description: "Basic shelter for protection",
      ingredients: [
        { type: "wood", quantity: 10 },
        { type: "cloth", quantity: 5 },
      ],
      result: { type: "building", quantity: 1 },
      craftingTime: 10000,
    },
    {
      id: 4,
      name: "Campfire",
      type: "building",
      icon: "🔥",
      description: "Cook food and stay warm",
      ingredients: [
        { type: "wood", quantity: 5 },
        { type: "stone", quantity: 5 },
      ],
      result: { type: "building", quantity: 1 },
      craftingTime: 2000,
    },
    {
      id: 5,
      name: "Cooked Meat",
      type: "food",
      icon: "🍖",
      description: "Restores hunger",
      ingredients: [{ type: "food", quantity: 1 }],
      result: { type: "food", quantity: 1 },
      craftingTime: 3000,
    },
    {
