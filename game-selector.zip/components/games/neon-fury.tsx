"use client"

import { useEffect, useRef, useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Play, Pause, RotateCcw, Volume2, VolumeX } from "lucide-react"
import Image from "next/image"

interface Enemy {
  id: number
  x: number
  y: number
  size: number
  speed: number
  health: number
  maxHealth: number
  color: string
  angle: number
  type: "drone" | "hunter" | "tank"
  shootCooldown: number
  lastShot: number
}

interface Bullet {
  id: number
  x: number
  y: number
  speed: number
  angle: number
  damage: number
  size: number
  color: string
  isPlayerBullet: boolean
}

interface Particle {
  x: number
  y: number
  size: number
  color: string
  speed: number
  angle: number
  alpha: number
  decay: number
}

interface PowerUp {
  id: number
  x: number
  y: number
  type: "health" | "speed" | "damage" | "shield"
  size: number
  color: string
  active: boolean
  duration: number
  collected: boolean
}

interface Explosion {
  x: number
  y: number
  size: number
  frame: number
  maxFrames: number
  frameTime: number
  lastFrameUpdate: number
}

export default function NeonFuryGame() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [gameStarted, setGameStarted] = useState(false)
  const [gamePaused, setGamePaused] = useState(false)
  const [gameOver, setGameOver] = useState(false)
  const [score, setScore] = useState(0)
  const [level, setLevel] = useState(1)
  const [playerHealth, setPlayerHealth] = useState(100)
  const [muted, setMuted] = useState(false)
  const [assetsLoaded, setAssetsLoaded] = useState(false)

  // Image refs
  const backgroundImageRef = useRef<HTMLImageElement | null>(null)
  const playerImageRef = useRef<HTMLImageElement | null>(null)
  const enemyImageRefs = useRef<Record<string, HTMLImageElement>>({})
  const powerupImageRef = useRef<HTMLImageElement | null>(null)
  const explosionImageRef = useRef<HTMLImageElement | null>(null)

  // Game state refs (to avoid dependency issues in useEffect)
  const gameStateRef = useRef({
    player: {
      x: 0,
      y: 0,
      size: 25,
      speed: 5,
      angle: 0,
      health: 100,
      maxHealth: 100,
      shield: 0,
      maxShield: 50,
      powerUps: {
        speed: { active: false, duration: 0 },
        damage: { active: false, duration: 0 },
        shield: { active: false, duration: 0 },
      },
      dashing: false,
      dashCooldown: 0,
      dashDirection: 0,
      dashDistance: 0,
      dashSpeed: 0,
      invulnerable: false,
      invulnerabilityTime: 0,
    },
    enemies: [] as Enemy[],
    bullets: [] as Bullet[],
    particles: [] as Particle[],
    powerUps: [] as PowerUp[],
    explosions: [] as Explosion[],
    keys: {
      w: false,
      a: false,
      s: false,
      d: false,
      up: false,
      down: false,
      left: false,
      right: false,
      space: false,
    },
    mouse: {
      x: 0,
      y: 0,
      clicked: false,
    },
    gameTime: 0,
    lastShot: 0,
    shotCooldown: 200, // ms
    score: 0,
    level: 1,
    enemiesKilled: 0,
    enemiesRequired: 10,
    nextId: 1,
    nextBulletId: 1,
    nextPowerUpId: 1,
  })

  // Load assets
  useEffect(() => {
    const loadImage = (src: string): Promise<HTMLImageElement> => {
      return new Promise((resolve, reject) => {
        const img = new Image()
        img.crossOrigin = "anonymous"
        img.onload = () => resolve(img)
        img.onerror = reject
        img.src = src
      })
    }

    const loadAssets = async () => {
      try {
        // Load background
        backgroundImageRef.current = await loadImage("/images/neon-bg.png")

        // Load player ship
        playerImageRef.current = await loadImage("/images/player-ship.png")

        // Load enemy ships
        enemyImageRefs.current.drone = await loadImage("/images/enemy-ship.png")
        enemyImageRefs.current.hunter = await loadImage("/images/enemy-ship.png")
        enemyImageRefs.current.tank = await loadImage("/images/enemy-ship.png")

        // Load powerup
        powerupImageRef.current = await loadImage("/images/powerup.png")

        // Load explosion
        explosionImageRef.current = await loadImage("/images/explosion.png")

        setAssetsLoaded(true)
      } catch (error) {
        console.error("Failed to load assets:", error)
      }
    }

    loadAssets()
  }, [])

  // Initialize game
  useEffect(() => {
    if (!gameStarted || gamePaused || gameOver) return

    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions
    canvas.width = 800
    canvas.height = 600

    // Center player initially
    gameStateRef.current.player.x = canvas.width / 2
    gameStateRef.current.player.y = canvas.height / 2
    gameStateRef.current.player.health = 100
    gameStateRef.current.player.shield = 0
    gameStateRef.current.player.powerUps = {
      speed: { active: false, duration: 0 },
      damage: { active: false, duration: 0 },
      shield: { active: false, duration: 0 },
    }
    gameStateRef.current.enemies = []
    gameStateRef.current.bullets = []
    gameStateRef.current.particles = []
    gameStateRef.current.powerUps = []
    gameStateRef.current.explosions = []
    gameStateRef.current.score = 0
    gameStateRef.current.level = level
    gameStateRef.current.enemiesKilled = 0
    gameStateRef.current.enemiesRequired = 10 + level * 5
    gameStateRef.current.nextId = 1
    gameStateRef.current.nextBulletId = 1
    gameStateRef.current.nextPowerUpId = 1

    setScore(0)
    setPlayerHealth(100)

    // Event listeners
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "w" || e.key === "W" || e.key === "ArrowUp") gameStateRef.current.keys.w = true
      if (e.key === "a" || e.key === "A" || e.key === "ArrowLeft") gameStateRef.current.keys.a = true
      if (e.key === "s" || e.key === "S" || e.key === "ArrowDown") gameStateRef.current.keys.s = true
      if (e.key === "d" || e.key === "D" || e.key === "ArrowRight") gameStateRef.current.keys.d = true
      if (e.key === " ") gameStateRef.current.keys.space = true
    }

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key === "w" || e.key === "W" || e.key === "ArrowUp") gameStateRef.current.keys.w = false
      if (e.key === "a" || e.key === "A" || e.key === "ArrowLeft") gameStateRef.current.keys.a = false
      if (e.key === "s" || e.key === "S" || e.key === "ArrowDown") gameStateRef.current.keys.s = false
      if (e.key === "d" || e.key === "D" || e.key === "ArrowRight") gameStateRef.current.keys.d = false
      if (e.key === " ") gameStateRef.current.keys.space = false
    }

    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect()
      gameStateRef.current.mouse.x = e.clientX - rect.left
      gameStateRef.current.mouse.y = e.clientY - rect.top

      // Calculate angle between player and mouse
      const dx = gameStateRef.current.mouse.x - gameStateRef.current.player.x
      const dy = gameStateRef.current.mouse.y - gameStateRef.current.player.y
      gameStateRef.current.player.angle = Math.atan2(dy, dx)
    }

    const handleMouseDown = () => {
      gameStateRef.current.mouse.clicked = true
    }

    const handleMouseUp = () => {
      gameStateRef.current.mouse.clicked = false
    }

    window.addEventListener("keydown", handleKeyDown)
    window.addEventListener("keyup", handleKeyUp)
    canvas.addEventListener("mousemove", handleMouseMove)
    canvas.addEventListener("mousedown", handleMouseDown)
    canvas.addEventListener("mouseup", handleMouseUp)

    // Spawn enemies function
    const spawnEnemies = () => {
      const { level, enemies } = gameStateRef.current
      const enemyCount = Math.min(5 + level, 15)

      if (enemies.length >= enemyCount) return

      // Determine spawn position (outside the canvas)
      let x, y
      if (Math.random() < 0.5) {
        // Spawn on left or right edge
        x = Math.random() < 0.5 ? -50 : canvas.width + 50
        y = Math.random() * canvas.height
      } else {
        // Spawn on top or bottom edge
        x = Math.random() * canvas.width
        y = Math.random() < 0.5 ? -50 : canvas.height + 50
      }

      // Determine enemy type
      const typeRoll = Math.random()
      let type: "drone" | "hunter" | "tank"
      let size: number
      let speed: number
      let health: number
      let color: string
      let shootCooldown: number

      if (typeRoll < 0.6) {
        type = "drone"
        size = 15
        speed = 2 + Math.random() * 1.5
        health = 2 + level * 0.5
        color = "#FF2D95"
        shootCooldown = 0 // Drones don't shoot
      } else if (typeRoll < 0.9) {
        type = "hunter"
        size = 20
        speed = 3 + Math.random()
        health = 4 + level * 0.7
        color = "#9D00FF"
        shootCooldown = 2000 // Shoot every 2 seconds
      } else {
        type = "tank"
        size = 30
        speed = 1 + Math.random() * 0.5
        health = 10 + level * 1.5
        color = "#00FFFF"
        shootCooldown = 3000 // Shoot every 3 seconds
      }

      gameStateRef.current.enemies.push({
        id: gameStateRef.current.nextId++,
        x,
        y,
        size,
        speed,
        health,
        maxHealth: health,
        color,
        angle: 0,
        type,
        shootCooldown,
        lastShot: 0,
      })
    }

    // Spawn power-ups
    const spawnPowerUp = () => {
      if (gameStateRef.current.powerUps.length >= 2) return

      if (Math.random() < 0.005) {
        const types: ("health" | "speed" | "damage" | "shield")[] = ["health", "speed", "damage", "shield"]
        const type = types[Math.floor(Math.random() * types.length)]

        let color
        switch (type) {
          case "health":
            color = "#00FF80"
            break
          case "speed":
            color = "#FFFF00"
            break
          case "damage":
            color = "#FF2D95"
            break
          case "shield":
            color = "#00FFFF"
            break
        }

        gameStateRef.current.powerUps.push({
          id: gameStateRef.current.nextPowerUpId++,
          x: 100 + Math.random() * (canvas.width - 200),
          y: 100 + Math.random() * (canvas.height - 200),
          type,
          size: 20,
          color,
          active: true,
          duration: 0,
          collected: false,
        })
      }
    }

    // Create particles
    const createParticles = (x: number, y: number, count: number, color: string, size = 5) => {
      for (let i = 0; i < count; i++) {
        gameStateRef.current.particles.push({
          x,
          y,
          size: Math.random() * size + 1,
          color,
          speed: Math.random() * 3 + 0.5,
          angle: Math.random() * Math.PI * 2,
          alpha: 1,
          decay: 0.01 + Math.random() * 0.03,
        })
      }
    }

    // Create explosion
    const createExplosion = (x: number, y: number, size: number) => {
      gameStateRef.current.explosions.push({
        x,
        y,
        size,
        frame: 0,
        maxFrames: 8,
        frameTime: 80,
        lastFrameUpdate: gameStateRef.current.gameTime,
      })

      // Create particles for additional effect
      createParticles(x, y, 30, "#FF2D95", 5)
      createParticles(x, y, 20, "#FFFF00", 3)
    }

    // Shoot function
    const shoot = () => {
      const now = Date.now()
      const { player, lastShot, shotCooldown } = gameStateRef.current

      if (now - lastShot < shotCooldown) return

      gameStateRef.current.lastShot = now

      // Create bullet
      const bulletSpeed = 10
      const bulletDamage = player.powerUps.damage.active ? 2 : 1

      gameStateRef.current.bullets.push({
        id: gameStateRef.current.nextBulletId++,
        x: player.x + Math.cos(player.angle) * player.size,
        y: player.y + Math.sin(player.angle) * player.size,
        speed: bulletSpeed,
        angle: player.angle,
        damage: bulletDamage,
        size: 5,
        color: player.powerUps.damage.active ? "#FF2D95" : "#00FFFF",
        isPlayerBullet: true,
      })

      // Create muzzle flash particles
      createParticles(
        player.x + Math.cos(player.angle) * player.size,
        player.y + Math.sin(player.angle) * player.size,
        5,
        "#FFFFFF",
        3,
      )

      // Play sound if not muted
      if (!muted) {
        const shootSound = new Audio()
        shootSound.src = "data:audio/wav;base64,UklGRiQEAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YQAEAAD"
        shootSound.volume = 0.2
        shootSound.play()
      }
    }

    // Enemy shoot function
    const enemyShoot = (enemy: Enemy) => {
      const now = Date.now()
      if (enemy.shootCooldown === 0 || now - enemy.lastShot < enemy.shootCooldown) return

      enemy.lastShot = now

      // Calculate angle to player
      const dx = gameStateRef.current.player.x - enemy.x
      const dy = gameStateRef.current.player.y - enemy.y
      const angle = Math.atan2(dy, dx)

      // Add some randomness to aim
      const randomAngle = angle + (Math.random() - 0.5) * 0.5

      gameStateRef.current.bullets.push({
        id: gameStateRef.current.nextBulletId++,
        x: enemy.x + Math.cos(randomAngle) * enemy.size,
        y: enemy.y + Math.sin(randomAngle) * enemy.size,
        speed: 5,
        angle: randomAngle,
        damage: 1,
        size: 4,
        color: enemy.color,
        isPlayerBullet: false,
      })
    }

    // Update player
    const updatePlayer = (deltaTime: number) => {
      const { player, keys } = gameStateRef.current

      // Movement
      const playerSpeed = player.powerUps.speed.active ? player.speed * 1.5 : player.speed

      if (keys.w || keys.up) player.y -= playerSpeed
      if (keys.s || keys.down) player.y += playerSpeed
      if (keys.a || keys.left) player.x -= playerSpeed
      if (keys.d || keys.right) player.x += playerSpeed

      // Keep player in bounds
      player.x = Math.max(player.size, Math.min(canvas.width - player.size, player.x))
      player.y = Math.max(player.size, Math.min(canvas.height - player.size, player.y))

      // Dash
      if (keys.space && !player.dashing) {
        player.dashing = true
        player.dashCooldown = 500
        player.dashDirection = player.angle
        player.dashDistance = 100
        player.dashSpeed = 20

        // Create dash particles
        createParticles(player.x, player.y, 20, "#00FFFF", 3)
      }

      // Shooting
      if (gameStateRef.current.mouse.clicked) {
        shoot()
      }

      // Update power-up durations
      Object.keys(player.powerUps).forEach((key) => {
        const powerUp = player.powerUps[key as keyof typeof player.powerUps]
        if (powerUp.active) {
          powerUp.duration -= deltaTime * 1000
          if (powerUp.duration <= 0) {
            powerUp.active = false
          }
        }
      })

      // Update invulnerability
      if (player.invulnerable) {
        player.invulnerabilityTime -= deltaTime * 1000
        if (player.invulnerabilityTime <= 0) {
          player.invulnerable = false
        }
      }
    }

    // Update enemies
    const updateEnemies = (deltaTime: number) => {
      const { enemies, player } = gameStateRef.current

      enemies.forEach((enemy, index) => {
        // Move towards player
        const dx = player.x - enemy.x
        const dy = player.y - enemy.y
        const distance = Math.sqrt(dx * dx + dy * dy)

        enemy.angle = Math.atan2(dy, dx)

        if (distance > enemy.size + player.size) {
          enemy.x += Math.cos(enemy.angle) * enemy.speed
          enemy.y += Math.sin(enemy.angle) * enemy.speed
        }

        // Enemy shooting
        if (enemy.type === "hunter" || enemy.type === "tank") {
          enemyShoot(enemy)
        }

        // Check collision with player
        if (distance < enemy.size + player.size && !player.invulnerable) {
          // Player takes damage
          if (player.shield > 0) {
            player.shield -= 10
            if (player.shield < 0) player.shield = 0
          } else {
            player.health -= 10
          }

          // Player becomes invulnerable briefly
          player.invulnerable = true
          player.invulnerabilityTime = 1000

          // Create hit particles
          createParticles(player.x, player.y, 10, "#FF2D95", 3)
        }
      })
    }

    // Update bullets
    const updateBullets = (deltaTime: number) => {
      const { bullets, enemies, player } = gameStateRef.current

      for (let i = bullets.length - 1; i >= 0; i--) {
        const bullet = bullets[i]

        // Move bullet
        bullet.x += Math.cos(bullet.angle) * bullet.speed
        bullet.y += Math.sin(bullet.angle) * bullet.speed

        // Check if bullet is out of bounds
        if (bullet.x < 0 || bullet.x > canvas.width || bullet.y < 0 || bullet.y > canvas.height) {
          bullets.splice(i, 1)
          continue
        }

        // Check collision with enemies
        if (bullet.isPlayerBullet) {
          for (let j = enemies.length - 1; j >= 0; j--) {
            const enemy = enemies[j]
            const dx = bullet.x - enemy.x
            const dy = bullet.y - enemy.y
            const distance = Math.sqrt(dx * dx + dy * dy)

            if (distance < enemy.size + bullet.size) {
              // Hit enemy
              enemy.health -= bullet.damage

              // Create hit particles
              createParticles(bullet.x, bullet.y, 10, enemy.color, 3)

              // Remove bullet
              bullets.splice(i, 1)

              // Check if enemy is dead
              if (enemy.health <= 0) {
                // Create explosion
                createExplosion(enemy.x, enemy.y, enemy.size * 2)

                // Remove enemy
                enemies.splice(j, 1)

                // Increase score
                gameStateRef.current.score += enemy.type === "drone" ? 10 : enemy.type === "hunter" ? 20 : 50
                gameStateRef.current.enemiesKilled++

                // Check for level up
                if (gameStateRef.current.enemiesKilled >= gameStateRef.current.enemiesRequired) {
                  gameStateRef.current.level++
                  gameStateRef.current.enemiesKilled = 0
                  gameStateRef.current.enemiesRequired = 10 + gameStateRef.current.level * 5
                  setLevel(gameStateRef.current.level)
                }
              }

              break
            }
          }
        } else {
          // Check collision with player
          const dx = bullet.x - player.x
          const dy = bullet.y - player.y
          const distance = Math.sqrt(dx * dx + dy * dy)

          if (distance < player.size + bullet.size && !player.invulnerable) {
            // Player takes damage
            if (player.shield > 0) {
              player.shield -= bullet.damage * 5
              if (player.shield < 0) player.shield = 0
            } else {
              player.health -= bullet.damage * 5
            }

            // Player becomes invulnerable briefly
            player.invulnerable = true
            player.invulnerabilityTime = 500

            // Create hit particles
            createParticles(bullet.x, bullet.y, 10, "#FF2D95", 3)

            // Remove bullet
            bullets.splice(i, 1)
          }
        }
      }
    }

    // Update particles
    const updateParticles = (deltaTime: number) => {
      const { particles } = gameStateRef.current

      for (let i = particles.length - 1; i >= 0; i--) {
        const particle = particles[i]

        // Move particle
        particle.x += Math.cos(particle.angle) * particle.speed
        particle.y += Math.sin(particle.angle) * particle.speed

        // Fade particle
        particle.alpha -= particle.decay

        // Remove faded particles
        if (particle.alpha <= 0) {
          particles.splice(i, 1)
        }
      }
    }

    // Update power-ups
    const updatePowerUps = (deltaTime: number) => {
      const { powerUps, player } = gameStateRef.current

      for (let i = powerUps.length - 1; i >= 0; i--) {
        const powerUp = powerUps[i]

        // Check collision with player
        const dx = powerUp.x - player.x
        const dy = powerUp.y - player.y
        const distance = Math.sqrt(dx * dx + dy * dy)

        if (distance < player.size + powerUp.size) {
          // Collect power-up
          powerUp.collected = true

          // Apply power-up effect
          switch (powerUp.type) {
            case "health":
              player.health = Math.min(player.health + 25, player.maxHealth)
              break
            case "speed":
              player.powerUps.speed.active = true
              player.powerUps.speed.duration = 10000
              break
            case "damage":
              player.powerUps.damage.active = true
              player.powerUps.damage.duration = 10000
              break
            case "shield":
              player.shield = player.maxShield
              break
          }

          // Create particles
          createParticles(powerUp.x, powerUp.y, 20, powerUp.color, 3)

          // Remove power-up
          powerUps.splice(i, 1)
        }
      }
    }

    // Update explosions
    const updateExplosions = (deltaTime: number) => {
      const { explosions, gameTime } = gameStateRef.current

      for (let i = explosions.length - 1; i >= 0; i--) {
        const explosion = explosions[i]

        // Update frame
        if (gameTime - explosion.lastFrameUpdate > explosion.frameTime) {
          explosion.frame++
          explosion.lastFrameUpdate = gameTime

          // Remove completed explosions
          if (explosion.frame >= explosion.maxFrames) {
            explosions.splice(i, 1)
          }
        }
      }
    }

    // Draw player
    const drawPlayer = (ctx: CanvasRenderingContext2D) => {
      const { player } = gameStateRef.current

      ctx.save()
      ctx.translate(player.x, player.y)
      ctx.rotate(player.angle)

      // Draw player ship
      ctx.fillStyle = player.invulnerable
        ? Math.floor(gameStateRef.current.gameTime / 100) % 2 === 0
          ? "#FFFFFF"
          : "#00FFFF"
        : "#00FFFF"

      // Ship body
      ctx.beginPath()
      ctx.moveTo(player.size, 0)
      ctx.lineTo(-player.size / 2, -player.size / 2)
      ctx.lineTo(-player.size / 2, player.size / 2)
      ctx.closePath()
      ctx.fill()

      // Glow effect
      ctx.shadowBlur = 10
      ctx.shadowColor = "#00FFFF"
      ctx.fill()
      ctx.shadowBlur = 0

      // Engine flame
      if (gameStateRef.current.keys.w || gameStateRef.current.keys.up) {
        ctx.beginPath()
        ctx.moveTo(-player.size / 2, 0)
        ctx.lineTo(-player.size, -player.size / 4)
        ctx.lineTo(-player.size - Math.random() * 10, 0)
        ctx.lineTo(-player.size, player.size / 4)
        ctx.closePath()
        ctx.fillStyle = "#FFFF00"
        ctx.fill()
      }

      ctx.restore()

      // Draw shield if active
      if (player.shield > 0) {
        ctx.beginPath()
        ctx.arc(player.x, player.y, player.size + 10, 0, Math.PI * 2)
        ctx.strokeStyle = "#00FFFF"
        ctx.lineWidth = 2
        ctx.stroke()

        // Shield strength indicator
        const shieldPercent = player.shield / player.maxShield
        ctx.beginPath()
        ctx.arc(player.x, player.y, player.size + 10, 0, Math.PI * 2 * shieldPercent)
        ctx.strokeStyle = "#00FFFF"
        ctx.lineWidth = 3
        ctx.stroke()
      }
    }

    // Draw enemies
    const drawEnemies = (ctx: CanvasRenderingContext2D) => {
      const { enemies } = gameStateRef.current

      enemies.forEach((enemy) => {
        ctx.save()
        ctx.translate(enemy.x, enemy.y)
        ctx.rotate(enemy.angle)

        // Enemy body
        ctx.fillStyle = enemy.color
        ctx.beginPath()

        if (enemy.type === "drone") {
          // Triangle shape
          ctx.moveTo(enemy.size, 0)
          ctx.lineTo(-enemy.size / 2, -enemy.size / 2)
          ctx.lineTo(-enemy.size / 2, enemy.size / 2)
          ctx.closePath()
        } else if (enemy.type === "hunter") {
          // Diamond shape
          ctx.moveTo(enemy.size, 0)
          ctx.lineTo(0, -enemy.size / 2)
          ctx.lineTo(-enemy.size / 2, 0)
          ctx.lineTo(0, enemy.size / 2)
          ctx.closePath()
        } else {
          // Tank - hexagon shape
          for (let i = 0; i < 6; i++) {
            const angle = ((Math.PI * 2) / 6) * i
            const x = Math.cos(angle) * enemy.size
            const y = Math.sin(angle) * enemy.size
            if (i === 0) ctx.moveTo(x, y)
            else ctx.lineTo(x, y)
          }
          ctx.closePath()
        }

        ctx.fill()

        // Glow effect
        ctx.shadowBlur = 10
        ctx.shadowColor = enemy.color
        ctx.fill()

        ctx.restore()

        // Health bar
        const healthBarWidth = enemy.size * 2
        const healthBarHeight = 4
        const healthPercent = enemy.health / enemy.maxHealth

        ctx.fillStyle = "#1A1145"
        ctx.fillRect(enemy.x - healthBarWidth / 2, enemy.y - enemy.size - 10, healthBarWidth, healthBarHeight)

        ctx.fillStyle = enemy.color
        ctx.fillRect(
          enemy.x - healthBarWidth / 2,
          enemy.y - enemy.size - 10,
          healthBarWidth * healthPercent,
          healthBarHeight,
        )
      })
    }

    // Draw bullets
    const drawBullets = (ctx: CanvasRenderingContext2D) => {
      const { bullets } = gameStateRef.current

      bullets.forEach((bullet) => {
        // Draw bullet
        ctx.beginPath()
        ctx.arc(bullet.x, bullet.y, bullet.size, 0, Math.PI * 2)
        ctx.fillStyle = bullet.color
        ctx.fill()

        // Glow effect
        ctx.shadowBlur = 10
        ctx.shadowColor = bullet.color
        ctx.fill()
        ctx.shadowBlur = 0

        // Bullet trail
        createParticles(bullet.x, bullet.y, 1, bullet.color, 2)
      })
    }

    // Draw particles
    const drawParticles = (ctx: CanvasRenderingContext2D) => {
      const { particles } = gameStateRef.current

      particles.forEach((particle) => {
        ctx.beginPath()
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2)
        ctx.fillStyle = particle.color
        ctx.globalAlpha = particle.alpha
        ctx.fill()
        ctx.globalAlpha = 1
      })
    }

    // Draw power-ups
    const drawPowerUps = (ctx: CanvasRenderingContext2D) => {
      const { powerUps, gameTime } = gameStateRef.current

      powerUps.forEach((powerUp) => {
        // Pulsating effect
        const pulse = 1 + Math.sin(gameTime / 200) * 0.1

        ctx.beginPath()
        ctx.arc(powerUp.x, powerUp.y, powerUp.size * pulse, 0, Math.PI * 2)
        ctx.fillStyle = powerUp.color
        ctx.fill()

        // Glow effect
        ctx.shadowBlur = 15
        ctx.shadowColor = powerUp.color
        ctx.fill()
        ctx.shadowBlur = 0

        // Icon based on type
        ctx.fillStyle = "#FFFFFF"
        ctx.font = "16px Arial"
        ctx.textAlign = "center"
        ctx.textBaseline = "middle"

        let icon = ""
        switch (powerUp.type) {
          case "health":
            icon = "❤️"
            break
          case "speed":
            icon = "⚡"
            break
          case "damage":
            icon = "🔥"
            break
          case "shield":
            icon = "🛡️"
            break
        }

        ctx.fillText(icon, powerUp.x, powerUp.y)
      })
    }

    // Draw explosions
    const drawExplosions = (ctx: CanvasRenderingContext2D) => {
      const { explosions } = gameStateRef.current

      explosions.forEach((explosion) => {
        const size = explosion.size * (1 + explosion.frame / explosion.maxFrames)

        ctx.beginPath()
        ctx.arc(explosion.x, explosion.y, size, 0, Math.PI * 2)

        const gradient = ctx.createRadialGradient(explosion.x, explosion.y, 0, explosion.x, explosion.y, size)

        gradient.addColorStop(0, "#FFFFFF")
        gradient.addColorStop(0.4, "#FFFF00")
        gradient.addColorStop(0.6, "#FF2D95")
        gradient.addColorStop(1, "rgba(0, 0, 0, 0)")

        ctx.fillStyle = gradient
        ctx.fill()
      })
    }

    // Draw UI
    const drawUI = (ctx: CanvasRenderingContext2D) => {
      const { player, score, level } = gameStateRef.current

      // Health bar
      const healthBarWidth = 200
      const healthBarHeight = 20
      const healthPercent = player.health / player.maxHealth

      ctx.fillStyle = "rgba(0, 0, 0, 0.5)"
      ctx.fillRect(20, 20, healthBarWidth, healthBarHeight)

      ctx.fillStyle = "#00FF80"
      ctx.fillRect(20, 20, healthBarWidth * healthPercent, healthBarHeight)

      ctx.strokeStyle = "#FFFFFF"
      ctx.lineWidth = 2
      ctx.strokeRect(20, 20, healthBarWidth, healthBarHeight)

      // Shield bar
      if (player.maxShield > 0) {
        const shieldPercent = player.shield / player.maxShield

        ctx.fillStyle = "rgba(0, 0, 0, 0.5)"
        ctx.fillRect(20, 50, healthBarWidth, healthBarHeight)

        ctx.fillStyle = "#00FFFF"
        ctx.fillRect(20, 50, healthBarWidth * shieldPercent, healthBarHeight)

        ctx.strokeStyle = "#FFFFFF"
        ctx.lineWidth = 2
        ctx.strokeRect(20, 50, healthBarWidth, healthBarHeight)
      }

      // Score and level
      ctx.fillStyle = "#FFFFFF"
      ctx.font = "20px Arial"
      ctx.textAlign = "right"
      ctx.fillText(`Score: ${score}`, canvas.width - 20, 30)
      ctx.fillText(`Level: ${level}`, canvas.width - 20, 60)

      // Power-up indicators
      let powerUpY = 90
      Object.entries(player.powerUps).forEach(([key, powerUp]) => {
        if (powerUp.active) {
          let color, name
          switch (key) {
            case "speed":
              color = "#FFFF00"
              name = "Speed Boost"
              break
            case "damage":
              color = "#FF2D95"
              name = "Damage Boost"
              break
            case "shield":
              color = "#00FFFF"
              name = "Shield"
              break
          }

          const duration = Math.max(0, Math.ceil(powerUp.duration / 1000))

          ctx.fillStyle = color
          ctx.fillText(`${name}: ${duration}s`, canvas.width - 20, powerUpY)
          powerUpY += 30
        }
      })
    }

    // Game loop
    let lastTime = 0
    const gameLoop = (timestamp: number) => {
      if (gamePaused || gameOver) return

      const deltaTime = timestamp - lastTime
      lastTime = timestamp

      gameStateRef.current.gameTime += deltaTime

      // Clear canvas
      ctx.fillStyle = "#0F0B2A"
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      // Draw background
      const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height)
      gradient.addColorStop(0, "#0F0B2A")
      gradient.addColorStop(1, "#1A1145")
      ctx.fillStyle = gradient
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      // Draw grid lines
      ctx.strokeStyle = "rgba(102, 51, 153, 0.1)"
      ctx.lineWidth = 1

      // Horizontal lines
      for (let y = 0; y < canvas.height; y += 40) {
        ctx.beginPath()
        ctx.moveTo(0, y)
        ctx.lineTo(canvas.width, y)
        ctx.stroke()
      }

      // Vertical lines
      for (let x = 0; x < canvas.width; x += 40) {
        ctx.beginPath()
        ctx.moveTo(x, 0)
        ctx.lineTo(x, canvas.height)
        ctx.stroke()
      }

      // Spawn enemies
      spawnEnemies()

      // Spawn power-ups
      spawnPowerUp()

      // Update player
      updatePlayer(deltaTime / 1000)

      // Update enemies
      updateEnemies(deltaTime / 1000)

      // Update bullets
      updateBullets(deltaTime / 1000)

      // Update particles
      updateParticles(deltaTime / 1000)

      // Update power-ups
      updatePowerUps(deltaTime / 1000)

      // Update explosions
      updateExplosions(deltaTime / 1000)

      // Draw player
      drawPlayer(ctx)

      // Draw enemies
      drawEnemies(ctx)

      // Draw bullets
      drawBullets(ctx)

      // Draw particles
      drawParticles(ctx)

      // Draw power-ups
      drawPowerUps(ctx)

      // Draw explosions
      drawExplosions(ctx)

      // Draw UI
      drawUI(ctx)

      // Check for game over
      if (gameStateRef.current.player.health <= 0) {
        setGameOver(true)
      }

      // Update UI
      setScore(gameStateRef.current.score)
      setPlayerHealth(gameStateRef.current.player.health)

      requestAnimationFrame(gameLoop)
    }

    requestAnimationFrame(gameLoop)

    return () => {
      window.removeEventListener("keydown", handleKeyDown)
      window.removeEventListener("keyup", handleKeyUp)
      canvas.removeEventListener("mousemove", handleMouseMove)
      canvas.removeEventListener("mousedown", handleMouseDown)
      canvas.removeEventListener("mouseup", handleMouseUp)
    }
  }, [gameStarted, gamePaused, gameOver, level, muted])

  // Start game
  const startGame = () => {
    setGameStarted(true)
    setGameOver(false)
    setLevel(1)
  }

  // Reset game
  const resetGame = () => {
    setGameStarted(false)
    setGameOver(false)
    setGamePaused(false)
  }

  // Toggle pause
  const togglePause = () => {
    setGamePaused(!gamePaused)
  }

  // Toggle mute
  const toggleMute = () => {
    setMuted(!muted)
  }

  return (
    <div className="relative">
      {/* Game canvas */}
      <canvas ref={canvasRef} className="bg-[#0F0B2A] rounded-lg shadow-lg" width={800} height={600} />

      {/* Game UI overlay */}
      <div className="absolute top-4 left-4 flex items-center space-x-4">
        <Badge className="bg-[#00FFFF] text-black px-3 py-1">Score: {score}</Badge>
        <Badge className="bg-[#FF2D95] text-white px-3 py-1">Level: {level}</Badge>
      </div>

      {/* Health bar */}
      <div className="absolute top-4 left-1/2 transform -translate-x-1/2 w-48">
        <div className="h-4 bg-black/50 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-[#00FF80] to-[#00FFFF] transition-all duration-300"
            style={{ width: `${(playerHealth / 100) * 100}%` }}
          />
        </div>
        <div className="text-center text-xs text-white mt-1">Health: {playerHealth}/100</div>
      </div>

      {/* Game controls */}
      <div className="absolute top-4 right-4 flex items-center space-x-2">
        <Button
          size="icon"
          variant="outline"
          className="bg-[#1A1145]/50 border-[#3A2A65] text-white hover:bg-[#3A2A65]/50"
          onClick={toggleMute}
        >
          {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
        </Button>

        <Button
          size="icon"
          variant="outline"
          className="bg-[#1A1145]/50 border-[#3A2A65] text-white hover:bg-[#3A2A65]/50"
          onClick={togglePause}
        >
          {gamePaused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
        </Button>

        <Button
          size="icon"
          variant="outline"
          className="bg-[#1A1145]/50 border-[#3A2A65] text-white hover:bg-[#3A2A65]/50"
          onClick={resetGame}
        >
          <RotateCcw className="h-4 w-4" />
        </Button>
      </div>

      {/* Game start overlay */}
      {!gameStarted && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#0F0B2A]/80 rounded-lg">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4 text-[#FF2D95]">Neon Fury</h2>
            <p className="text-[#E0E0FF] mb-6 max-w-md">
              Fast-paced cyberpunk shooter with stunning visuals and intense combat. Use WASD to move, mouse to aim and
              shoot, and SPACE to dash.
            </p>
            <Button
              onClick={startGame}
              className="bg-gradient-to-r from-[#FF2D95] to-[#9D00FF] text-white font-bold hover:from-[#FF5CAD] hover:to-[#B347FF]"
            >
              Start Game
            </Button>
          </div>
        </div>
      )}

      {/* Game over overlay */}
      {gameOver && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#0F0B2A]/80 rounded-lg">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4 text-[#FF2D95]">Game Over</h2>
            <p className="text-2xl text-[#E0E0FF] mb-2">Final Score: {score}</p>
            <p className="text-[#E0E0FF] mb-6">You reached level {level}!</p>
            <Button
              onClick={resetGame}
              className="bg-gradient-to-r from-[#FF2D95] to-[#9D00FF] text-white font-bold hover:from-[#FF5CAD] hover:to-[#B347FF]"
            >
              Play Again
            </Button>
          </div>
        </div>
      )}

      {/* Pause overlay */}
      {gameStarted && gamePaused && !gameOver && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#0F0B2A]/80 rounded-lg">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4 text-[#FF2D95]">Game Paused</h2>
            <Button
              onClick={togglePause}
              className="bg-gradient-to-r from-[#FF2D95] to-[#9D00FF] text-white font-bold hover:from-[#FF5CAD] hover:to-[#B347FF]"
            >
              Resume
            </Button>
          </div>
        </div>
      )}

      {/* Controls help */}
      <div className="absolute bottom-4 left-4 text-[#E0E0FF] text-xs">
        <p>WASD or Arrow Keys: Move</p>
        <p>Mouse: Aim and Shoot</p>
        <p>Space: Dash</p>
      </div>
    </div>
  )
}
