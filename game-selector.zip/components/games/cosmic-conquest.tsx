"use client"

import { useEffect, useRef, useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Play, Pause, RotateCcw, Volume2, VolumeX } from "lucide-react"

interface Star {
  id: number
  x: number
  y: number
  size: number
  color: string
  owner: "neutral" | "player" | "enemy"
  ships: number
  production: number
  selected: boolean
}

interface Fleet {
  id: number
  sourceId: number
  targetId: number
  x: number
  y: number
  ships: number
  owner: "player" | "enemy"
  progress: number
  angle: number
}

export default function CosmicConquestGame() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [gameStarted, setGameStarted] = useState(false)
  const [gamePaused, setGamePaused] = useState(false)
  const [gameOver, setGameOver] = useState(false)
  const [score, setScore] = useState(0)
  const [muted, setMuted] = useState(false)
  const [selectedStar, setSelectedStar] = useState<number | null>(null)

  // Game state
  const gameStateRef = useRef({
    stars: [] as Star[],
    fleets: [] as Fleet[],
    mouse: {
      x: 0,
      y: 0,
      clicked: false,
      rightClicked: false,
    },
    gameTime: 0,
    score: 0,
    nextId: 1,
    nextFleetId: 1,
  })

  // Initialize game
  const initializeGame = () => {
    if (!canvasRef.current) return

    const canvas = canvasRef.current
    const width = canvas.width
    const height = canvas.height

    // Create stars
    const stars: Star[] = []

    // Player's home star
    stars.push({
      id: gameStateRef.current.nextId++,
      x: width * 0.2,
      y: height * 0.5,
      size: 30,
      color: "#00FFFF",
      owner: "player",
      ships: 20,
      production: 1,
      selected: false,
    })

    // Enemy's home star
    stars.push({
      id: gameStateRef.current.nextId++,
      x: width * 0.8,
      y: height * 0.5,
      size: 30,
      color: "#FF2D95",
      owner: "enemy",
      ships: 20,
      production: 1,
      selected: false,
    })

    // Neutral stars
    for (let i = 0; i < 8; i++) {
      const x = 100 + Math.random() * (width - 200)
      const y = 100 + Math.random() * (height - 200)

      // Ensure stars aren't too close to each other
      let tooClose = false
      for (const star of stars) {
        const dx = x - star.x
        const dy = y - star.y
        const distance = Math.sqrt(dx * dx + dy * dy)
        if (distance < 100) {
          tooClose = true
          break
        }
      }

      if (!tooClose) {
        stars.push({
          id: gameStateRef.current.nextId++,
          x,
          y,
          size: 15 + Math.random() * 10,
          color: "#FFFFFF",
          owner: "neutral",
          ships: 5 + Math.floor(Math.random() * 10),
          production: 0.5 + Math.random() * 0.5,
          selected: false,
        })
      } else {
        // Try again
        i--
      }
    }

    gameStateRef.current.stars = stars
  }

  // Start game
  const startGame = () => {
    setGameStarted(true)
    setGameOver(false)
    setScore(0)
    gameStateRef.current.score = 0
    gameStateRef.current.nextId = 1
    gameStateRef.current.nextFleetId = 1
    gameStateRef.current.stars = []
    gameStateRef.current.fleets = []
    gameStateRef.current.gameTime = 0

    initializeGame()
  }

  // Reset game
  const resetGame = () => {
    setGameStarted(false)
    setGameOver(false)
    setGamePaused(false)
  }

  // Toggle pause
  const togglePause = () => {
    setGamePaused(!gamePaused)
  }

  // Toggle mute
  const toggleMute = () => {
    setMuted(!muted)
  }

  // Initialize canvas and event listeners
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    // Set canvas dimensions
    canvas.width = 800
    canvas.height = 600

    // Event listeners
    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect()
      gameStateRef.current.mouse.x = e.clientX - rect.left
      gameStateRef.current.mouse.y = e.clientY - rect.top
    }

    const handleMouseDown = (e: MouseEvent) => {
      if (e.button === 0) {
        gameStateRef.current.mouse.clicked = true
      } else if (e.button === 2) {
        gameStateRef.current.mouse.rightClicked = true
      }
    }

    const handleMouseUp = (e: MouseEvent) => {
      if (e.button === 0) {
        gameStateRef.current.mouse.clicked = false
      } else if (e.button === 2) {
        gameStateRef.current.mouse.rightClicked = false
      }
    }

    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault()
    }

    canvas.addEventListener("mousemove", handleMouseMove)
    canvas.addEventListener("mousedown", handleMouseDown)
    canvas.addEventListener("mouseup", handleMouseUp)
    canvas.addEventListener("contextmenu", handleContextMenu)

    return () => {
      canvas.removeEventListener("mousemove", handleMouseMove)
      canvas.removeEventListener("mousedown", handleMouseDown)
      canvas.removeEventListener("mouseup", handleMouseUp)
      canvas.removeEventListener("contextmenu", handleContextMenu)
    }
  }, [])

  // Game loop
  useEffect(() => {
    if (!gameStarted || gamePaused || gameOver) return

    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    let animationFrameId: number
    let lastTime = 0

    const gameLoop = (timestamp: number) => {
      if (!gameStarted || gamePaused || gameOver) return

      const deltaTime = timestamp - lastTime
      lastTime = timestamp

      gameStateRef.current.gameTime += deltaTime

      // Clear canvas
      ctx.fillStyle = "#0F0B2A"
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      // Draw stars
      drawStars(ctx)

      // Draw fleets
      drawFleets(ctx)

      // Handle mouse input
      handleMouseInput()

      // Update game state
      updateGameState(deltaTime / 1000)

      // Check win/lose condition
      checkGameOver()

      // Update UI
      setScore(gameStateRef.current.score)

      animationFrameId = requestAnimationFrame(gameLoop)
    }

    animationFrameId = requestAnimationFrame(gameLoop)

    return () => {
      cancelAnimationFrame(animationFrameId)
    }
  }, [gameStarted, gamePaused, gameOver])

  // Draw stars
  const drawStars = (ctx: CanvasRenderingContext2D) => {
    gameStateRef.current.stars.forEach((star) => {
      // Draw star glow
      ctx.beginPath()
      ctx.arc(star.x, star.y, star.size + 10, 0, Math.PI * 2)
      const gradient = ctx.createRadialGradient(star.x, star.y, star.size, star.x, star.y, star.size + 10)
      gradient.addColorStop(0, star.owner === "player" ? "#00FFFF" : star.owner === "enemy" ? "#FF2D95" : "#FFFFFF")
      gradient.addColorStop(1, "rgba(0, 0, 0, 0)")
      ctx.fillStyle = gradient
      ctx.fill()

      // Draw star
      ctx.beginPath()
      ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2)
      ctx.fillStyle = star.owner === "player" ? "#00FFFF" : star.owner === "enemy" ? "#FF2D95" : "#FFFFFF"
      ctx.fill()

      // Draw selection indicator
      if (star.selected) {
        ctx.beginPath()
        ctx.arc(star.x, star.y, star.size + 5, 0, Math.PI * 2)
        ctx.strokeStyle = "#FFFF00"
        ctx.lineWidth = 2
        ctx.stroke()
      }

      // Draw ship count
      ctx.font = "16px Arial"
      ctx.fillStyle = "#FFFFFF"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(Math.floor(star.ships).toString(), star.x, star.y)
    })
  }

  // Draw fleets
  const drawFleets = (ctx: CanvasRenderingContext2D) => {
    gameStateRef.current.fleets.forEach((fleet) => {
      // Draw fleet
      ctx.save()
      ctx.translate(fleet.x, fleet.y)
      ctx.rotate(fleet.angle)

      // Draw ships
      const shipCount = Math.min(fleet.ships, 5)
      const shipSpacing = 10
      const fleetWidth = (shipCount - 1) * shipSpacing

      for (let i = 0; i < shipCount; i++) {
        const shipX = -fleetWidth / 2 + i * shipSpacing

        // Draw ship
        ctx.beginPath()
        ctx.moveTo(shipX + 5, 0)
        ctx.lineTo(shipX - 3, -3)
        ctx.lineTo(shipX - 3, 3)
        ctx.closePath()
        ctx.fillStyle = fleet.owner === "player" ? "#00FFFF" : "#FF2D95"
        ctx.fill()
      }

      ctx.restore()

      // Draw ship count if more than 5
      if (fleet.ships > 5) {
        ctx.font = "12px Arial"
        ctx.fillStyle = "#FFFFFF"
        ctx.textAlign = "center"
        ctx.textBaseline = "middle"
        ctx.fillText(`+${Math.floor(fleet.ships - 5)}`, fleet.x, fleet.y - 15)
      }
    })
  }

  // Handle mouse input
  const handleMouseInput = () => {
    const { mouse, stars } = gameStateRef.current

    // Left click
    if (mouse.clicked) {
      mouse.clicked = false

      // Check if clicked on a star
      let clickedStar = false
      for (const star of stars) {
        const dx = mouse.x - star.x
        const dy = mouse.y - star.y
        const distance = Math.sqrt(dx * dx + dy * dy)

        if (distance < star.size) {
          clickedStar = true

          if (star.owner === "player") {
            // Select player's star
            stars.forEach((s) => (s.selected = false))
            star.selected = true
            setSelectedStar(star.id)
          } else if (selectedStar !== null) {
            // Send fleet from selected star to this star
            const sourceStar = stars.find((s) => s.id === selectedStar)
            if (sourceStar && sourceStar.ships > 1) {
              // Calculate ships to send (half of available ships)
              const shipsToSend = Math.floor(sourceStar.ships / 2)
              sourceStar.ships -= shipsToSend

              // Calculate angle
              const dx = star.x - sourceStar.x
              const dy = star.y - sourceStar.y
              const angle = Math.atan2(dy, dx)

              // Create fleet
              gameStateRef.current.fleets.push({
                id: gameStateRef.current.nextFleetId++,
                sourceId: sourceStar.id,
                targetId: star.id,
                x: sourceStar.x,
                y: sourceStar.y,
                ships: shipsToSend,
                owner: "player",
                progress: 0,
                angle,
              })

              // Play sound
              if (!muted) {
                const sendSound = new Audio()
                sendSound.src =
                  "data:audio/wav;base64,UklGRiQDAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YQADAAD////////+/////f////v////3////8/////H////w////8P////D////y////9f////n////+//////////////////////////7////7////9/////P////w////7v///+3////t////7v///+/////y////9/////z///8AAAAA/////v////v////4////9P////H////v////7f///+z////s////7f///+/////y////9/////z///8AAAAA/////v////r////3////8/////D////u////7P///+v////r////7P///+7////x////9v////v///8AAAAA/////v////r////3////8/////D////u////7P///+v////r////7P///+7////x////9v////v///8="
                sendSound.volume = 0.2
                sendSound.play()
              }
            }
          }

          break
        }
      }

      if (!clickedStar && selectedStar !== null) {
        // Deselect star
        stars.forEach((s) => (s.selected = false))
        setSelectedStar(null)
      }
    }

    // Right click
    if (mouse.rightClicked) {
      mouse.rightClicked = false

      // Deselect star
      stars.forEach((s) => (s.selected = false))
      setSelectedStar(null)
    }
  }

  // Update game state
  const updateGameState = (deltaTime: number) => {
    const { stars, fleets } = gameStateRef.current

    // Update stars
    stars.forEach((star) => {
      if (star.owner !== "neutral") {
        star.ships += star.production * deltaTime
      }
    })

    // Update fleets
    for (let i = fleets.length - 1; i >= 0; i--) {
      const fleet = fleets[i]
      const sourceStar = stars.find((s) => s.id === fleet.sourceId)
      const targetStar = stars.find((s) => s.id === fleet.targetId)

      if (!sourceStar || !targetStar) {
        fleets.splice(i, 1)
        continue
      }

      // Move fleet
      const dx = targetStar.x - sourceStar.x
      const dy = targetStar.y - sourceStar.y
      const distance = Math.sqrt(dx * dx + dy * dy)
      const speed = 100 // pixels per second

      fleet.progress += (speed * deltaTime) / distance
      fleet.x = sourceStar.x + dx * fleet.progress
      fleet.y = sourceStar.y + dy * fleet.progress

      // Check if fleet has arrived
      if (fleet.progress >= 1) {
        // Fleet has arrived
        if (targetStar.owner === fleet.owner) {
          // Friendly star, add ships
          targetStar.ships += fleet.ships
        } else {
          // Enemy star, battle
          targetStar.ships -= fleet.ships

          if (targetStar.ships < 0) {
            // Star captured
            targetStar.owner = fleet.owner
            targetStar.ships = Math.abs(targetStar.ships)
            targetStar.color = fleet.owner === "player" ? "#00FFFF" : "#FF2D95"

            // Update score
            if (fleet.owner === "player") {
              gameStateRef.current.score += 100
            }

            // Play capture sound
            if (!muted) {
              const captureSound = new Audio()
              captureSound.src =
                "data:audio/wav;base64,UklGRiQDAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YQADAAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wAA/v8AAP7/AAD+/wA"
              captureSound.volume = 0.3
              captureSound.play()
            }
          }
        }

        // Remove fleet
        fleets.splice(i, 1)
      }
    }

    // AI logic
    if (Math.random() < 0.01) {
      // Find enemy stars
      const enemyStars = stars.filter((s) => s.owner === "enemy")

      if (enemyStars.length > 0) {
        // Pick a random enemy star as source
        const sourceStar = enemyStars[Math.floor(Math.random() * enemyStars.length)]

        if (sourceStar.ships > 10) {
          // Find potential targets
          const potentialTargets = stars.filter((s) => s.id !== sourceStar.id)

          if (potentialTargets.length > 0) {
            // Prioritize player stars, then neutral stars
            const playerStars = potentialTargets.filter((s) => s.owner === "player")
            const neutralStars = potentialTargets.filter((s) => s.owner === "neutral")

            let targetStar
            if (playerStars.length > 0 && Math.random() < 0.7) {
              // Attack player
              targetStar = playerStars[Math.floor(Math.random() * playerStars.length)]
            } else if (neutralStars.length > 0) {
              // Expand to neutral
              targetStar = neutralStars[Math.floor(Math.random() * neutralStars.length)]
            } else {
              // Reinforce another enemy star
              const otherEnemyStars = enemyStars.filter((s) => s.id !== sourceStar.id)
              if (otherEnemyStars.length > 0) {
                targetStar = otherEnemyStars[Math.floor(Math.random() * otherEnemyStars.length)]
              }
            }

            if (targetStar) {
              // Calculate ships to send
              const shipsToSend = Math.floor(sourceStar.ships * 0.7)
              sourceStar.ships -= shipsToSend

              // Calculate angle
              const dx = targetStar.x - sourceStar.x
              const dy = targetStar.y - sourceStar.y
              const angle = Math.atan2(dy, dx)

              // Create fleet
              gameStateRef.current.fleets.push({
                id: gameStateRef.current.nextFleetId++,
                sourceId: sourceStar.id,
                targetId: targetStar.id,
                x: sourceStar.x,
                y: sourceStar.y,
                ships: shipsToSend,
                owner: "enemy",
                progress: 0,
                angle,
              })
            }
          }
        }
      }
    }
  }

  // Check game over
  const checkGameOver = () => {
    const { stars } = gameStateRef.current

    const playerStars = stars.filter((s) => s.owner === "player")
    const enemyStars = stars.filter((s) => s.owner === "enemy")

    if (playerStars.length === 0) {
      // Player lost
      setGameOver(true)
    } else if (enemyStars.length === 0) {
      // Player won
      setGameOver(true)
      gameStateRef.current.score += 500
      setScore(gameStateRef.current.score)
    }
  }

  return (
    <div className="relative">
      {/* Game canvas */}
      <canvas ref={canvasRef} className="bg-[#0F0B2A] rounded-lg shadow-lg" width={800} height={600} />

      {/* Game UI overlay */}
      <div className="absolute top-4 left-4 flex items-center space-x-4">
        <Badge className="bg-[#00FFFF] text-black px-3 py-1">Score: {score}</Badge>
      </div>

      {/* Game controls */}
      <div className="absolute top-4 right-4 flex items-center space-x-2">
        <Button
          size="icon"
          variant="outline"
          className="bg-[#1A1145]/50 border-[#3A2A65] text-white hover:bg-[#3A2A65]/50"
          onClick={toggleMute}
        >
          {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
        </Button>

        <Button
          size="icon"
          variant="outline"
          className="bg-[#1A1145]/50 border-[#3A2A65] text-white hover:bg-[#3A2A65]/50"
          onClick={togglePause}
        >
          {gamePaused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
        </Button>

        <Button
          size="icon"
          variant="outline"
          className="bg-[#1A1145]/50 border-[#3A2A65] text-white hover:bg-[#3A2A65]/50"
          onClick={resetGame}
        >
          <RotateCcw className="h-4 w-4" />
        </Button>
      </div>

      {/* Game start overlay */}
      {!gameStarted && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#0F0B2A]/80 rounded-lg">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4 text-[#00FFFF]">Cosmic Conquest</h2>
            <p className="text-[#E0E0FF] mb-6 max-w-md">
              Expand your galactic empire by capturing stars and defeating your enemy. Click on your stars and then on
              target stars to send fleets.
            </p>
            <Button
              onClick={startGame}
              className="bg-gradient-to-r from-[#00FFFF] to-[#0080FF] text-black font-bold hover:from-[#00FFFF] hover:to-[#00BFFF]"
            >
              Start Game
            </Button>
          </div>
        </div>
      )}

      {/* Game over overlay */}
      {gameOver && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#0F0B2A]/80 rounded-lg">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4 text-[#00FFFF]">Game Over</h2>
            <p className="text-2xl text-[#E0E0FF] mb-2">Final Score: {score}</p>
            <p className="text-[#E0E0FF] mb-6">
              {gameStateRef.current.stars.some((s) => s.owner === "player")
                ? "Victory! You've conquered the galaxy!"
                : "Defeat! Your empire has been destroyed."}
            </p>
            <Button
              onClick={resetGame}
              className="bg-gradient-to-r from-[#00FFFF] to-[#0080FF] text-black font-bold hover:from-[#00FFFF] hover:to-[#00BFFF]"
            >
              Play Again
            </Button>
          </div>
        </div>
      )}

      {/* Pause overlay */}
      {gameStarted && gamePaused && !gameOver && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#0F0B2A]/80 rounded-lg">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4 text-[#00FFFF]">Game Paused</h2>
            <Button
              onClick={togglePause}
              className="bg-gradient-to-r from-[#00FFFF] to-[#0080FF] text-black font-bold hover:from-[#00FFFF] hover:to-[#00BFFF]"
            >
              Resume
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}
