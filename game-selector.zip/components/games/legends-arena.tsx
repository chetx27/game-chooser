"use client"

import { useEffect, useRef, useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Play, Pause, RotateCcw, Volume2, VolumeX } from "lucide-react"

interface Hero {
  id: number
  name: string
  x: number
  y: number
  size: number
  speed: number
  health: number
  maxHealth: number
  mana: number
  maxMana: number
  damage: number
  defense: number
  attackRange: number
  attackSpeed: number
  lastAttack: number
  team: "player" | "enemy"
  color: string
  abilities: Ability[]
  cooldowns: Record<string, number>
  target: number | null
  state: "idle" | "moving" | "attacking" | "casting"
  path: { x: number; y: number }[]
}

interface Ability {
  id: string
  name: string
  icon: string
  damage: number
  manaCost: number
  cooldown: number
  range: number
  areaOfEffect: number
  duration: number
  description: string
}

interface Projectile {
  id: number
  x: number
  y: number
  targetX: number
  targetY: number
  speed: number
  damage: number
  size: number
  color: string
  sourceId: number
  targetId: number | null
  ability: string | null
}

interface Effect {
  id: number
  x: number
  y: number
  size: number
  color: string
  duration: number
  startTime: number
  type: "explosion" | "heal" | "buff" | "debuff"
}

export default function LegendsArenaGame() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [gameStarted, setGameStarted] = useState(false)
  const [gamePaused, setGamePaused] = useState(false)
  const [gameOver, setGameOver] = useState(false)
  const [score, setScore] = useState(0)
  const [selectedHero, setSelectedHero] = useState<number | null>(null)
  const [selectedAbility, setSelectedAbility] = useState<string | null>(null)
  const [muted, setMuted] = useState(false)
  const [gameResult, setGameResult] = useState<"victory" | "defeat" | null>(null)

  // Game state
  const gameStateRef = useRef({
    heroes: [] as Hero[],
    projectiles: [] as Projectile[],
    effects: [] as Effect[],
    gameTime: 0,
    nextId: 1,
    nextProjectileId: 1,
    nextEffectId: 1,
    mapWidth: 800,
    mapHeight: 600,
    baseRadius: 50,
    playerBaseX: 100,
    playerBaseY: 300,
    enemyBaseX: 700,
    enemyBaseY: 300,
    playerScore: 0,
    enemyScore: 0,
    mouse: {
      x: 0,
      y: 0,
      clicked: false,
      rightClicked: false,
    },
  })

  // Hero templates
  const heroTemplates = [
    {
      name: "Warrior",
      size: 25,
      speed: 3,
      health: 200,
      mana: 100,
      damage: 20,
      defense: 10,
      attackRange: 50,
      attackSpeed: 1000, // ms between attacks
      color: "#FF2D95",
      abilities: [
        {
          id: "whirlwind",
          name: "Whirlwind",
          icon: "🌀",
          damage: 30,
          manaCost: 20,
          cooldown: 5000,
          range: 0,
          areaOfEffect: 100,
          duration: 2000,
          description: "Spin in a circle, damaging all nearby enemies",
        },
        {
          id: "charge",
          name: "Charge",
          icon: "⚡",
          damage: 15,
          manaCost: 15,
          cooldown: 8000,
          range: 200,
          areaOfEffect: 0,
          duration: 0,
          description: "Charge toward an enemy, dealing damage on impact",
        },
      ],
    },
    {
      name: "Mage",
      size: 20,
      speed: 2.5,
      health: 120,
      mana: 200,
      damage: 15,
      defense: 5,
      attackRange: 200,
      attackSpeed: 1200, // ms between attacks
      color: "#00FFFF",
      abilities: [
        {
          id: "fireball",
          name: "Fireball",
          icon: "🔥",
          damage: 40,
          manaCost: 30,
          cooldown: 4000,
          range: 300,
          areaOfEffect: 80,
          duration: 0,
          description: "Launch a fireball that explodes on impact",
        },
        {
          id: "frostNova",
          name: "Frost Nova",
          icon: "❄️",
          damage: 20,
          manaCost: 25,
          cooldown: 6000,
          range: 150,
          areaOfEffect: 120,
          duration: 3000,
          description: "Create a burst of frost that damages and slows enemies",
        },
      ],
    },
    {
      name: "Archer",
      size: 22,
      speed: 3.5,
      health: 150,
      mana: 150,
      damage: 25,
      defense: 7,
      attackRange: 250,
      attackSpeed: 800, // ms between attacks
      color: "#FFFF00",
      abilities: [
        {
          id: "volley",
          name: "Arrow Volley",
          icon: "🏹",
          damage: 35,
          manaCost: 25,
          cooldown: 7000,
          range: 300,
          areaOfEffect: 100,
          duration: 0,
          description: "Fire multiple arrows in an area",
        },
        {
          id: "trap",
          name: "Trap",
          icon: "⚠️",
          damage: 10,
          manaCost: 20,
          cooldown: 10000,
          range: 150,
          areaOfEffect: 60,
          duration: 5000,
          description: "Place a trap that damages and immobilizes enemies",
        },
      ],
    },
  ]

  // Initialize game
  const initializeGame = () => {
    const heroes: Hero[] = []
    const { mapWidth, mapHeight, playerBaseX, playerBaseY, enemyBaseX, enemyBaseY } = gameStateRef.current

    // Create player heroes
    for (let i = 0; i < 3; i++) {
      const template = heroTemplates[i]
      heroes.push({
        id: gameStateRef.current.nextId++,
        name: template.name,
        x: playerBaseX + Math.cos(Math.PI * 2 * (i / 3)) * 80,
        y: playerBaseY + Math.sin(Math.PI * 2 * (i / 3)) * 80,
        size: template.size,
        speed: template.speed,
        health: template.health,
        maxHealth: template.health,
        mana: template.mana,
        maxMana: template.mana,
        damage: template.damage,
        defense: template.defense,
        attackRange: template.attackRange,
        attackSpeed: template.attackSpeed,
        lastAttack: 0,
        team: "player",
        color: template.color,
        abilities: template.abilities,
        cooldowns: {},
        target: null,
        state: "idle",
        path: [],
      })
    }

    // Create enemy heroes
    for (let i = 0; i < 3; i++) {
      const template = heroTemplates[i]
      heroes.push({
        id: gameStateRef.current.nextId++,
        name: template.name,
        x: enemyBaseX + Math.cos(Math.PI * 2 * (i / 3)) * 80,
        y: enemyBaseY + Math.sin(Math.PI * 2 * (i / 3)) * 80,
        size: template.size,
        speed: template.speed,
        health: template.health,
        maxHealth: template.health,
        mana: template.mana,
        maxMana: template.mana,
        damage: template.damage,
        defense: template.defense,
        attackRange: template.attackRange,
        attackSpeed: template.attackSpeed,
        lastAttack: 0,
        team: "enemy",
        color: template.color,
        abilities: template.abilities,
        cooldowns: {},
        target: null,
        state: "idle",
        path: [],
      })
    }

    gameStateRef.current.heroes = heroes
    gameStateRef.current.projectiles = []
    gameStateRef.current.effects = []
    gameStateRef.current.gameTime = 0
    gameStateRef.current.playerScore = 0
    gameStateRef.current.enemyScore = 0

    setScore(0)
    setSelectedHero(null)
    setSelectedAbility(null)
    setGameResult(null)
  }

  // Start game
  const startGame = () => {
    setGameStarted(true)
    setGameOver(false)
    initializeGame()
  }

  // Reset game
  const resetGame = () => {
    setGameStarted(false)
    setGameOver(false)
    setGamePaused(false)
  }

  // Toggle pause
  const togglePause = () => {
    setGamePaused(!gamePaused)
  }

  // Toggle mute
  const toggleMute = () => {
    setMuted(!muted)
  }

  // Initialize canvas and event listeners
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    // Set canvas dimensions
    canvas.width = gameStateRef.current.mapWidth
    canvas.height = gameStateRef.current.mapHeight

    // Event listeners
    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect()
      gameStateRef.current.mouse.x = e.clientX - rect.left
      gameStateRef.current.mouse.y = e.clientY - rect.top
    }

    const handleMouseDown = (e: MouseEvent) => {
      if (e.button === 0) {
        gameStateRef.current.mouse.clicked = true
        handleClick()
      } else if (e.button === 2) {
        gameStateRef.current.mouse.rightClicked = true
        handleRightClick()
      }
    }

    const handleMouseUp = (e: MouseEvent) => {
      if (e.button === 0) {
        gameStateRef.current.mouse.clicked = false
      } else if (e.button === 2) {
        gameStateRef.current.mouse.rightClicked = false
      }
    }

    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault()
    }

    canvas.addEventListener("mousemove", handleMouseMove)
    canvas.addEventListener("mousedown", handleMouseDown)
    canvas.addEventListener("mouseup", handleMouseUp)
    canvas.addEventListener("contextmenu", handleContextMenu)

    return () => {
      canvas.removeEventListener("mousemove", handleMouseMove)
      canvas.removeEventListener("mousedown", handleMouseDown)
      canvas.removeEventListener("mouseup", handleMouseUp)
      canvas.removeEventListener("contextmenu", handleContextMenu)
    }
  }, [selectedHero, selectedAbility])

  // Handle left click
  const handleClick = () => {
    if (gamePaused || gameOver) return

    const { heroes, mouse } = gameStateRef.current

    // Check if clicked on a hero
    let clickedOnHero = false
    for (const hero of heroes) {
      const dx = mouse.x - hero.x
      const dy = mouse.y - hero.y
      const distance = Math.sqrt(dx * dx + dy * dy)

      if (distance < hero.size) {
        if (hero.team === "player") {
          // Select player hero
          setSelectedHero(hero.id)
        } else if (selectedHero !== null && selectedAbility !== null) {
          // Cast ability on enemy hero
          castAbility(selectedHero, selectedAbility, hero.id)
          setSelectedAbility(null)
        } else if (selectedHero !== null) {
          // Attack enemy hero
          const playerHero = heroes.find((h) => h.id === selectedHero)
          if (playerHero) {
            playerHero.target = hero.id
            playerHero.state = "moving"

            // Calculate path to target
            const targetHero = heroes.find((h) => h.id === hero.id)
            if (targetHero) {
              playerHero.path = calculatePath(playerHero, targetHero.x, targetHero.y)
            }
          }
        }
        clickedOnHero = true
        break
      }
    }

    // If not clicked on a hero and a hero is selected, move to location
    if (!clickedOnHero && selectedHero !== null) {
      if (selectedAbility !== null) {
        // Cast ground-targeted ability
        castAbility(selectedHero, selectedAbility, null, mouse.x, mouse.y)
        setSelectedAbility(null)
      } else {
        // Move hero to location
        const hero = heroes.find((h) => h.id === selectedHero)
        if (hero) {
          hero.target = null
          hero.state = "moving"
          hero.path = calculatePath(hero, mouse.x, mouse.y)
        }
      }
    }
  }

  // Handle right click
  const handleRightClick = () => {
    if (gamePaused || gameOver) return

    // Cancel ability selection
    setSelectedAbility(null)

    // If a hero is selected, stop movement
    if (selectedHero !== null) {
      const hero = gameStateRef.current.heroes.find((h) => h.id === selectedHero)
      if (hero) {
        hero.target = null
        hero.state = "idle"
        hero.path = []
      }
    }
  }

  // Calculate path to target
  const calculatePath = (hero: Hero, targetX: number, targetY: number): { x: number; y: number }[] => {
    // Simple direct path for now
    return [{ x: targetX, y: targetY }]
  }

  // Cast ability
  const castAbility = (
    heroId: number,
    abilityId: string,
    targetId: number | null,
    targetX?: number,
    targetY?: number,
  ) => {
    const { heroes } = gameStateRef.current
    const hero = heroes.find((h) => h.id === heroId)

    if (!hero) return

    const ability = hero.abilities.find((a) => a.id === abilityId)
    if (!ability) return

    // Check cooldown
    if (hero.cooldowns[abilityId] && hero.cooldowns[abilityId] > gameStateRef.current.gameTime) {
      return
    }

    // Check mana
    if (hero.mana < ability.manaCost) {
      return
    }

    // Consume mana
    hero.mana -= ability.manaCost

    // Set cooldown
    hero.cooldowns[abilityId] = gameStateRef.current.gameTime + ability.cooldown

    // Cast ability based on type
    switch (ability.id) {
      case "whirlwind":
        // Area damage around hero
        hero.state = "casting"
        createEffect(hero.x, hero.y, ability.areaOfEffect, "#FF2D95", ability.duration, "explosion")

        // Damage nearby enemies
        heroes.forEach((enemy) => {
          if (enemy.team !== hero.team) {
            const dx = enemy.x - hero.x
            const dy = enemy.y - hero.y
            const distance = Math.sqrt(dx * dx + dy * dy)

            if (distance < ability.areaOfEffect) {
              dealDamage(hero, enemy, ability.damage)
            }
          }
        })

        playSound("ability")
        break

      case "charge":
        // Charge toward target
        if (targetId) {
          const target = heroes.find((h) => h.id === targetId)
          if (target) {
            hero.state = "casting"

            // Create projectile for visual effect
            createProjectile(
              hero.x,
              hero.y,
              target.x,
              target.y,
              10,
              ability.damage,
              10,
              "#FF2D95",
              hero.id,
              targetId,
              ability.id,
            )

            // Teleport hero toward target
            const dx = target.x - hero.x
            const dy = target.y - hero.y
            const distance = Math.sqrt(dx * dx + dy * dy)
            const ratio = Math.min(distance, ability.range) / distance

            hero.x += dx * ratio
            hero.y += dy * ratio

            // Damage target if close enough
            if (distance < hero.size + target.size + 20) {
              dealDamage(hero, target, ability.damage)
            }

            playSound("ability")
          }
        }
        break

      case "fireball":
        // Launch fireball projectile
        if (targetId) {
          const target = heroes.find((h) => h.id === targetId)
          if (target) {
            hero.state = "casting"
            createProjectile(
              hero.x,
              hero.y,
              target.x,
              target.y,
              5,
              ability.damage,
              15,
              "#FF5722",
              hero.id,
              targetId,
              ability.id,
            )
            playSound("ability")
          }
        } else if (targetX !== undefined && targetY !== undefined) {
          hero.state = "casting"
          createProjectile(
            hero.x,
            hero.y,
            targetX,
            targetY,
            5,
            ability.damage,
            15,
            "#FF5722",
            hero.id,
            null,
            ability.id,
          )
          playSound("ability")
        }
        break

      case "frostNova":
        // Area frost effect
        hero.state = "casting"
        createEffect(hero.x, hero.y, ability.areaOfEffect, "#00FFFF", ability.duration, "debuff")

        // Damage and slow nearby enemies
        heroes.forEach((enemy) => {
          if (enemy.team !== hero.team) {
            const dx = enemy.x - hero.x
            const dy = enemy.y - hero.y
            const distance = Math.sqrt(dx * dx + dy * dy)

            if (distance < ability.areaOfEffect) {
              dealDamage(hero, enemy, ability.damage)
              // Slow effect (temporary speed reduction)
              enemy.speed *= 0.5
              setTimeout(() => {
                if (enemy && gameStateRef.current.heroes.includes(enemy)) {
                  enemy.speed *= 2 // Restore speed
                }
              }, ability.duration)
            }
          }
        })

        playSound("ability")
        break

      case "volley":
        // Multiple arrow projectiles
        hero.state = "casting"

        if (targetX !== undefined && targetY !== undefined) {
          // Fire 5 arrows in a spread pattern
          for (let i = 0; i < 5; i++) {
            const angle = Math.atan2(targetY - hero.y, targetX - hero.x)
            const spreadAngle = angle + (i - 2) * 0.2 // -0.4, -0.2, 0, 0.2, 0.4 radians spread

            const arrowTargetX = hero.x + Math.cos(spreadAngle) * ability.range
            const arrowTargetY = hero.y + Math.sin(spreadAngle) * ability.range

            createProjectile(
              hero.x,
              hero.y,
              arrowTargetX,
              arrowTargetY,
              7,
              ability.damage / 5,
              8,
              "#FFFF00",
              hero.id,
              null,
              ability.id,
            )
          }

          playSound("ability")
        }
        break

      case "trap":
        // Place trap at location
        if (targetX !== undefined && targetY !== undefined) {
          hero.state = "casting"
          createEffect(targetX, targetY, ability.areaOfEffect, "#FFFF00", ability.duration, "debuff")

          // Check for enemies in trap area every 500ms
          const trapInterval = setInterval(() => {
            const { heroes, effects } = gameStateRef.current
            const trapExists = effects.some((e) => e.type === "debuff" && e.x === targetX && e.y === targetY)

            if (!trapExists) {
              clearInterval(trapInterval)
              return
            }

            heroes.forEach((enemy) => {
              if (enemy.team !== hero.team) {
                const dx = enemy.x - targetX
                const dy = enemy.y - targetY
                const distance = Math.sqrt(dx * dx + dy * dy)

                if (distance < ability.areaOfEffect) {
                  dealDamage(hero, enemy, ability.damage / 10) // Damage over time
                  enemy.speed = 0 // Root effect

                  // Restore speed after a short duration
                  setTimeout(() => {
                    if (enemy && gameStateRef.current.heroes.includes(enemy)) {
                      enemy.speed = heroTemplates.find((t) => t.name === enemy.name)?.speed || 3
                    }
                  }, 1000)
                }
              }
            })
          }, 500)

          playSound("ability")
        }
        break
    }
  }

  // Create projectile
  const createProjectile = (
    x: number,
    y: number,
    targetX: number,
    targetY: number,
    speed: number,
    damage: number,
    size: number,
    color: string,
    sourceId: number,
    targetId: number | null,
    ability: string | null,
  ) => {
    gameStateRef.current.projectiles.push({
      id: gameStateRef.current.nextProjectileId++,
      x,
      y,
      targetX,
      targetY,
      speed,
      damage,
      size,
      color,
      sourceId,
      targetId,
      ability,
    })
  }

  // Create effect
  const createEffect = (
    x: number,
    y: number,
    size: number,
    color: string,
    duration: number,
    type: "explosion" | "heal" | "buff" | "debuff",
  ) => {
    gameStateRef.current.effects.push({
      id: gameStateRef.current.nextEffectId++,
      x,
      y,
      size,
      color,
      duration,
      startTime: gameStateRef.current.gameTime,
      type,
    })
  }

  // Deal damage
  const dealDamage = (source: Hero, target: Hero, damage: number) => {
    // Calculate actual damage based on defense
    const actualDamage = Math.max(1, damage - target.defense / 2)

    // Apply damage
    target.health -= actualDamage

    // Check if target is dead
    if (target.health <= 0) {
      // Award score
      if (target.team === "enemy") {
        gameStateRef.current.playerScore += 100
        setScore(gameStateRef.current.playerScore)
      } else {
        gameStateRef.current.enemyScore += 100
      }

      // Remove target from game
      gameStateRef.current.heroes = gameStateRef.current.heroes.filter((h) => h.id !== target.id)

      // Create death effect
      createEffect(target.x, target.y, target.size * 2, target.color, 1000, "explosion")

      // Play sound
      playSound("death")

      // Check for game over
      checkGameOver()

      // Respawn hero after delay
      setTimeout(() => {
        if (gameOver) return

        const template = heroTemplates.find((t) => t.name === target.name)
        if (!template) return

        const { playerBaseX, playerBaseY, enemyBaseX, enemyBaseY } = gameStateRef.current
        const baseX = target.team === "player" ? playerBaseX : enemyBaseX
        const baseY = target.team === "player" ? playerBaseY : enemyBaseY

        const newHeroData: Hero = {
          id: gameStateRef.current.nextId++,
          name: target.name,
          x: baseX + (Math.random() - 0.5) * 50,
          y: baseY + (Math.random() - 0.5) * 50,
          size: template.size,
          speed: template.speed,
          health: template.health,
          maxHealth: template.health,
          mana: template.mana,
          maxMana: template.mana,
          damage: template.damage,
          defense: template.defense,
          attackRange: template.attackRange,
          attackSpeed: template.attackSpeed,
          lastAttack: 0,
          team: target.team,
          color: template.color,
          abilities: template.abilities,
          cooldowns: {},
          target: null,
          state: "idle",
          path: [],
        }

        gameStateRef.current.heroes.push(newHeroData)
      }, 5000)
    } else {
      // Create hit effect
      createEffect(target.x, target.y, 20, "#FFFFFF", 300, "explosion")

      // Play sound
      playSound("hit")
    }
  }

  // Check for game over
  const checkGameOver = () => {
    const { heroes, playerBaseX, playerBaseY, enemyBaseX, enemyBaseY, baseRadius } = gameStateRef.current

    // Check if all heroes of a team are dead
    const playerHeroes = heroes.filter((h) => h.team === "player")
    const enemyHeroes = heroes.filter((h) => h.team === "enemy")

    if (playerHeroes.length === 0) {
      setGameOver(true)
      setGameResult("defeat")
      return
    }

    if (enemyHeroes.length === 0) {
      setGameOver(true)
      setGameResult("victory")
      return
    }

    // Check if enemy hero is at player base
    for (const hero of enemyHeroes) {
      const dx = hero.x - playerBaseX
      const dy = hero.y - playerBaseY
      const distance = Math.sqrt(dx * dx + dy * dy)

      if (distance < baseRadius) {
        setGameOver(true)
        setGameResult("defeat")
        return
      }
    }

    // Check if player hero is at enemy base
    for (const hero of playerHeroes) {
      const dx = hero.x - enemyBaseX
      const dy = hero.y - enemyBaseY
      const distance = Math.sqrt(dx * dx + dy * dy)

      if (distance < baseRadius) {
        setGameOver(true)
        setGameResult("victory")
        return
      }
    }
  }

  // Play sound
  const playSound = (type: "hit" | "death" | "ability" | "victory" | "defeat") => {
    if (muted) return

    const sound = new Audio()
    sound.volume = 0.3

    // Simple audio data
    sound.src = "data:audio/wav;base64,UklGRigAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAAABMYXZmNTguMTMuMTAw"
    sound.play()
  }

  // Game loop
  useEffect(() => {
    if (!gameStarted || gamePaused || gameOver) return

    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    let animationFrameId: number
    let lastTime = 0

    const gameLoop = (timestamp: number) => {
      if (!gameStarted || gamePaused || gameOver) return

      const deltaTime = timestamp - lastTime
      lastTime = timestamp

      gameStateRef.current.gameTime += deltaTime

      // Clear canvas
      ctx.fillStyle = "#0F0B2A"
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      // Draw map
      drawMap(ctx)

      // Update heroes
      updateHeroes(deltaTime)

      // Update projectiles
      updateProjectiles(deltaTime)

      // Update effects
      updateEffects(deltaTime)

      // Draw heroes
      drawHeroes(ctx)

      // Draw projectiles
      drawProjectiles(ctx)

      // Draw effects
      drawEffects(ctx)

      // Draw UI
      drawUI(ctx)

      // AI decision making
      if (gameStateRef.current.gameTime % 1000 < 20) {
        updateAI()
      }

      animationFrameId = requestAnimationFrame(gameLoop)
    }

    animationFrameId = requestAnimationFrame(gameLoop)

    return () => {
      cancelAnimationFrame(animationFrameId)
    }
  }, [gameStarted, gamePaused, gameOver, selectedHero, selectedAbility])

  // Update heroes
  const updateHeroes = (deltaTime: number) => {
    const { heroes } = gameStateRef.current

    heroes.forEach((hero) => {
      // Regenerate mana
      hero.mana = Math.min(hero.maxMana, hero.mana + 0.05)

      // Update hero state
      switch (hero.state) {
        case "idle":
          // Do nothing
          break

        case "moving":
          // Move along path
          if (hero.path.length > 0) {
            const target = hero.path[0]
            const dx = target.x - hero.x
            const dy = target.y - hero.y
            const distance = Math.sqrt(dx * dx + dy * dy)

            if (distance < 5) {
              // Reached waypoint
              hero.path.shift()

              if (hero.path.length === 0) {
                hero.state = "idle"
              }
            } else {
              // Move toward waypoint
              const moveDistance = Math.min(distance, hero.speed)
              const ratio = moveDistance / distance

              hero.x += dx * ratio
              hero.y += dy * ratio
            }
          }

          // Check if target is in range
          if (hero.target !== null) {
            const target = heroes.find((h) => h.id === hero.target)
            if (target) {
              const dx = target.x - hero.x
              const dy = target.y - hero.y
              const distance = Math.sqrt(dx * dx + dy * dy)

              if (distance <= hero.attackRange) {
                // In range, attack
                hero.state = "attacking"
              }
            } else {
              // Target no longer exists
              hero.target = null
              hero.state = "idle"
            }
          }
          break

        case "attacking":
          // Check if target still exists and is in range
          if (hero.target !== null) {
            const target = heroes.find((h) => h.id === hero.target)
            if (target) {
              const dx = target.x - hero.x
              const dy = target.y - hero.y
              const distance = Math.sqrt(dx * dx + dy * dy)

              if (distance <= hero.attackRange) {
                // In range, attack if cooldown is ready
                const now = gameStateRef.current.gameTime
                if (now - hero.lastAttack >= hero.attackSpeed) {
                  // Attack
                  hero.lastAttack = now

                  // Create projectile
                  createProjectile(
                    hero.x,
                    hero.y,
                    target.x,
                    target.y,
                    10,
                    hero.damage,
                    5,
                    hero.color,
                    hero.id,
                    target.id,
                    null,
                  )
                }
              } else {
                // Target moved out of range, follow
                hero.state = "moving"
                hero.path = calculatePath(hero, target.x, target.y)
              }
            } else {
              // Target no longer exists
              hero.target = null
              hero.state = "idle"
            }
          } else {
            // No target
            hero.state = "idle"
          }
          break

        case "casting":
          // Return to previous state after a short delay
          setTimeout(() => {
            if (hero && gameStateRef.current.heroes.includes(hero)) {
              hero.state = hero.target ? "attacking" : "idle"
            }
          }, 500)
          break
      }
    })
  }

  // Update projectiles
  const updateProjectiles = (deltaTime: number) => {
    const { projectiles, heroes } = gameStateRef.current

    for (let i = projectiles.length - 1; i >= 0; i--) {
      const projectile = projectiles[i]

      // Update target position if targeting a hero
      if (projectile.targetId !== null) {
        const target = heroes.find((h) => h.id === projectile.targetId)
        if (target) {
          projectile.targetX = target.x
          projectile.targetY = target.y
        }
      }

      // Move projectile
      const dx = projectile.targetX - projectile.x
      const dy = projectile.targetY - projectile.y
      const distance = Math.sqrt(dx * dx + dy * dy)

      if (distance < projectile.speed) {
        // Reached target

        // Check for collision with heroes
        heroes.forEach((hero) => {
          const source = heroes.find((h) => h.id === projectile.sourceId)
          if (source && hero.team !== source.team) {
            const heroDistance = Math.sqrt(
              Math.pow(hero.x - projectile.targetX, 2) + Math.pow(hero.y - projectile.targetY, 2),
            )

            // Area effect for abilities
            const areaOfEffect = projectile.ability === "fireball" ? 80 : projectile.ability === "volley" ? 30 : 0

            if (heroDistance < hero.size + areaOfEffect) {
              dealDamage(source, hero, projectile.damage)
            }
          }
        })

        // Create impact effect
        if (projectile.ability === "fireball") {
          createEffect(projectile.targetX, projectile.targetY, 80, "#FF5722", 500, "explosion")
        } else {
          createEffect(projectile.targetX, projectile.targetY, 20, projectile.color, 300, "explosion")
        }

        // Remove projectile
        projectiles.splice(i, 1)
      } else {
        // Move toward target
        const ratio = projectile.speed / distance
        projectile.x += dx * ratio
        projectile.y += dy * ratio
      }
    }
  }

  // Update effects
  const updateEffects = (deltaTime: number) => {
    const { effects, gameTime } = gameStateRef.current

    for (let i = effects.length - 1; i >= 0; i--) {
      const effect = effects[i]

      // Check if effect has expired
      if (gameTime - effect.startTime >= effect.duration) {
        effects.splice(i, 1)
      }
    }
  }

  // Update AI
  const updateAI = () => {
    const { heroes, playerBaseX, playerBaseY, enemyBaseX, enemyBaseY } = gameStateRef.current

    // AI for enemy heroes
    const enemyHeroes = heroes.filter((h) => h.team === "enemy")
    const playerHeroes = heroes.filter((h) => h.team === "player")

    enemyHeroes.forEach((hero) => {
      // Simple AI: attack nearest player hero or move toward player base
      if (hero.state === "idle" || Math.random() < 0.1) {
        // Find nearest player hero
        let nearestHero = null
        let nearestDistance = Number.POSITIVE_INFINITY

        playerHeroes.forEach((playerHero) => {
          const dx = playerHero.x - hero.x
          const dy = playerHero.y - hero.y
          const distance = Math.sqrt(dx * dx + dy * dy)

          if (distance < nearestDistance) {
            nearestHero = playerHero
            nearestDistance = distance
          }
        })

        if (nearestHero && nearestDistance < 300) {
          // Attack nearest hero
          hero.target = nearestHero.id
          hero.state = "moving"
          hero.path = calculatePath(hero, nearestHero.x, nearestHero.y)
        } else {
          // Move toward player base
          hero.target = null
          hero.state = "moving"
          hero.path = calculatePath(hero, playerBaseX, playerBaseY)
        }

        // Use abilities if available
        if (nearestHero && Math.random() < 0.2) {
          const availableAbilities = hero.abilities.filter(
            (ability) => !hero.cooldowns[ability.id] || hero.cooldowns[ability.id] <= gameStateRef.current.gameTime,
          )

          if (availableAbilities.length > 0 && hero.mana > 20) {
            const ability = availableAbilities[Math.floor(Math.random() * availableAbilities.length)]
            castAbility(hero.id, ability.id, nearestHero.id)
          }
        }
      }
    })
  }

  // Draw map
  const drawMap = (ctx: CanvasRenderingContext2D) => {
    const { mapWidth, mapHeight, playerBaseX, playerBaseY, enemyBaseX, enemyBaseY, baseRadius } = gameStateRef.current

    // Draw background
    const gradient = ctx.createLinearGradient(0, 0, mapWidth, mapHeight)
    gradient.addColorStop(0, "#0F0B2A")
    gradient.addColorStop(1, "#1A1145")
    ctx.fillStyle = gradient
    ctx.fillRect(0, 0, mapWidth, mapHeight)

    // Draw grid lines
    ctx.strokeStyle = "rgba(102, 51, 153, 0.1)"
    ctx.lineWidth = 1

    // Horizontal lines
    for (let y = 0; y < mapHeight; y += 40) {
      ctx.beginPath()
      ctx.moveTo(0, y)
      ctx.lineTo(mapWidth, y)
      ctx.stroke()
    }

    // Vertical lines
    for (let x = 0; x < mapWidth; x += 40) {
      ctx.beginPath()
      ctx.moveTo(x, 0)
      ctx.lineTo(x, mapHeight)
      ctx.stroke()
    }

    // Draw player base
    ctx.beginPath()
    ctx.arc(playerBaseX, playerBaseY, baseRadius, 0, Math.PI * 2)
    ctx.fillStyle = "rgba(0, 255, 255, 0.3)"
    ctx.fill()
    ctx.strokeStyle = "#00FFFF"
    ctx.lineWidth = 3
    ctx.stroke()

    // Draw enemy base
    ctx.beginPath()
    ctx.arc(enemyBaseX, enemyBaseY, baseRadius, 0, Math.PI * 2)
    ctx.fillStyle = "rgba(255, 45, 149, 0.3)"
    ctx.fill()
    ctx.strokeStyle = "#FF2D95"
    ctx.lineWidth = 3
    ctx.stroke()
  }

  // Draw heroes
  const drawHeroes = (ctx: CanvasRenderingContext2D) => {
    const { heroes } = gameStateRef.current

    heroes.forEach((hero) => {
      // Draw hero
      ctx.beginPath()
      ctx.arc(hero.x, hero.y, hero.size, 0, Math.PI * 2)
      ctx.fillStyle = hero.team === "player" ? "#00FFFF" : "#FF2D95"
      ctx.fill()

      // Draw hero border
      ctx.strokeStyle = hero.color
      ctx.lineWidth = 2
      ctx.stroke()

      // Draw selection indicator
      if (selectedHero === hero.id) {
        ctx.beginPath()
        ctx.arc(hero.x, hero.y, hero.size + 5, 0, Math.PI * 2)
        ctx.strokeStyle = "#FFFFFF"
        ctx.lineWidth = 2
        ctx.stroke()
      }

      // Draw health bar
      const healthBarWidth = hero.size * 2
      const healthBarHeight = 5
      const healthPercent = hero.health / hero.maxHealth

      ctx.fillStyle = "#333333"
      ctx.fillRect(hero.x - healthBarWidth / 2, hero.y - hero.size - 10, healthBarWidth, healthBarHeight)

      ctx.fillStyle = hero.team === "player" ? "#00FF00" : "#FF0000"
      ctx.fillRect(
        hero.x - healthBarWidth / 2,
        hero.y - hero.size - 10,
        healthBarWidth * healthPercent,
        healthBarHeight,
      )

      // Draw mana bar
      const manaBarWidth = hero.size * 2
      const manaBarHeight = 3
      const manaPercent = hero.mana / hero.maxMana

      ctx.fillStyle = "#333333"
      ctx.fillRect(hero.x - manaBarWidth / 2, hero.y - hero.size - 5, manaBarWidth, manaBarHeight)

      ctx.fillStyle = "#0088FF"
      ctx.fillRect(hero.x - manaBarWidth / 2, hero.y - hero.size - 5, manaBarWidth * manaPercent, manaBarHeight)

      // Draw hero name
      ctx.fillStyle = "#FFFFFF"
      ctx.font = "12px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "bottom"
      ctx.fillText(hero.name, hero.x, hero.y - hero.size - 15)
    })
  }

  // Draw projectiles
  const drawProjectiles = (ctx: CanvasRenderingContext2D) => {
    const { projectiles } = gameStateRef.current

    projectiles.forEach((projectile) => {
      // Draw projectile
      ctx.beginPath()
      ctx.arc(projectile.x, projectile.y, projectile.size, 0, Math.PI * 2)
      ctx.fillStyle = projectile.color
      ctx.fill()

      // Draw glow effect
      ctx.shadowBlur = 10
      ctx.shadowColor = projectile.color
      ctx.fill()
      ctx.shadowBlur = 0

      // Draw trail
      const dx = projectile.targetX - projectile.x
      const dy = projectile.targetY - projectile.y
      const angle = Math.atan2(dy, dx)

      ctx.beginPath()
      ctx.moveTo(projectile.x, projectile.y)
      ctx.lineTo(
        projectile.x - Math.cos(angle) * projectile.size * 3,
        projectile.y - Math.sin(angle) * projectile.size * 3,
      )
      ctx.strokeStyle = projectile.color
      ctx.lineWidth = projectile.size
      ctx.globalAlpha = 0.5
      ctx.stroke()
      ctx.globalAlpha = 1
    })
  }

  // Draw effects
  const drawEffects = (ctx: CanvasRenderingContext2D) => {
    const { effects, gameTime } = gameStateRef.current

    effects.forEach((effect) => {
      // Calculate effect progress
      const progress = (gameTime - effect.startTime) / effect.duration

      // Draw effect based on type
      switch (effect.type) {
        case "explosion":
          // Expanding circle that fades out
          ctx.beginPath()
          ctx.arc(effect.x, effect.y, effect.size * progress, 0, Math.PI * 2)
          ctx.fillStyle = effect.color
          ctx.globalAlpha = 1 - progress
          ctx.fill()
          ctx.globalAlpha = 1
          break

        case "heal":
          // Rising particles
          for (let i = 0; i < 5; i++) {
            const angle = Math.PI * 2 * (i / 5)
            const distance = effect.size * progress

            ctx.beginPath()
            ctx.arc(
              effect.x + Math.cos(angle) * distance,
              effect.y + Math.sin(angle) * distance - effect.size * progress,
              5,
              0,
              Math.PI * 2,
            )
            ctx.fillStyle = "#00FF00"
            ctx.globalAlpha = 1 - progress
            ctx.fill()
            ctx.globalAlpha = 1
          }
          break

        case "buff":
          // Rotating stars
          for (let i = 0; i < 5; i++) {
            const angle = Math.PI * 2 * (i / 5) + progress * Math.PI * 2
            const distance = effect.size * 0.7

            ctx.beginPath()
            ctx.moveTo(effect.x + Math.cos(angle) * distance, effect.y + Math.sin(angle) * distance)

            for (let j = 0; j < 5; j++) {
              const starAngle = angle + Math.PI * 2 * (j / 5)
              const starDistance = j % 2 === 0 ? distance * 0.5 : distance

              ctx.lineTo(effect.x + Math.cos(starAngle) * starDistance, effect.y + Math.sin(starAngle) * starDistance)
            }

            ctx.fillStyle = "#FFFF00"
            ctx.globalAlpha = 1 - progress
            ctx.fill()
            ctx.globalAlpha = 1
          }
          break

        case "debuff":
          // Pulsating circle
          const pulseSize = effect.size * (0.8 + Math.sin(progress * Math.PI * 10) * 0.2)

          ctx.beginPath()
          ctx.arc(effect.x, effect.y, pulseSize, 0, Math.PI * 2)
          ctx.strokeStyle = effect.color
          ctx.lineWidth = 3
          ctx.globalAlpha = 1 - progress
          ctx.stroke()
          ctx.globalAlpha = 1
          break
      }
    })
  }

  // Draw UI
  const drawUI = (ctx: CanvasRenderingContext2D) => {
    const { playerScore, enemyScore } = gameStateRef.current

    // Draw scores
    ctx.fillStyle = "#FFFFFF"
    ctx.font = "20px Arial"
    ctx.textAlign = "left"
    ctx.fillText(`Score: ${playerScore}`, 20, 30)

    // Draw selected hero abilities
    if (selectedHero !== null) {
      const hero = gameStateRef.current.heroes.find((h) => h.id === selectedHero)
      if (hero) {
        // Draw ability icons
        const abilitySize = 40
        const abilityPadding = 10
        const startX = 20
        const startY = gameStateRef.current.mapHeight - abilitySize - 20

        hero.abilities.forEach((ability, index) => {
          const x = startX + (abilitySize + abilityPadding) * index
          const y = startY

          // Draw ability background
          ctx.fillStyle = selectedAbility === ability.id ? "#FFFFFF" : "#333333"
          ctx.fillRect(x, y, abilitySize, abilitySize)

          // Draw ability icon
          ctx.fillStyle = "#000000"
          ctx.font = "20px Arial"
          ctx.textAlign = "center"
          ctx.textBaseline = "middle"
          ctx.fillText(ability.icon, x + abilitySize / 2, y + abilitySize / 2)

          // Draw cooldown overlay
          const cooldown = hero.cooldowns[ability.id] || 0
          if (cooldown > gameStateRef.current.gameTime) {
            const remainingCooldown = (cooldown - gameStateRef.current.gameTime) / 1000

            // Gray overlay
            ctx.fillStyle = "rgba(0, 0, 0, 0.7)"
            ctx.fillRect(x, y, abilitySize, abilitySize)

            // Cooldown text
            ctx.fillStyle = "#FFFFFF"
            ctx.font = "16px Arial"
            ctx.textAlign = "center"
            ctx.textBaseline = "middle"
            ctx.fillText(remainingCooldown.toFixed(1), x + abilitySize / 2, y + abilitySize / 2)
          }

          // Draw mana cost indicator
          if (hero.mana < ability.manaCost) {
            // Blue overlay
            ctx.fillStyle = "rgba(0, 0, 255, 0.3)"
            ctx.fillRect(x, y, abilitySize, abilitySize)
          }

          // Draw ability hotkey
          ctx.fillStyle = "#FFFFFF"
          ctx.font = "12px Arial"
          ctx.textAlign = "left"
          ctx.textBaseline = "top"
          ctx.fillText(`${index + 1}`, x + 2, y + 2)
        })
      }
    }
  }

  return (
    <div className="relative">
      {/* Game canvas */}
      <canvas ref={canvasRef} className="bg-[#0F0B2A] rounded-lg shadow-lg" />

      {/* Game UI overlay */}
      <div className="absolute top-4 left-4 flex items-center space-x-4">
        <Badge className="bg-[#00FFFF] text-black px-3 py-1">Score: {score}</Badge>
      </div>

      {/* Game controls */}
      <div className="absolute top-4 right-4 flex items-center space-x-2">
        <Button
          size="icon"
          variant="outline"
          className="bg-[#1A1145]/50 border-[#3A2A65] text-white hover:bg-[#3A2A65]/50"
          onClick={toggleMute}
        >
          {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
        </Button>

        <Button
          size="icon"
          variant="outline"
          className="bg-[#1A1145]/50 border-[#3A2A65] text-white hover:bg-[#3A2A65]/50"
          onClick={togglePause}
        >
          {gamePaused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
        </Button>

        <Button
          size="icon"
          variant="outline"
          className="bg-[#1A1145]/50 border-[#3A2A65] text-white hover:bg-[#3A2A65]/50"
          onClick={resetGame}
        >
          <RotateCcw className="h-4 w-4" />
        </Button>
      </div>

      {/* Ability buttons (for mobile) */}
      {selectedHero !== null && (
        <div className="absolute bottom-4 left-4 flex space-x-2">
          {gameStateRef.current.heroes
            .find((h) => h.id === selectedHero)
            ?.abilities.map((ability, index) => (
              <Button
                key={ability.id}
                size="sm"
                variant={selectedAbility === ability.id ? "default" : "outline"}
                className={`${selectedAbility === ability.id ? "bg-[#FFFFFF] text-black" : "bg-[#1A1145]/50 border-[#3A2A65] text-white"}`}
                onClick={() => setSelectedAbility(ability.id)}
                disabled={((hero) => {
                  const cooldown = hero?.cooldowns[ability.id] || 0
                  return cooldown > gameStateRef.current.gameTime || (hero?.mana || 0) < ability.manaCost
                })(gameStateRef.current.heroes.find((h) => h.id === selectedHero))}
              >
                <span className="mr-1">{ability.icon}</span>
                {ability.name}
              </Button>
            ))}
        </div>
      )}

      {/* Hero selection buttons (for mobile) */}
      <div className="absolute bottom-4 right-4 flex space-x-2">
        {gameStateRef.current.heroes
          .filter((h) => h.team === "player")
          .map((hero) => (
            <Button
              key={hero.id}
              size="sm"
              variant={selectedHero === hero.id ? "default" : "outline"}
              className={`${selectedHero === hero.id ? "bg-[#00FFFF]" : "bg-[#1A1145]/50 border-[#3A2A65]"} text-white`}
              onClick={() => setSelectedHero(hero.id)}
            >
              {hero.name}
            </Button>
          ))}
      </div>

      {/* Game start overlay */}
      {!gameStarted && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#0F0B2A]/80 rounded-lg">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4 text-[#9D00FF]">Legends Arena</h2>
            <p className="text-[#E0E0FF] mb-6 max-w-md">
              Command your team of heroes in this competitive battle arena. Click to select heroes, right-click to move,
              and use abilities to defeat the enemy team. Destroy the enemy base to win!
            </p>
            <Button
              onClick={startGame}
              className="bg-gradient-to-r from-[#9D00FF] to-[#FF2D95] text-white font-bold hover:from-[#B347FF] hover:to-[#FF5CAD]"
            >
              Start Game
            </Button>
          </div>
        </div>
      )}

      {/* Game over overlay */}
      {gameOver && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#0F0B2A]/80 rounded-lg">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4 text-[#9D00FF]">Game Over</h2>
            <p className="text-2xl text-[#E0E0FF] mb-2">{gameResult === "victory" ? "Victory!" : "Defeat!"}</p>
            <p className="text-[#E0E0FF] mb-6">Final Score: {score}</p>
            <Button
              onClick={resetGame}
              className="bg-gradient-to-r from-[#9D00FF] to-[#FF2D95] text-white font-bold hover:from-[#B347FF] hover:to-[#FF5CAD]"
            >
              Play Again
            </Button>
          </div>
        </div>
      )}

      {/* Pause overlay */}
      {gameStarted && gamePaused && !gameOver && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#0F0B2A]/80 rounded-lg">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4 text-[#9D00FF]">Game Paused</h2>
            <Button
              onClick={togglePause}
              className="bg-gradient-to-r from-[#9D00FF] to-[#FF2D95] text-white font-bold hover:from-[#B347FF] hover:to-[#FF5CAD]"
            >
              Resume
            </Button>
          </div>
        </div>
      )}

      {/* Controls help */}
      <div className="absolute top-16 left-4 bg-[#1A1145]/70 p-2 rounded-lg text-[#E0E0FF] text-xs">
        <p>Left-click: Select hero or target</p>
        <p>Right-click: Move or cancel</p>
        <p>1-2: Use abilities</p>
      </div>
    </div>
  )
}
