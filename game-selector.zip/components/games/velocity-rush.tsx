"\"use client"

import { useEffect, useRef, useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Play, Pause, RotateCcw, Volume2, VolumeX } from "lucide-react"

interface TrackSegment {
  x: number
  y: number
  width: number
  height: number
  color: string
}

interface Vehicle {
  x: number
  y: number
  angle: number
  speed: number
  width: number
  height: number
  color: string
  boosting: boolean
  drifting: boolean
}

export default function VelocityRushGame() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [gameStarted, setGameStarted] = useState(false)
  const [gamePaused, setGamePaused] = useState(false)
  const [gameOver, setGameOver] = useState(false)
  const [score, setScore] = useState(0)
  const [level, setLevel] = useState(1)
  const [muted, setMuted] = useState(false)

  // Game state
  const gameStateRef = useRef({
    track: [] as TrackSegment[],
    vehicle: null as Vehicle | null,
    keys: {
      w: false,
      a: false,
      s: false,
      d: false,
      shift: false,
      space: false,
    },
    gameTime: 0,
    score: 0,
    lapTime: 0,
    bestLapTime: Number.POSITIVE_INFINITY,
    lapsCompleted: 0,
  })

  // Initialize game
  const initializeGame = () => {
    if (!canvasRef.current) return

    const canvas = canvasRef.current
    const width = canvas.width
    const height = canvas.height

    // Create track
    const track: TrackSegment[] = []
    const segmentWidth = 100
    const segmentHeight = 20
    const trackLength = 20

    let currentX = width / 2 - segmentWidth / 2
    let currentY = height / 2 - segmentHeight / 2

    for (let i = 0; i < trackLength; i++) {
      track.push({
        x: currentX,
        y: currentY,
        width: segmentWidth,
        height: segmentHeight,
        color: i % 2 === 0 ? "#00FFFF" : "#FF2D95",
      })

      // Simple track generation (can be improved)
      currentX += (Math.random() - 0.5) * 50
      currentY += (Math.random() - 0.5) * 30

      // Keep track within bounds
      currentX = Math.max(segmentWidth / 2, Math.min(width - segmentWidth / 2, currentX))
      currentY = Math.max(segmentHeight / 2, Math.min(height - segmentHeight / 2, currentY))
    }

    // Create vehicle
    const vehicle: Vehicle = {
      x: width / 2,
      y: height / 2,
      angle: 0,
      speed: 0,
      width: 20,
      height: 10,
      color: "#FFFF00",
      boosting: false,
      drifting: false,
    }

    gameStateRef.current.track = track
    gameStateRef.current.vehicle = vehicle
    gameStateRef.current.score = 0
    gameStateRef.current.lapTime = 0
    gameStateRef.current.bestLapTime = Number.POSITIVE_INFINITY
    gameStateRef.current.lapsCompleted = 0
  }

  // Start game
  const startGame = () => {
    setGameStarted(true)
    setGameOver(false)
    setLevel(1)
    initializeGame()
  }

  // Reset game
  const resetGame = () => {
    setGameStarted(false)
    setGameOver(false)
    setGamePaused(false)
  }

  // Toggle pause
  const togglePause = () => {
    setGamePaused(!gamePaused)
  }

  // Toggle mute
  const toggleMute = () => {
    setMuted(!muted)
  }

  // Initialize canvas and event listeners
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    // Set canvas dimensions
    canvas.width = 800
    canvas.height = 600

    // Event listeners
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "w" || e.key === "ArrowUp") gameStateRef.current.keys.w = true
      if (e.key === "a" || e.key === "ArrowLeft") gameStateRef.current.keys.a = true
      if (e.key === "s" || e.key === "ArrowDown") gameStateRef.current.keys.s = true
      if (e.key === "d" || e.key === "ArrowRight") gameStateRef.current.keys.d = true
      if (e.key === "Shift") gameStateRef.current.keys.shift = true
      if (e.key === " ") gameStateRef.current.keys.space = true
    }

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key === "w" || e.key === "ArrowUp") gameStateRef.current.keys.w = false
      if (e.key === "a" || e.key === "ArrowLeft") gameStateRef.current.keys.a = false
      if (e.key === "s" || e.key === "ArrowDown") gameStateRef.current.keys.s = false
      if (e.key === "d" || e.key === "ArrowRight") gameStateRef.current.keys.d = false
      if (e.key === "Shift") gameStateRef.current.keys.shift = false
      if (e.key === " ") gameStateRef.current.keys.space = false
    }

    window.addEventListener("keydown", handleKeyDown)
    window.addEventListener("keyup", handleKeyUp)

    return () => {
      window.removeEventListener("keydown", handleKeyDown)
      window.removeEventListener("keyup", handleKeyUp)
    }
  }, [])

  // Game loop
  useEffect(() => {
    if (!gameStarted || gamePaused || gameOver) return

    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    let animationFrameId: number
    let lastTime = 0

    const gameLoop = (timestamp: number) => {
      if (!gameStarted || gamePaused || gameOver) return

      const deltaTime = timestamp - lastTime
      lastTime = timestamp

      gameStateRef.current.gameTime += deltaTime
      gameStateRef.current.lapTime += deltaTime

      // Clear canvas
      ctx.fillStyle = "#0F0B2A"
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      // Update game state
      updateGameState(deltaTime / 1000)

      // Draw track
      drawTrack(ctx)

      // Draw vehicle
      drawVehicle(ctx)

      // Check for lap completion
      checkForLapCompletion()

      animationFrameId = requestAnimationFrame(gameLoop)
    }

    animationFrameId = requestAnimationFrame(gameLoop)

    return () => {
      cancelAnimationFrame(animationFrameId)
    }
  }, [gameStarted, gamePaused, gameOver])

  // Draw track
  const drawTrack = (ctx: CanvasRenderingContext2D) => {
    gameStateRef.current.track.forEach((segment) => {
      ctx.fillStyle = segment.color
      ctx.fillRect(segment.x, segment.y, segment.width, segment.height)
    })
  }

  // Draw vehicle
  const drawVehicle = (ctx: CanvasRenderingContext2D) => {
    const vehicle = gameStateRef.current.vehicle
    if (!vehicle) return

    ctx.save()
    ctx.translate(vehicle.x, vehicle.y)
    ctx.rotate(vehicle.angle)

    ctx.fillStyle = vehicle.color
    ctx.fillRect(-vehicle.width / 2, -vehicle.height / 2, vehicle.width, vehicle.height)

    ctx.restore()
  }

  // Update game state
  const updateGameState = (deltaTime: number) => {
    const { vehicle, keys } = gameStateRef.current
    if (!vehicle) return

    const acceleration = 50
    const rotationSpeed = 2
    const maxSpeed = 200
    const driftRotationFactor = 0.5

    // Acceleration/Deceleration
    if (keys.w) {
      vehicle.speed += acceleration * deltaTime
      vehicle.speed = Math.min(vehicle.speed, maxSpeed)
    } else if (keys.s) {
      vehicle.speed -= acceleration * deltaTime
      vehicle.speed = Math.max(vehicle.speed, -maxSpeed / 2)
    } else {
      // Natural deceleration
      vehicle.speed *= 0.98
    }

    // Steering
    if (keys.a) {
      vehicle.angle -= rotationSpeed * deltaTime * (1 + (keys.shift ? driftRotationFactor : 0))
    }
    if (keys.d) {
      vehicle.angle += rotationSpeed * deltaTime * (1 + (keys.shift ? driftRotationFactor : 0))
    }

    // Drifting
    vehicle.drifting = keys.shift

    // Boosting
    vehicle.boosting = keys.space

    // Apply movement
    vehicle.x += Math.cos(vehicle.angle) * vehicle.speed * deltaTime
    vehicle.y += Math.sin(vehicle.angle) * vehicle.speed * deltaTime

    // Keep vehicle within bounds (simple collision)
    const canvas = canvasRef.current
    if (!canvas) return

    vehicle.x = Math.max(0, Math.min(canvas.width, vehicle.x))
    vehicle.y = Math.max(0, Math.min(canvas.height, vehicle.y))
  }

  // Check for lap completion
  const checkForLapCompletion = () => {
    // Simple lap completion check (can be improved)
    const vehicle = gameStateRef.current.vehicle
    if (!vehicle) return

    // Check if vehicle is near the starting point
    if (Math.abs(vehicle.x - 400) < 50 && Math.abs(vehicle.y - 300) < 50) {
      // Check if lap time is better than best lap time
      if (gameStateRef.current.lapTime < gameStateRef.current.bestLapTime) {
        gameStateRef.current.bestLapTime = gameStateRef.current.lapTime
      }

      // Reset lap time
      gameStateRef.current.lapTime = 0

      // Increment laps completed
      gameStateRef.current.lapsCompleted++

      // Update score
      gameStateRef.current.score += 100
      setScore(gameStateRef.current.score)

      // Check for game over (e.g., 3 laps)
      if (gameStateRef.current.lapsCompleted >= 3) {
        setGameOver(true)
      }
    }
  }

  return (
    <div className="relative">
      {/* Game canvas */}
      <canvas ref={canvasRef} className="bg-[#0F0B2A] rounded-lg shadow-lg" width={800} height={600} />

      {/* Game UI overlay */}
      <div className="absolute top-4 left-4 flex items-center space-x-4">
        <Badge className="bg-[#00FFFF] text-black px-3 py-1">Score: {score}</Badge>
        <Badge className="bg-[#FF2D95] text-white px-3 py-1">Laps: {gameStateRef.current.lapsCompleted}</Badge>
        <Badge className="bg-[#FFFF00] text-black px-3 py-1">
          Best Time: {(gameStateRef.current.bestLapTime / 1000).toFixed(2)}s
        </Badge>
      </div>

      {/* Game controls */}
      <div className="absolute top-4 right-4 flex items-center space-x-2">
        <Button
          size="icon"
          variant="outline"
          className="bg-[#1A1145]/50 border-[#3A2A65] text-white hover:bg-[#3A2A65]/50"
          onClick={toggleMute}
        >
          {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
        </Button>

        <Button
          size="icon"
          variant="outline"
          className="bg-[#1A1145]/50 border-[#3A2A65] text-white hover:bg-[#3A2A65]/50"
          onClick={togglePause}
        >
          {gamePaused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
        </Button>

        <Button
          size="icon"
          variant="outline"
          className="bg-[#1A1145]/50 border-[#3A2A65] text-white hover:bg-[#3A2A65]/50"
          onClick={resetGame}
        >
          <RotateCcw className="h-4 w-4" />
        </Button>
      </div>

      {/* Game start overlay */}
      {!gameStarted && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#0F0B2A]/80 rounded-lg">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4 text-[#00FFFF]">Velocity Rush</h2>
            <p className="text-[#E0E0FF] mb-6 max-w-md">
              Race around the track and complete 3 laps as fast as possible. Use WASD or arrow keys to steer, Shift to
              drift, and Space to boost.
            </p>
            <Button
              onClick={startGame}
              className="bg-gradient-to-r from-[#FFFF00] to-[#FF8A00] text-black font-bold hover:from-[#FFB84D] hover:to-[#FFA733]"
            >
              Start Game
            </Button>
          </div>
        </div>
      )}

      {/* Game over overlay */}
      {gameOver && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#0F0B2A]/80 rounded-lg">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4 text-[#00FFFF]">Game Over</h2>
            <p className="text-2xl text-[#E0E0FF] mb-2">Final Score: {score}</p>
            <p className="text-[#E0E0FF] mb-6">
              You completed the race in {(gameStateRef.current.bestLapTime / 1000).toFixed(2)}s!
            </p>
            <Button
              onClick={resetGame}
              className="bg-gradient-to-r from-[#FFFF00] to-[#FF8A00] text-black font-bold hover:from-[#FFB84D] hover:to-[#FFA733]"
            >
              Play Again
            </Button>
          </div>
        </div>
      )}

      {/* Pause overlay */}
      {gameStarted && gamePaused && !gameOver && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#0F0B2A]/80 rounded-lg">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4 text-[#00FFFF]">Game Paused</h2>
            <Button
              onClick={togglePause}
              className="bg-gradient-to-r from-[#FFFF00] to-[#FF8A00] text-black font-bold hover:from-[#FFB84D] hover:to-[#FFA733]"
            >
              Resume
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}
