"use client"

import { useState } from "react"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Image from "next/image"
import { motion } from "framer-motion"
import { Star, Heart, Share2 } from "lucide-react"
import Link from "next/link"

interface Game {
  id: number
  title: string
  description: string
  image: string
  genres: string[]
  platforms: string[]
  multiplayer: boolean
  pace: string
  complexity: string
}

interface GameCardProps {
  game: Game
}

export default function GameCard({ game }: GameCardProps) {
  const [isHovered, setIsHovered] = useState(false)

  // Generate a random rating between 4.0 and 5.0
  const rating = (4 + Math.random()).toFixed(1)

  return (
    <motion.div whileHover={{ y: -5 }} transition={{ duration: 0.3 }}>
      <Card
        className="overflow-hidden transition-all duration-500 h-full
          bg-gradient-to-br from-[#1A1145] to-[#0F0B2A] border-[#3A2A65]
          hover:shadow-lg hover:shadow-[#9D00FF]/20"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <CardHeader className="p-0">
          <div className="relative h-48 w-full overflow-hidden">
            <Image
              src={game.image || "/placeholder.svg"}
              alt={game.title}
              fill
              className={`object-cover transition-transform duration-700 ${isHovered ? "scale-110" : "scale-100"}`}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0F0B2A] to-transparent opacity-70" />

            <div className="absolute top-2 right-2 flex space-x-1">
              <Badge variant="secondary" className="bg-[#FF2D95]/80 hover:bg-[#FF2D95] border-none text-white">
                <Star className="h-3 w-3 mr-1 fill-white" /> {rating}
              </Badge>
            </div>

            <div className="absolute bottom-2 left-2">
              {game.genres.slice(0, 2).map((genre) => (
                <Badge key={genre} variant="secondary" className="mr-1 bg-[#1A1145]/80 border-[#3A2A65]">
                  {genre}
                </Badge>
              ))}
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-4 relative">
          <h3 className="text-xl font-bold mb-2 bg-clip-text text-transparent bg-gradient-to-r from-white to-[#E0E0FF]">
            {game.title}
          </h3>
          <p className="text-[#E0E0FF] text-sm mb-4 line-clamp-2">{game.description}</p>

          <div className="grid grid-cols-2 gap-2 text-sm">
            <div>
              <span className="text-[#9D9DBF]">Platforms:</span>
              <p className="text-white">{game.platforms.join(", ")}</p>
            </div>
            <div>
              <span className="text-[#9D9DBF]">Multiplayer:</span>
              <p className="text-white">{game.multiplayer ? "Yes" : "No"}</p>
            </div>
            <div>
              <span className="text-[#9D9DBF]">Pace:</span>
              <p className="text-white">{game.pace}</p>
            </div>
            <div>
              <span className="text-[#9D9DBF]">Complexity:</span>
              <p className="text-white">{game.complexity}</p>
            </div>
          </div>
        </CardContent>
        <CardFooter className="p-4 pt-0">
          <div className="w-full flex gap-2">
            <Link href={`/games/${game.id}`} className="flex-1">
              <button className="w-full py-2 rounded-md bg-gradient-to-r from-[#FF2D95] to-[#9D00FF] hover:from-[#FF5CAD] hover:to-[#B347FF] transition-colors duration-300 font-medium text-white">
                Play Now
              </button>
            </Link>
            <button className="w-10 h-10 flex items-center justify-center rounded-md border border-[#3A2A65] hover:bg-[#3A2A65]/50 transition-colors duration-300">
              <Heart className="h-5 w-5 text-[#FF2D95]" />
            </button>
            <button className="w-10 h-10 flex items-center justify-center rounded-md border border-[#3A2A65] hover:bg-[#3A2A65]/50 transition-colors duration-300">
              <Share2 className="h-5 w-5 text-[#00FFFF]" />
            </button>
          </div>
        </CardFooter>
      </Card>
    </motion.div>
  )
}
