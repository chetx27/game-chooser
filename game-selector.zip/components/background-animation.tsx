"use client"

import { useEffect, useRef } from "react"

export default function BackgroundAnimation() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions
    const setCanvasDimensions = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }

    setCanvasDimensions()
    window.addEventListener("resize", setCanvasDimensions)

    // Game elements
    const particles: Particle[] = []
    const gameIcons: GameIcon[] = []

    // Create particles
    for (let i = 0; i < 50; i++) {
      particles.push(new Particle(canvas))
    }

    // Create game icons
    const iconTypes = ["⚔️", "🏹", "🛡️", "🎮", "🎲", "🏆", "🚀", "🧩"]
    for (let i = 0; i < 15; i++) {
      const icon = iconTypes[Math.floor(Math.random() * iconTypes.length)]
      gameIcons.push(new GameIcon(canvas, icon))
    }

    // Mouse position for interactive effects
    let mouseX = 0
    let mouseY = 0

    const handleMouseMove = (e: MouseEvent) => {
      mouseX = e.clientX
      mouseY = e.clientY
    }

    window.addEventListener("mousemove", handleMouseMove)

    // Animation loop
    const animate = () => {
      // Create gradient background
      const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height)
      gradient.addColorStop(0, "#0F0B2A")
      gradient.addColorStop(1, "#1A1145")

      ctx.fillStyle = gradient
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      // Draw grid lines
      ctx.strokeStyle = "rgba(102, 51, 153, 0.1)"
      ctx.lineWidth = 1

      // Horizontal lines
      for (let y = 0; y < canvas.height; y += 40) {
        ctx.beginPath()
        ctx.moveTo(0, y)
        ctx.lineTo(canvas.width, y)
        ctx.stroke()
      }

      // Vertical lines
      for (let x = 0; x < canvas.width; x += 40) {
        ctx.beginPath()
        ctx.moveTo(x, 0)
        ctx.lineTo(x, canvas.height)
        ctx.stroke()
      }

      // Update and draw particles
      particles.forEach((particle) => {
        // Add subtle attraction to mouse
        const dx = mouseX - particle.x
        const dy = mouseY - particle.y
        const distance = Math.sqrt(dx * dx + dy * dy)

        if (distance < 200) {
          const force = 0.2
          particle.vx += (dx / distance) * force
          particle.vy += (dy / distance) * force
        }

        particle.update()
        particle.draw(ctx)
      })

      // Update and draw game icons
      gameIcons.forEach((icon) => {
        // Add subtle repulsion from mouse
        const dx = mouseX - icon.x
        const dy = mouseY - icon.y
        const distance = Math.sqrt(dx * dx + dy * dy)

        if (distance < 150) {
          const force = 1
          icon.vx -= (dx / distance) * force
          icon.vy -= (dy / distance) * force
        }

        icon.update()
        icon.draw(ctx)
      })

      requestAnimationFrame(animate)
    }

    animate()

    return () => {
      window.removeEventListener("resize", setCanvasDimensions)
      window.removeEventListener("mousemove", handleMouseMove)
    }
  }, [])

  return <canvas ref={canvasRef} className="fixed top-0 left-0 w-full h-full -z-10" />
}

class Particle {
  x: number
  y: number
  size: number
  vx: number
  vy: number
  color: string
  canvas: HTMLCanvasElement

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas
    this.x = Math.random() * canvas.width
    this.y = Math.random() * canvas.height
    this.size = Math.random() * 3 + 1
    this.vx = (Math.random() - 0.5) * 0.5
    this.vy = (Math.random() - 0.5) * 0.5

    // Neon colors
    const colors = ["#FF2D95", "#00FFFF", "#9D00FF", "#FFFF00"]
    this.color = colors[Math.floor(Math.random() * colors.length)]
  }

  update() {
    this.x += this.vx
    this.y += this.vy

    // Bounce off edges with some damping
    if (this.x < 0 || this.x > this.canvas.width) {
      this.vx *= -0.9
    }

    if (this.y < 0 || this.y > this.canvas.height) {
      this.vy *= -0.9
    }

    // Keep particles in bounds
    this.x = Math.max(0, Math.min(this.canvas.width, this.x))
    this.y = Math.max(0, Math.min(this.canvas.height, this.y))

    // Add some random movement
    this.vx += (Math.random() - 0.5) * 0.05
    this.vy += (Math.random() - 0.5) * 0.05

    // Limit velocity
    const maxVel = 1.5
    const vel = Math.sqrt(this.vx * this.vx + this.vy * this.vy)
    if (vel > maxVel) {
      this.vx = (this.vx / vel) * maxVel
      this.vy = (this.vy / vel) * maxVel
    }
  }

  draw(ctx: CanvasRenderingContext2D) {
    ctx.beginPath()
    ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2)
    ctx.fillStyle = this.color
    ctx.fill()

    // Add glow effect
    ctx.shadowBlur = 10
    ctx.shadowColor = this.color
    ctx.fill()
    ctx.shadowBlur = 0
  }
}

class GameIcon {
  x: number
  y: number
  size: number
  vx: number
  vy: number
  icon: string
  rotation: number
  rotationSpeed: number
  canvas: HTMLCanvasElement
  opacity: number

  constructor(canvas: HTMLCanvasElement, icon: string) {
    this.canvas = canvas
    this.x = Math.random() * canvas.width
    this.y = Math.random() * canvas.height
    this.size = Math.random() * 20 + 20
    this.vx = (Math.random() - 0.5) * 0.8
    this.vy = (Math.random() - 0.5) * 0.8
    this.icon = icon
    this.rotation = Math.random() * Math.PI * 2
    this.rotationSpeed = (Math.random() - 0.5) * 0.02
    this.opacity = Math.random() * 0.5 + 0.1
  }

  update() {
    this.x += this.vx
    this.y += this.vy
    this.rotation += this.rotationSpeed

    // Bounce off edges
    if (this.x < 0 || this.x > this.canvas.width) {
      this.vx *= -1
    }

    if (this.y < 0 || this.y > this.canvas.height) {
      this.vy *= -1
    }

    // Pulsate opacity
    this.opacity = 0.1 + Math.abs(Math.sin(Date.now() * 0.001)) * 0.5
  }

  draw(ctx: CanvasRenderingContext2D) {
    ctx.save()
    ctx.translate(this.x, this.y)
    ctx.rotate(this.rotation)
    ctx.globalAlpha = this.opacity
    ctx.font = `${this.size}px Arial`
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText(this.icon, 0, 0)
    ctx.globalAlpha = 1
    ctx.restore()
  }
}
