"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ArrowRight, RefreshCw, Sparkles } from "lucide-react"
import GameCard from "./game-card"
import { motion, AnimatePresence } from "framer-motion"

// Sample game data
const GAMES = [
  {
    id: 1,
    title: "Cosmic Conquest",
    description: "An epic space strategy game with deep resource management and diplomacy.",
    image: "/placeholder.svg?height=300&width=200",
    genres: ["Strategy", "Sci-Fi", "4X"],
    platforms: ["PC", "Mac"],
    multiplayer: false,
    pace: "Slow",
    complexity: "High",
  },
  {
    id: 2,
    title: "Neon Fury",
    description: "Fast-paced cyberpunk shooter with stunning visuals and intense combat.",
    image: "/placeholder.svg?height=300&width=200",
    genres: ["Action", "FPS", "Cyberpunk"],
    platforms: ["PC", "PlayStation", "Xbox"],
    multiplayer: true,
    pace: "Fast",
    complexity: "Medium",
  },
  {
    id: 3,
    title: "Verdant Valley",
    description: "Relaxing farming simulator where you build your dream homestead.",
    image: "/placeholder.svg?height=300&width=200",
    genres: ["Simulation", "Casual", "Life Sim"],
    platforms: ["PC", "Switch", "Mobile"],
    multiplayer: false,
    pace: "Slow",
    complexity: "Low",
  },
  {
    id: 4,
    title: "Legends Arena",
    description: "Competitive team-based battle game with unique heroes and abilities.",
    image: "/placeholder.svg?height=300&width=200",
    genres: ["MOBA", "Strategy", "Action"],
    platforms: ["PC", "Mobile"],
    multiplayer: true,
    pace: "Fast",
    complexity: "High",
  },
  {
    id: 5,
    title: "Mystic Realms",
    description: "Immersive fantasy RPG with a vast open world and compelling storyline.",
    image: "/placeholder.svg?height=300&width=200",
    genres: ["RPG", "Fantasy", "Open World"],
    platforms: ["PC", "PlayStation", "Xbox"],
    multiplayer: false,
    pace: "Medium",
    complexity: "High",
  },
  {
    id: 6,
    title: "Velocity Rush",
    description: "High-octane racing game with futuristic vehicles and impossible tracks.",
    image: "/placeholder.svg?height=300&width=200",
    genres: ["Racing", "Arcade", "Futuristic"],
    platforms: ["PC", "PlayStation", "Xbox", "Switch"],
    multiplayer: true,
    pace: "Fast",
    complexity: "Low",
  },
  {
    id: 7,
    title: "Puzzle Dimensions",
    description: "Mind-bending puzzle game that plays with physics and perspective.",
    image: "/placeholder.svg?height=300&width=200",
    genres: ["Puzzle", "Casual", "Indie"],
    platforms: ["PC", "Mobile", "Switch"],
    multiplayer: false,
    pace: "Slow",
    complexity: "Medium",
  },
  {
    id: 8,
    title: "Survival Horizon",
    description: "Post-apocalyptic survival game where every decision matters.",
    image: "/placeholder.svg?height=300&width=200",
    genres: ["Survival", "Open World", "Crafting"],
    platforms: ["PC", "PlayStation", "Xbox"],
    multiplayer: true,
    pace: "Medium",
    complexity: "High",
  },
]

// Contrasting choices for the game selector
const CHOICES = [
  {
    id: "pace",
    question: "Do you prefer fast-paced action or a more relaxed experience?",
    options: [
      {
        value: "Fast",
        label: "Fast-paced",
        description: "Quick reflexes, intense action",
        icon: "🏃‍♂️",
        color: "from-[#FF2D95] to-[#FF5C5C]",
      },
      {
        value: "Slow",
        label: "Relaxed",
        description: "Take your time, think things through",
        icon: "🧘‍♂️",
        color: "from-[#00FFFF] to-[#0080FF]",
      },
    ],
  },
  {
    id: "multiplayer",
    question: "Do you want to play with others or enjoy a solo experience?",
    options: [
      {
        value: true,
        label: "Multiplayer",
        description: "Compete or cooperate with other players",
        icon: "👥",
        color: "from-[#9D00FF] to-[#FF2D95]",
      },
      {
        value: false,
        label: "Single-player",
        description: "Focus on your own journey",
        icon: "👤",
        color: "from-[#00FFFF] to-[#00FF80]",
      },
    ],
  },
  {
    id: "complexity",
    question: "How complex do you want your game to be?",
    options: [
      {
        value: "High",
        label: "Complex",
        description: "Deep systems, steep learning curve",
        icon: "🧠",
        color: "from-[#FFFF00] to-[#FF8A00]",
      },
      {
        value: "Low",
        label: "Simple",
        description: "Easy to learn, pick up and play",
        icon: "🎯",
        color: "from-[#00FF80] to-[#00FFFF]",
      },
    ],
  },
]

export default function GameSelector() {
  const [currentStep, setCurrentStep] = useState(0)
  const [preferences, setPreferences] = useState<Record<string, any>>({})
  const [recommendations, setRecommendations] = useState<typeof GAMES>([])
  const [showResults, setShowResults] = useState(false)
  const [isTransitioning, setIsTransitioning] = useState(false)
  const [selectedOption, setSelectedOption] = useState<number | null>(null)

  const handleChoice = (value: any, optionIndex: number) => {
    setSelectedOption(optionIndex)

    setTimeout(() => {
      setIsTransitioning(true)

      setTimeout(() => {
        const updatedPreferences = { ...preferences, [CHOICES[currentStep].id]: value }
        setPreferences(updatedPreferences)

        if (currentStep < CHOICES.length - 1) {
          setCurrentStep(currentStep + 1)
        } else {
          // Generate recommendations based on preferences
          const filteredGames = GAMES.filter((game) => {
            let score = 0

            // Check each preference against the game properties
            Object.entries(updatedPreferences).forEach(([key, value]) => {
              if (game[key] === value) {
                score++
              }
            })

            // Return games that match at least one preference
            return score > 0
          })

          // Sort by how many preferences they match
          filteredGames.sort((a, b) => {
            const scoreA = Object.entries(updatedPreferences).filter(([key, value]) => a[key] === value).length
            const scoreB = Object.entries(updatedPreferences).filter(([key, value]) => b[key] === value).length
            return scoreB - scoreA
          })

          setRecommendations(filteredGames.length > 0 ? filteredGames : GAMES)
          setShowResults(true)
        }

        setIsTransitioning(false)
        setSelectedOption(null)
      }, 500)
    }, 300)
  }

  const resetSelector = () => {
    setIsTransitioning(true)

    setTimeout(() => {
      setCurrentStep(0)
      setPreferences({})
      setShowResults(false)
      setIsTransitioning(false)
    }, 500)
  }

  // Sound effects
  useEffect(() => {
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()

    // Function to play a tone
    const playTone = (frequency: number, duration: number, type: OscillatorType = "sine") => {
      const oscillator = audioContext.createOscillator()
      const gainNode = audioContext.createGain()

      oscillator.type = type
      oscillator.frequency.value = frequency
      oscillator.connect(gainNode)
      gainNode.connect(audioContext.destination)

      // Fade in and out to avoid clicks
      gainNode.gain.value = 0
      gainNode.gain.linearRampToValueAtTime(0.3, audioContext.currentTime + 0.05)
      gainNode.gain.linearRampToValueAtTime(0, audioContext.currentTime + duration)

      oscillator.start()
      oscillator.stop(audioContext.currentTime + duration)
    }

    // Play a sound when step changes
    if (currentStep > 0 || showResults) {
      playTone(440 + currentStep * 100, 0.3, "sine")
    }
  }, [currentStep, showResults])

  if (showResults) {
    return (
      <AnimatePresence>
        <motion.div
          className="space-y-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.5 }}
        >
          <div className="text-center">
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.2, duration: 0.5 }}
              className="inline-block mb-6"
            >
              <div className="p-3 rounded-full bg-gradient-to-r from-[#FF2D95] to-[#9D00FF] shadow-lg shadow-purple-500/20">
                <Sparkles className="h-8 w-8 text-white" />
              </div>
            </motion.div>
            <h2 className="text-3xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-[#FF2D95] to-[#00FFFF]">
              Your Game Recommendations
            </h2>
            <p className="text-[#E0E0FF] mb-8">Based on your preferences, we think you'll enjoy these games:</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {recommendations.slice(0, 6).map((game, index) => (
              <motion.div
                key={game.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * index, duration: 0.5 }}
              >
                <GameCard game={game} />
              </motion.div>
            ))}
          </div>

          <div className="flex justify-center mt-8">
            <Button
              onClick={resetSelector}
              variant="outline"
              className="flex items-center gap-2 bg-transparent border border-[#9D00FF] text-white hover:bg-[#9D00FF]/20 transition-all duration-300"
            >
              <RefreshCw className="h-4 w-4" />
              Start Over
            </Button>
          </div>
        </motion.div>
      </AnimatePresence>
    )
  }

  const currentChoice = CHOICES[currentStep]

  return (
    <AnimatePresence>
      <motion.div
        className="max-w-3xl mx-auto"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        transition={{ duration: 0.5 }}
        key={currentStep}
      >
        <div className="flex justify-between mb-8">
          {CHOICES.map((choice, index) => (
            <div key={choice.id} className={`relative flex-1 ${index > 0 ? "ml-2" : ""}`}>
              <div
                className={`h-2 rounded-full ${
                  index < currentStep
                    ? "bg-gradient-to-r from-[#FF2D95] to-[#9D00FF]"
                    : index === currentStep
                      ? "bg-gradient-to-r from-[#00FFFF] to-[#0080FF]"
                      : "bg-[#2A1B4A]"
                } transition-all duration-500`}
              />
              <div
                className={`absolute -top-1 left-1/2 transform -translate-x-1/2 w-4 h-4 rounded-full ${
                  index < currentStep ? "bg-[#FF2D95]" : index === currentStep ? "bg-[#00FFFF]" : "bg-[#2A1B4A]"
                } transition-all duration-500`}
              />
            </div>
          ))}
        </div>

        <div className="text-center mb-8">
          <motion.h2
            className="text-2xl font-bold mb-2 bg-clip-text text-transparent bg-gradient-to-r from-[#00FFFF] to-[#0080FF]"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.5 }}
          >
            {currentChoice.question}
          </motion.h2>
          <motion.p
            className="text-[#E0E0FF]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.5 }}
          >
            Step {currentStep + 1} of {CHOICES.length}
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {currentChoice.options.map((option, index) => (
            <motion.div
              key={option.label}
              initial={{ opacity: 0, x: index === 0 ? -20 : 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 + index * 0.1, duration: 0.5 }}
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.98 }}
            >
              <Card
                className={`border-2 transition-all duration-500 cursor-pointer overflow-hidden
                  ${selectedOption === index ? "border-white scale-95" : "border-transparent hover:border-[#00FFFF]"}
                  bg-gradient-to-br from-[#1A1145] to-[#0F0B2A]
                `}
                onClick={() => handleChoice(option.value, index)}
              >
                <div className="p-6 h-full flex flex-col justify-between relative overflow-hidden">
                  {/* Background glow effect */}
                  <div
                    className={`absolute inset-0 opacity-20 bg-gradient-to-br ${option.color} blur-xl transition-opacity duration-300
                      ${selectedOption === index ? "opacity-60" : "opacity-20"}
                    `}
                  />

                  <div className="relative z-10">
                    <div className="flex items-center mb-4">
                      <div
                        className={`text-4xl mr-3 bg-gradient-to-br ${option.color} rounded-full w-12 h-12 flex items-center justify-center`}
                      >
                        {option.icon}
                      </div>
                      <h3 className="text-xl font-bold">{option.label}</h3>
                    </div>
                    <p className="text-[#E0E0FF]">{option.description}</p>
                  </div>

                  <Button
                    variant="ghost"
                    className={`mt-4 self-end relative z-10 text-white
                      ${selectedOption === index ? "bg-gradient-to-r from-[#FF2D95] to-[#9D00FF]" : "hover:bg-white/10"}
                    `}
                  >
                    Select <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </AnimatePresence>
  )
}
